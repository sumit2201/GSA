<?php  $bracket_game_numbers = array();
//echo $bracket_game_numbers;
$bracket_game_numbers[1] = array();
$bracket_game_numbers[2] = array();
$bracket_game_numbers[3] = array();
$bracket_game_numbers[4] = array();
$bracket_game_numbers[5] = array();
$bracket_game_numbers[6] = array();
$bracket_game_numbers[7] = array();
$bracket_game_numbers[8] = array();

$bracket_game_numbers[1][3] = array();
//$bracket_game_numbers[1][3][0] = array('3,4,6,7;1,0;5;0,0:1');

//print_r($bracket_game_numbers[1][3][0]);//die;

$bracket_game_numbers[1][4] = array();
//$bracket_game_numbers[1][4][0] = array('3,4,5,8,9;1,1;6,7;0,1:1');
$bracket_game_numbers[1][5] = array();
//$bracket_game_numbers[1][5][0] = array('4,5,6,8,11,12;0,0,0,1;7,9,10;1,0:0,1:1');
$bracket_game_numbers[1][6] = array();
//$bracket_game_numbers[1][6][0] = array('4,5,6,7,10,13,14;0,1,1,0;8,9,11,12;1,1:0,1:1');
$bracket_game_numbers[1][7] = array();
//$bracket_game_numbers[1][7][0] = array('5,6,7,8,10,13,16,17;0,1,1,1;9,12,11,14,15;0,1,0,0:1,1:0,1:1');
$bracket_game_numbers[1][8] = array();
//$bracket_game_numbers[1][8][0] = array('5,6,7,8,10,12,15,18,19;1,1,1,1;9,11,13,14,16,17;1,0,1,0:1,1:1,0:1');
$bracket_game_numbers[1][9] = array();
//$bracket_game_numbers[1][9][0] = array('6,7,8,10,9,12,14,18,21,22;0,0,0,0,0,1,0,0;11,15,13,17,16,19,20;0,1,0,0:1,0,1,0:1,1:0,1:1');
$bracket_game_numbers[1][10] = array();
//$bracket_game_numbers[1][10][0] = array('7,8,6,10,11,9,14,16,20,23,24;0,0,1,0,0,1,0,0;12,13,15,17,18,19,21,22;1,0,1,0:1,0,1,0:1,1:1,0:1');
$bracket_game_numbers[1][11] = array();
//$bracket_game_numbers[1][11][0] = array('7,8,9,10,11,12,13,16,18,23,26,27;0,0,0,1,1,0,1,0;14,15,17,19,20,21,22,24,25;1,1,1,0:0,1,0,1:1,1:0,1:1');
$bracket_game_numbers[1][12] = array();
//$bracket_game_numbers[1][12][0] = array('7,8,9,10,11,12,13,14,19,20,25,28,29;0,1,1,0,1,0,1,0;15,16,17,18,21,22,23,24,26,27;1,1,1,1:1,0,1,0:1,1:0,1:1');
$bracket_game_numbers[1][13] = array();
//$bracket_game_numbers[1][13][0] = array('8,9,10,11,12,13,14,16,15,22,23,28,31,32;0,1,1,0,1,1,1,0;17,21,18,19,20,24,25,26,27,29,30;0,1,0,0,0,0,0,0:1,1,1,1:1,0,1,0:1,1:0,1:1');
$bracket_game_numbers[1][14] = array();
//$bracket_game_numbers[1][14][0] = array('8,9,10,11,12,13,16,14,17,15,24,25,30,33,34;1,1,1,0,1,1,1,0;18,19,22,20,23,21,26,27,28,29,31,32;0,1,0,0,1,0,0,0:1,1,1,1:1,0,1,0:1,1:0,1:1');

$bracket_game_numbers[2][3] = array();
$bracket_game_numbers[2][4] = array();
$bracket_game_numbers[2][5] = array();
$bracket_game_numbers[2][6] = array();
$bracket_game_numbers[2][7] = array();
$bracket_game_numbers[2][8] = array();
$bracket_game_numbers[2][9] = array();
$bracket_game_numbers[2][10] = array();
$bracket_game_numbers[2][11] = array();
$bracket_game_numbers[2][12] = array();

$bracket_game_numbers[3][3] = array();
$bracket_game_numbers[3][4] = array();
$bracket_game_numbers[3][5] = array();
$bracket_game_numbers[3][6] = array();
$bracket_game_numbers[3][7] = array();
$bracket_game_numbers[3][8] = array();
$bracket_game_numbers[3][9] = array();
$bracket_game_numbers[3][10] = array();
$bracket_game_numbers[3][11] = array();
$bracket_game_numbers[3][12] = array();
$bracket_game_numbers[3][13] = array();
$bracket_game_numbers[3][14] = array();

$bracket_game_numbers[4][4] = array();
$bracket_game_numbers[4][5] = array();
$bracket_game_numbers[4][6] = array();
$bracket_game_numbers[4][7] = array();
$bracket_game_numbers[4][8] = array();
$bracket_game_numbers[4][9] = array();
$bracket_game_numbers[4][10] = array();
$bracket_game_numbers[4][11] = array();
$bracket_game_numbers[4][12] = array();

$bracket_game_numbers[5][3] = array();
$bracket_game_numbers[5][4] = array();
$bracket_game_numbers[5][5] = array();
$bracket_game_numbers[5][6] = array();
$bracket_game_numbers[5][7] = array();
$bracket_game_numbers[5][8] = array();
$bracket_game_numbers[5][9] = array();
$bracket_game_numbers[5][10] = array();
$bracket_game_numbers[5][11] = array();
$bracket_game_numbers[5][12] = array();


$bracket_game_numbers[6][4] = array();
$bracket_game_numbers[6][5] = array();
$bracket_game_numbers[6][6] = array();
$bracket_game_numbers[6][7] = array();
$bracket_game_numbers[6][8] = array();
$bracket_game_numbers[6][9] = array();
$bracket_game_numbers[6][10] = array();
$bracket_game_numbers[6][11] = array();
$bracket_game_numbers[6][12] = array();


$bracket_game_numbers[7][4] = array();
$bracket_game_numbers[7][5] = array();
$bracket_game_numbers[7][6] = array();
$bracket_game_numbers[7][7] = array();
$bracket_game_numbers[7][8] = array();
$bracket_game_numbers[7][9] = array();
$bracket_game_numbers[7][10] = array();
$bracket_game_numbers[7][11] = array();
$bracket_game_numbers[7][12] = array();


$bracket_game_numbers[8][3] = array();
$bracket_game_numbers[8][4] = array();
$bracket_game_numbers[8][5] = array();
$bracket_game_numbers[8][6] = array();
$bracket_game_numbers[8][7] = array();
$bracket_game_numbers[8][8] = array();
$bracket_game_numbers[8][9] = array();
$bracket_game_numbers[8][10] = array();

$bracket_game_numbers[9][2] = array();
$bracket_game_numbers[9][3] = array();
$bracket_game_numbers[9][4] = array();
$bracket_game_numbers[9][5] = array();
$bracket_game_numbers[9][6] = array();
$bracket_game_numbers[9][7] = array();
$bracket_game_numbers[9][8] = array();
$bracket_game_numbers[9][9] = array();
$bracket_game_numbers[9][10] = array();
$bracket_game_numbers[9][11] = array();
$bracket_game_numbers[9][12] = array();
$bracket_game_numbers[9][13] = array();
$bracket_game_numbers[9][14] = array();


$bracket_game_numbers[12][4] = array();
$bracket_game_numbers[12][5] = array();
$bracket_game_numbers[12][6] = array();
$bracket_game_numbers[12][7] = array();
$bracket_game_numbers[12][8] = array();
$bracket_game_numbers[12][9] = array();
$bracket_game_numbers[12][10] = array();
$bracket_game_numbers[12][11] = array();
$bracket_game_numbers[12][12] = array();
$bracket_game_numbers[12][13] = array();
$bracket_game_numbers[12][14] = array();
$bracket_game_numbers[12][15] = array();
$bracket_game_numbers[12][16] = array();



$bracket_game_numbers[1][3][1] = array("Team 1", "Team 2", "P", "0", "", "");
$bracket_game_numbers[1][3][2] = array("Team 3", "Team 1", "P", "0", "", "");
$bracket_game_numbers[1][3][3] = array("Team 2", "Team 3", "W", "0", "", "");
$bracket_game_numbers[1][3][4] = array("Team 1", "Winner Game 3", "W", "0", "", "W-3");
$bracket_game_numbers[1][3][5] = array("Loser Game 3", "Loser Game 4", "L", "3", "L-3", "L-4");
$bracket_game_numbers[1][3][6] = array("Winner Game 4", "Winner Game 5", "W", "1", "W-4", "W-5");
$bracket_game_numbers[1][3][7] = array("Winner Game 6", "Loser 6 If 1st Loss", "W", "1", "W-6", "L-6");


$bracket_game_numbers[1][4][1] = array("Team 1", "Team 2", "P", "0", "", "");
$bracket_game_numbers[1][4][2] = array("Team 3", "Team 4", "P", "0", "", "");
$bracket_game_numbers[1][4][3] = array("Team 2", "Team 3", "W", "0", "", "");
$bracket_game_numbers[1][4][4] = array("Team 1", "Team 4", "W", "0", "", "");
$bracket_game_numbers[1][4][5] = array("Winner Game 3", "Winner Game 4", "W", "0", "W-3", "W-4");
$bracket_game_numbers[1][4][6] = array("Loser Game 3", "Loser Game 4", "L", "4", "L-3", "L-4");
$bracket_game_numbers[1][4][7] = array("Winner Game 6", "Loser Game 5", "L", "3", "W-6", "L-5");
$bracket_game_numbers[1][4][8] = array("Winner Game 5", "Winner Game 7", "W", "1", "W-5", "W-7");
$bracket_game_numbers[1][4][9] = array("Winner Game 8", "Loser 8 If 1st Loss", "W", "1", "W-8", "L-8");


$bracket_game_numbers[1][5][1] = array("Team 1", "Team 2", "P", "0", "", "");
$bracket_game_numbers[1][5][2] = array("Team 3", "Team 4", "P", "0", "", "");
$bracket_game_numbers[1][5][3] = array("Team 5", "Team 1", "P", "0", "", "");
$bracket_game_numbers[1][5][4] = array("Team 2", "Team 3", "W", "0", "", "");
$bracket_game_numbers[1][5][5] = array("Team 4", "Team 5", "W", "0", "", "");
$bracket_game_numbers[1][5][6] = array("Team 1", "Winner Game 4", "W", "0", "", "W-4");
$bracket_game_numbers[1][5][7] = array("Loser Game 4", "Loser Game 5", "L", "5", "L-4", "L-5");
$bracket_game_numbers[1][5][8] = array("Winner Game 5", "Winner Game 6", "W", "0", "W-5", "W-6");
$bracket_game_numbers[1][5][9] = array("Winner Game 7", "Loser Game 6", "L", "4", "W-7", "L-6");
$bracket_game_numbers[1][5][10] = array("Winner Game 9", "Loser Game 8", "L", "3", "W-9", "L-8");
$bracket_game_numbers[1][5][11] = array("Winner Game 8", "Winner Game 10", "W", "1", "W-8", "W-10");
$bracket_game_numbers[1][5][12] = array("Winner Game 11", "Loser 11 If 1st Loss", "W", "1", "W-11", "L-11");


$bracket_game_numbers[1][6][1] = array("Team 1", "Team 2", "P", "0", "", "");
$bracket_game_numbers[1][6][2] = array("Team 3", "Team 4", "P", "0", "", "");
$bracket_game_numbers[1][6][3] = array("Team 5", "Team 6", "P", "0", "", "");
$bracket_game_numbers[1][6][4] = array("Team 1", "Team 4", "W", "0", "", "");
$bracket_game_numbers[1][6][5] = array("Team 2", "Team 3", "W", "0", "" ,"");
$bracket_game_numbers[1][6][6] = array("Team 5", "Winner Game 4", "W", "0", "", "W-4");
$bracket_game_numbers[1][6][7] = array("Team 6", "Winner Game 5", "W", "0", "", "W-5");
$bracket_game_numbers[1][6][8] = array("Loser Game 4", "Loser Game 5", "L", "6", "L-4", "L-5");
$bracket_game_numbers[1][6][9] = array("Loser Game 6", "Loser Game 7", "L", "5", "L-6", "L-7");
$bracket_game_numbers[1][6][10] = array("Winner Game 6", "Winner Game 7", "W", "0", "W-6", "W-7");
$bracket_game_numbers[1][6][11] = array("Winner Game 8", "Winner Game 9", "L", "4", "W-8", "W-9");
$bracket_game_numbers[1][6][12] = array("Winner Game 11", "Loser Game 10", "L", "3", "W-11", "L-10");
$bracket_game_numbers[1][6][13] = array("Winner Game 10", "Winner Game 12", "W", "1", "W-10", "W-12");
$bracket_game_numbers[1][6][14] = array("Winner Game 13", "Loser 13 If 1st Loss", "W", "1", "W-13", "L-13");


$bracket_game_numbers[1][7][1] = array("Team 1", "Team 2", "P", "0", "", "");
$bracket_game_numbers[1][7][2] = array("Team 3", "Team 4", "P", "0", "", "");
$bracket_game_numbers[1][7][3] = array("Team 5", "Team 6", "P", "0", "", "");
$bracket_game_numbers[1][7][4] = array("Team 7", "Team 1", "P", "0", "", "");
$bracket_game_numbers[1][7][5] = array("Team 2", "Team 3", "W", "0", "", "");
$bracket_game_numbers[1][7][6] = array("Team 4", "Team 5", "W", "0", "", "");
$bracket_game_numbers[1][7][7] = array("Team 6", "Team 7", "W", "0", "", "");
$bracket_game_numbers[1][7][8] = array("Team 1", "Winner Game 5", "W", "0", "", "W-5");
$bracket_game_numbers[1][7][9] = array("Loser Game 5", "Loser Game 6", "L", "7", "L-5", "L-6");
$bracket_game_numbers[1][7][10] = array("Winner Game 6", "Winner Game 7", "W", "0", "W-6", "W-7");
$bracket_game_numbers[1][7][11] = array("Loser Game 7", "Loser Game 8", "L", "6", "L-7", "L-8");
$bracket_game_numbers[1][7][12] = array("Winner Game 9", "Loser Game 10", "L", "5", "W-9", "L-10");
$bracket_game_numbers[1][7][13] = array("Winner Game 8", "Winner Game 10", "W", "0", "W-8", "W-10");
$bracket_game_numbers[1][7][14] = array("Winner Game 11", "Winner Game 12", "L", "4", "W-11", "W-12");
$bracket_game_numbers[1][7][15] = array("Winner Game 14", "Loser Game 13", "L", "3", "W-14", "W-13");
$bracket_game_numbers[1][7][16] = array("Winner Game 13", "Winner Game 15", "W", "1", "W-13", "W-15");
$bracket_game_numbers[1][7][17] = array("Winner Game 16", "Loser 16 If 1st Loss", "W", "1", "W-16", "L-16");


$bracket_game_numbers[1][8][1] = array("Team 1", "Team 2", "P", "0", "", "");
$bracket_game_numbers[1][8][2] = array("Team 3", "Team 4", "P", "0", "", "");
$bracket_game_numbers[1][8][3] = array("Team 5", "Team 6", "P", "0", "", "");
$bracket_game_numbers[1][8][4] = array("Team 7", "Team 8", "P", "0", "", "");
$bracket_game_numbers[1][8][5] = array("Team 1", "Team 4", "W", "0", "", "");
$bracket_game_numbers[1][8][6] = array("Team 2", "Team 3", "W", "0", "", "");
$bracket_game_numbers[1][8][7] = array("Team 5", "Team 8", "W", "0", "", "");
$bracket_game_numbers[1][8][8] = array("Team 6", "Team 7", "W", "0", "", "");
$bracket_game_numbers[1][8][9] = array("Loser Game 5", "Loser Game 6", "L", "8", "L-5", "L-6");
$bracket_game_numbers[1][8][10] = array("Winner Game 5", "Winner Game 6", "W", "0", "W-5", "W-6");
$bracket_game_numbers[1][8][11] = array("Loser Game 7", "Loser Game 8", "L", "7", "L-7", "L-8");
$bracket_game_numbers[1][8][12] = array("Winner Game 7", "Winner Game 8", "W", "0", "W-7", "W-8");
$bracket_game_numbers[1][8][13] = array("Winner Game 9", "Loser Game 12", "L", "6", "W-9", "L-12");
$bracket_game_numbers[1][8][14] = array("Winner Game 11", "Loser Game 10", "L", "5", "W-11", "L-10");
$bracket_game_numbers[1][8][15] = array("Winner Game 10", "Winner Game 12", "W", "0", "W-10", "W-12");
$bracket_game_numbers[1][8][16] = array("Winner Game 13", "Winner Game 14", "L", "4", "W-13", "W-14");
$bracket_game_numbers[1][8][17] = array("Winner Game 16", "Loser Game 15", "L", "3", "W-16", "L-15");
$bracket_game_numbers[1][8][18] = array("Winner Game 15", "Winner Game 17", "W", "1", "W-15", "W-17");
$bracket_game_numbers[1][8][19] = array("Winner Game 18", "Loser 18 If 1st Loss", "W", "1", "W-18", "L-18");


$bracket_game_numbers[1][9][1] = array("Team 1", "Team 2", "P", "0", "", "");
$bracket_game_numbers[1][9][2] = array("Team 3", "Team 4", "P", "0", "", "");
$bracket_game_numbers[1][9][3] = array("Team 5", "Team 6", "P", "0", "", "");
$bracket_game_numbers[1][9][4] = array("Team 7", "Team 8", "P", "0", "", "");
$bracket_game_numbers[1][9][5] = array("Team 9", "Team 1", "P", "0", "", "");
$bracket_game_numbers[1][9][6] = array("Team 2", "Team 3", "W", "0", "", "");
$bracket_game_numbers[1][9][7] = array("Team 4", "Team 5", "W", "0", "", "");
$bracket_game_numbers[1][9][8] = array("Team 6", "Team 7", "W", "0", "", "");
$bracket_game_numbers[1][9][9] = array("Team 8", "Team 9", "W", "0", "", "");
$bracket_game_numbers[1][9][10] = array("Team 1", "Winner Game 6", "W", "0", "" ,"W-6");
$bracket_game_numbers[1][9][11] = array("Loser Game 6", "Loser Game 7", "L", "9", "L-6", "L-7");
$bracket_game_numbers[1][9][12] = array("Winner Game 7", "Winner Game 8", "W", "0", "W-7", "W-8");
$bracket_game_numbers[1][9][13] = array("Loser Game 8", "Loser Game 9", "L", "8", "L-8", "L-9");
$bracket_game_numbers[1][9][14] = array("Winner Game 9", "Winner Game 10", "W", "0", "W-9", "W-10");
$bracket_game_numbers[1][9][15] = array("Winner Game 11", "Loser Game 10", "L", "7", "W-11", "L-10");
$bracket_game_numbers[1][9][16] = array("Winner Game 13", "Loser Game 14", "L", "6", "W-13", "L-14");
$bracket_game_numbers[1][9][17] = array("Winner Game 15", "Loser Game 12", "L", "5", "W-15", "L-12");
$bracket_game_numbers[1][9][18] = array("Winner Game 12", "Winner Game 14", "W", "0", "W-12", "W-17");
$bracket_game_numbers[1][9][19] = array("Winner Game 16", "Winner Game 17", "L", "4", "W-16", "W-17");
$bracket_game_numbers[1][9][20] = array("Winner Game 19", "Loser Game 18", "L", "3", "W-19", "L-18");
$bracket_game_numbers[1][9][21] = array("Winner Game 18", "Winner Game 20", "W", "1", "W-18", "W-20");
$bracket_game_numbers[1][9][22] = array("Winner Game 21", "Loser 21 If 1st Loss", "W", "1", "W-21", "L-21");


$bracket_game_numbers[1][10][1] = array("Team 1", "Team 2", "P", "0", "", "");
$bracket_game_numbers[1][10][2] = array("Team 3", "Team 4", "P", "0", "", "");
$bracket_game_numbers[1][10][3] = array("Team 5", "Team 6", "P", "0", "", "");
$bracket_game_numbers[1][10][4] = array("Team 7", "Team 8", "P", "0", "", "");
$bracket_game_numbers[1][10][5] = array("Team 9", "Team 10", "P", "0", "", "");
$bracket_game_numbers[1][10][6] = array("Team 1", "Team 4", "W", "0", "", "");
$bracket_game_numbers[1][10][7] = array("Team 2", "Team 3", "W", "0", "", "");
$bracket_game_numbers[1][10][8] = array("Team 5", "Team 8", "W", "0", "", "");
$bracket_game_numbers[1][10][9] = array("Team 6", "Team 7", "W", "0", "", "");
$bracket_game_numbers[1][10][10] = array("Team 9", "Winner Game 7", "W", "0", "", "W-7");
$bracket_game_numbers[1][10][11] = array("Team 10", "Winner Game 8", "W", "0", "", "W-8");
$bracket_game_numbers[1][10][12] = array("Loser Game 6", "Loser Game 7", "L", "10", "L-6", "L-7");
$bracket_game_numbers[1][10][13] = array("Loser Game 8", "Loser Game 9", "L", "9", "L-8", "L-9");
$bracket_game_numbers[1][10][14] = array("Winner Game 6", "Winner Game 10", "W", "0", "W-6", "W-10");
$bracket_game_numbers[1][10][15] = array("Winner Game 12", "Loser Game 11", "L", "8", "W-12", "L-11");
$bracket_game_numbers[1][10][16] = array("Winner Game 9", "Winner Game 11", "W", "0", "W-9", "W-11");
$bracket_game_numbers[1][10][17] = array("Winner Game 13", "Loser Game 10", "L", "7", "W-13", "L-10");
$bracket_game_numbers[1][10][18] = array("Winner Game 15", "Loser Game 14", "L", "6", "W-15", "L-14");
$bracket_game_numbers[1][10][19] = array("Winner Game 17", "Loser Game 16", "L", "5", "W-17", "L-16");
$bracket_game_numbers[1][10][20] = array("Winner Game 14", "Winner Game 16", "W", "W-14", "W-16");
$bracket_game_numbers[1][10][21] = array("Winner Game 18", "Winner Game 19", "L", "4", "W-18", "W-19");
$bracket_game_numbers[1][10][22] = array("Winner Game 21", "Loser Game 20", "L", "3", "W-21", "L-20");
$bracket_game_numbers[1][10][23] = array("Winner Game 20", "Winner Game 22", "W", "1", "W-20", "W-22");
$bracket_game_numbers[1][10][24] = array("Winner Game 23", "Loser 23 If 1st Loss", "W", "1", "W-23", "L-23");


$bracket_game_numbers[1][11][1] = array("Team 1", "Team 2", "P", "0", "", "");
$bracket_game_numbers[1][11][2] = array("Team 3", "Team 4", "P", "0", "", "");
$bracket_game_numbers[1][11][3] = array("Team 5", "Team 6", "P", "0", "", "");
$bracket_game_numbers[1][11][4] = array("Team 7", "Team 8", "P", "0", "", "");
$bracket_game_numbers[1][11][5] = array("Team 9", "Team 10", "P", "0", "", "");
$bracket_game_numbers[1][11][6] = array("Team 11", "Team 1", "P", "0", "", "");
$bracket_game_numbers[1][11][7] = array("Team 2", "Team 3", "W", "0", "", "");
$bracket_game_numbers[1][11][8] = array("Team 4", "Team 5", "W", "0", "", "");
$bracket_game_numbers[1][11][9] = array("Team 6", "Team 7", "W", "0", "", "");
$bracket_game_numbers[1][11][10] = array("Team 8", "Team 9", "W", "0", "", "");
$bracket_game_numbers[1][11][11] = array("Team 10", "Winner Game 7", "W", "0", "", "W-7");
$bracket_game_numbers[1][11][12] = array("Team 11", "Winner Game 8", "W", "0", "", "W-8");
$bracket_game_numbers[1][11][13] = array("Team 1", "Winner Game 9", "W", "0", "" ,"W-9");
$bracket_game_numbers[1][11][14] = array("Loser Game 7", "Loser Game 8", "L", "11", "L-7" ,"L-8");
$bracket_game_numbers[1][11][15] = array("Loser Game 9", "Loser Game 10", "L", "10", "L-9", "L-10");
$bracket_game_numbers[1][11][16] = array("Winner Game 10", "Winner Game 11", "W", "0", "W-10", "W-11");
$bracket_game_numbers[1][11][17] = array("Loser Game 11", "Loser Game 12", "L", "9", "L-11", "L-12");
$bracket_game_numbers[1][11][18] = array("Winner Game 12", "Winner Game 13", "W", "0", "W-12" ,"W-13");
$bracket_game_numbers[1][11][19] = array("Winner Game 14", "Winner Game 15", "L", "8", "W-14", "W-15");
$bracket_game_numbers[1][11][20] = array("Winner Game 17", "Loser Game 13", "L", "7", "W-17", "L-13");
$bracket_game_numbers[1][11][21] = array("Winner Game 19", "Loser Game 16", "L", "6", "W-19", "L-16");
$bracket_game_numbers[1][11][22] = array("Winner Game 20", "Loser Game 18", "L", "5", "W-20", "L-18");
$bracket_game_numbers[1][11][23] = array("Winner Game 16", "Winner Game 18", "W", "W-16", "W-18");
$bracket_game_numbers[1][11][24] = array("Winner Game 21", "Winner Game 22", "L", "4", "W-21", "W-22");
$bracket_game_numbers[1][11][25] = array("Winner Game 24", "Loser Game 23", "L", "3", "W-24", "L-23");
$bracket_game_numbers[1][11][26] = array("Winner Game 23", "Winner Game 25", "W", "1", "W-23", "W-25");
$bracket_game_numbers[1][11][27] = array("Winner Game 26", "Loser 26 If 1st Loss", "W", "1", "W-26", "L-26");


$bracket_game_numbers[1][12][1] = array("Team 1", "Team 2", "P", "0", "", "");
$bracket_game_numbers[1][12][2] = array("Team 3", "Team 4", "P", "0", "", "");
$bracket_game_numbers[1][12][3] = array("Team 5", "Team 6", "P", "0", "", "");
$bracket_game_numbers[1][12][4] = array("Team 7", "Team 8", "P", "0", "", "");
$bracket_game_numbers[1][12][5] = array("Team 9", "Team 10", "P", "0", "", "");
$bracket_game_numbers[1][12][6] = array("Team 11", "Team 12", "P", "0", "", "");
$bracket_game_numbers[1][12][7] = array("Team 1", "Team 4", "W", "0", "", "");
$bracket_game_numbers[1][12][8] = array("Team 2", "Team 3", "W", "0", "", "");
$bracket_game_numbers[1][12][9] = array("Team 5", "Team 8", "W", "0", "", "");
$bracket_game_numbers[1][12][10] = array("Team 6", "Team 7", "W", "0", "", "");
$bracket_game_numbers[1][12][11] = array("Team 9", "Winner Game 7", "W", "0", "", "W-7");
$bracket_game_numbers[1][12][12] = array("Team 10", "Winner Game 8", "W", "0", "", "W-8");
$bracket_game_numbers[1][12][13] = array("Team 11", "Winner Game 9", "W", "0", "", "W-9");
$bracket_game_numbers[1][12][14] = array("Team 12", "Winner Game 10", "W", "0", "", "W-10");
$bracket_game_numbers[1][12][15] = array("Loser Game 7", "Loser Game 8", "L", "12", "L-7", "L-8");
$bracket_game_numbers[1][12][16] = array("Loser Game 9", "Loser Game 10", "L", "11", "L-9", "L-10");
$bracket_game_numbers[1][12][17] = array("Loser Game 11", "Loser Game 12", "L", "10", "L-11", "L-12");
$bracket_game_numbers[1][12][18] = array("Loser Game 13", "Loser Game 14", "L", "9", "L-13", "L-14");
$bracket_game_numbers[1][12][19] = array("Winner Game 11", "Winner Game 12", "W", "0", "W-11", "W-12");
$bracket_game_numbers[1][12][20] = array("Winner Game 13", "Winner Game 14", "W", "0", "W-13", "W-14");
$bracket_game_numbers[1][12][21] = array("Winner Game 15", "Winner Game 16", "L", "8", "W-15", "W-16");
$bracket_game_numbers[1][12][22] = array("Winner Game 17", "Winner Game 18", "L", "7", "W-17", "W-18");
$bracket_game_numbers[1][12][23] = array("Winner Game 21", " Loser Game 19", "L", "6", "W-21", "L-19");
$bracket_game_numbers[1][12][24] = array("Winner Game 22", " Loser Game 20", "L", "5", "W-22", "L-20");
$bracket_game_numbers[1][12][25] = array("Winner Game 19", "Winner Game 20", "W", "0", "W-19", "W-20");
$bracket_game_numbers[1][12][26] = array("Winner Game 23", "Winner Game 24", "L", "4", "W-23", "W-24");
$bracket_game_numbers[1][12][27] = array("Winner Game 26", " Loser Game 25", "L", "3", "W-26", "L-25");
$bracket_game_numbers[1][12][28] = array("Winner Game 25", "Winner Game # 27", "W", "1", "W-25", "W-27");
$bracket_game_numbers[1][12][29] = array("Winner Game 28", "Loser 28 If 1st Loss", "W", "1", "W-28", "L-28");


$bracket_game_numbers[1][13][1] = array("Team 1", "Team 2", "P", "0", "" ,"");
$bracket_game_numbers[1][13][2] = array("Team 3", "Team 4", "P", "0", "", "");
$bracket_game_numbers[1][13][3] = array("Team 5", "Team 6", "P", "0", "", "");
$bracket_game_numbers[1][13][4] = array("Team 7", "Team 8", "P", "0", "", "");
$bracket_game_numbers[1][13][5] = array("Team 9", "Team 10", "P", "0", "", "");
$bracket_game_numbers[1][13][6] = array("Team 11", "Team 12", "P", "0", "", "");
$bracket_game_numbers[1][13][7] = array("Team 13", "Team 1", "P", "0", "", "");
$bracket_game_numbers[1][13][8] = array("Team 2", "Team 3", "W", "0", "", "");
$bracket_game_numbers[1][13][9] = array("Team 4", "Team 5", "W", "0", "", "");
$bracket_game_numbers[1][13][10] = array("Team 6", "Team 7", "W", "0", "", "");
$bracket_game_numbers[1][13][11] = array("Team 8", "Team 9", "W", "0", "", "");
$bracket_game_numbers[1][13][12] = array("Team 10", "Team 11", "W", "0", "","");
$bracket_game_numbers[1][13][13] = array("Team 12", "Winner Game 8", "W", "0", "", "W-8");
$bracket_game_numbers[1][13][14] = array("Team 13", "Winner Game 9", "W", "0", "", "W-9");
$bracket_game_numbers[1][13][15] = array("Team 1", "Winner Game 12", "W", "0", "", "W-12");
$bracket_game_numbers[1][13][16] = array("Winner Game 10", "Winner Game 11", "W", "0", "W-10", "W-11");
$bracket_game_numbers[1][13][17] = array("Loser Game 8", "Loser Game 9", "L", "13", "L-8", "L-9");
$bracket_game_numbers[1][13][18] = array("Loser Game 10", "Loser Game 11", "L", "12", "L-10", "L-11");
$bracket_game_numbers[1][13][19] = array("Loser Game 12", "Loser Game 13", "L", "11", "L-14", "L-13");
$bracket_game_numbers[1][13][20] = array("Loser Game 14", "Loser Game 15", "L", "10", "L-14", "L-15");
$bracket_game_numbers[1][13][21] = array("Loser Game 16", "Winner Game 17", "L", "9", "L-16", "W-17");
$bracket_game_numbers[1][13][22] = array("Winner Game 13", "Winner Game 14", "W", "0", "W-13", "W-14");
$bracket_game_numbers[1][13][23] = array("Winner Game 16", "Winner Game 15", "W", "0", "W-16", "W-15");
$bracket_game_numbers[1][13][24] = array("Winner Game 21", "Winner Game 18", "L", "8", "W-21", "W-18");
$bracket_game_numbers[1][13][25] = array("Winner Game 19", "Winner Game 20", "L", "7", "W-19", "W-20");
$bracket_game_numbers[1][13][26] = array("Winner Game 24", " Loser Game 22", "L", "6", "W-24", "L-22");
$bracket_game_numbers[1][13][27] = array("Winner Game 25", " Loser Game 23", "L", "5", "W-25", "L-23");
$bracket_game_numbers[1][13][28] = array("Winner Game 22", "Winner Game 23", "W", "0", "W-22", "W-23");
$bracket_game_numbers[1][13][29] = array("Winner Game 26", "Winner Game 27", "L", "4", "W-26", "W-27");
$bracket_game_numbers[1][13][30] = array("Winner Game 29", "Loser Game 28", "L", "3",  "W-29", "L-28");
$bracket_game_numbers[1][13][31] = array("Winner Game 28", "Winner Game 30", "W", "1", "W-28", "W-30");
$bracket_game_numbers[1][13][32] = array("Winner Game 31", "Loser 31 If 1st Loss", "W", "1", "W-31", "L-31");


$bracket_game_numbers[1][14][1] = array("Team 1", "Team 2", "P", "0", "", "");
$bracket_game_numbers[1][14][2] = array("Team 3", "Team 4", "P", "0", "", "");
$bracket_game_numbers[1][14][3] = array("Team 5", "Team 6", "P", "0", "", "");
$bracket_game_numbers[1][14][4] = array("Team 7", "Team 8", "P", "0", "", "");
$bracket_game_numbers[1][14][5] = array("Team 9", "Team 10", "P", "0", "", "");
$bracket_game_numbers[1][14][6] = array("Team 11", "Team 12", "P", "0", "", "");
$bracket_game_numbers[1][14][7] = array("Team 13", "Team 14", "P", "0", "", "");
$bracket_game_numbers[1][14][8] = array("Team 1", "Team 4", "W", "0", "", "");
$bracket_game_numbers[1][14][9] = array("Team 2", "Team 3", "W", "0", "", "");
$bracket_game_numbers[1][14][10] = array("Team 5", "Team 8", "W", "0", "" ,"");
$bracket_game_numbers[1][14][11] = array("Team 6", "Team 7", "W", "0", "", "");
$bracket_game_numbers[1][14][12] = array("Team 9", "Team 12", "W", "0", "", "");
$bracket_game_numbers[1][14][13] = array("Team 10", "Team 11", "W", "0", "" ,"");
$bracket_game_numbers[1][14][14] = array("Team 13", "Winner Game 10", "W", "0", "" ,"W-10");
$bracket_game_numbers[1][14][15] = array("Team 14", "Winner Game 13", "W", "0", "", "W-13");
$bracket_game_numbers[1][14][16] = array("Winner Game 8", "Winner Game 9", "W", "0", "W-8", "W-9");
$bracket_game_numbers[1][14][17] = array("Winner Game 11", "Winner Game 12", "W", "0", "W-11", "W-12");
$bracket_game_numbers[1][14][18] = array("Loser Game 8", "Loser Game 9", "L", "14", "L-8" ,"L-9");
$bracket_game_numbers[1][14][19] = array("Loser Game 10", "Loser Game 11", "L", "13", "L-10", "L-11");
$bracket_game_numbers[1][14][20] = array("Loser Game 12", "Loser Game 13", "L", "12", "L-12", "L-13");
$bracket_game_numbers[1][14][21] = array("Loser Game 14", "Loser Game 15", "L", "11", "L-14", "L-15");
$bracket_game_numbers[1][14][22] = array("Winner Game 18", "Loser Game 17", "L", "10", "W-18", "L-17");
$bracket_game_numbers[1][14][23] = array("Winner Game 19", "Loser Game 16", "L", "9", "W-19", "L-16");
$bracket_game_numbers[1][14][24] = array("Winner Game 16", "Winner Game 14", "W", "0", "W-16", "W-14");
$bracket_game_numbers[1][14][25] = array("Winner Game 17", "Winner Game 15", "W", "0", "W-17", "W-15");
$bracket_game_numbers[1][14][26] = array("Winner Game 22", "Winner Game 20", "L", "8", "W-22", "W-20");
$bracket_game_numbers[1][14][27] = array("Winner Game 23", "Winner Game 21", "L", "7", "W-23", "W-21");
$bracket_game_numbers[1][14][28] = array("Winner Game 26", "Loser Game 25", "L", "6", "W-26", "L-25");
$bracket_game_numbers[1][14][29] = array("Winner Game 27", "Loser Game 24", "L", "5", "W-27", "L-24");
$bracket_game_numbers[1][14][30] = array("Winner Game 24", "Winner Game 25", "W", "0", "W-24", "W-25");
$bracket_game_numbers[1][14][31] = array("Winner Game 28", "Winner Game 29", "L", "4", "W-28", "W-29");
$bracket_game_numbers[1][14][32] = array("Winner Game 31", "Loser Game 30", "L", "3", "W-31", "L-30");
$bracket_game_numbers[1][14][33] = array("Winner Game 30", "Winner Game 32", "W", "1", "W-30", "W-32");
$bracket_game_numbers[1][14][34] = array("Winner Game 33", "Loser 33 If 1st Loss", "W", "1", "W-33", "L-33");

// modified on 4.12.11   again replaced on 06.1.12 because it is correct

$bracket_game_numbers[5][3][1] = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[5][3][2] = array("Team 3", "Team 1", "P","","","");
$bracket_game_numbers[5][3][3] = array("Team 2", "Team 3", "P","","","");
$bracket_game_numbers[5][3][4] = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[5][3][5] = array("Team 3", "Team 1", "P","","","");
$bracket_game_numbers[5][3][6] = array("Team 2", "Team 3", "P","","","");
$bracket_game_numbers[5][3][7] = array("#1 Seed", "#2 Seed", "P","","#1","#2");



$bracket_game_numbers[5][4][1] = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[5][4][2] = array("Team 3", "Team 4", "P","","","");
$bracket_game_numbers[5][4][3] = array("Team 2", "Team 3", "P","","","");
$bracket_game_numbers[5][4][4] = array("Team 1", "Team 4", "P","","","");
$bracket_game_numbers[5][4][5] = array("Team 1", "Team 3", "P","","","");
$bracket_game_numbers[5][4][6] = array("Team 2", "Team 4", "P","","","");
$bracket_game_numbers[5][4][7] = array("#1 Seed", "#4 Seed", "W","","#1","#4");
$bracket_game_numbers[5][4][8] = array("#2 Seed", "#3 Seed", "W","","#2","#3");
$bracket_game_numbers[5][4][9] = array("Winner Game 7", "Winner Game 8", "W","","W-7","W-8");


$bracket_game_numbers[5][5][1] = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[5][5][2] = array("Team 3", "Team 4", "P","","","");
$bracket_game_numbers[5][5][3] = array("Team 5", "Team 1", "P","","","");
$bracket_game_numbers[5][5][4] = array("Team 2", "Team 3", "P","","","");
$bracket_game_numbers[5][5][5] = array("Team 4", "Team 5", "P","","","");
$bracket_game_numbers[5][5][6] = array("Team 1", "Team 3", "P","","","");
$bracket_game_numbers[5][5][7] = array("Team 2", "Team 4", "P","","","");
$bracket_game_numbers[5][5][8] = array("Team 5", "Team 3", "P","","","");
$bracket_game_numbers[5][5][9] = array("Team 4", "Team 1", "P","","","");
$bracket_game_numbers[5][5][10] = array("Team 2", "Team 5", "P","","","");
$bracket_game_numbers[5][5][11] = array("Number 1", "Number 2", "W","","N-1","N-2");


$bracket_game_numbers[5][6][1] = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[5][6][2] = array("Team 3", "Team 4", "P","","","");
$bracket_game_numbers[5][6][3] = array("Team 5", "Team 6", "P","","","");
$bracket_game_numbers[5][6][4] = array("Team 4", "Team 1", "P","","","");
$bracket_game_numbers[5][6][5] = array("Team 2", "Team 5", "P","","","");
$bracket_game_numbers[5][6][6] = array("Team 6", "Team 3", "P","","","");
$bracket_game_numbers[5][6][7] = array("Team 1", "Team 5", "P","","","");
$bracket_game_numbers[5][6][8] = array("Team 4", "Team 6", "P","","","");
$bracket_game_numbers[5][6][9] = array("Team 3", "Team 2", "P","","","");
$bracket_game_numbers[5][6][10] = array("Team 6", "Team 1", "P","","","");
$bracket_game_numbers[5][6][11] = array("Team 5", "Team 3", "P","","","");
$bracket_game_numbers[5][6][12] = array("Team 2", "Team 4", "P","","","");
$bracket_game_numbers[5][6][13] = array("Number 1", "Number 2", "W","","N-1","N-2");


$bracket_game_numbers[5][7][1] = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[5][7][2] = array("Team 3", "Team 4", "P","","","");
$bracket_game_numbers[5][7][3] = array("Team 5", "Team 6", "P","","","");
$bracket_game_numbers[5][7][4] = array("Team 7", "Team 1", "P","","","");
$bracket_game_numbers[5][7][5] = array("Team 2", "Team 3", "P","","","");
$bracket_game_numbers[5][7][6]= array("Team 4", "Team 5", "P","","","");
$bracket_game_numbers[5][7][7] = array("Team 6", "Team 7", "P","","","");
$bracket_game_numbers[5][7][8] = array("Team 1", "Team 3", "P","","","");
$bracket_game_numbers[5][7][9] = array("Team 2", "Team 4", "P","","","");
$bracket_game_numbers[5][7][10] = array("Team 5", "Team 7", "P","","","");
$bracket_game_numbers[5][7][11] = array("Team 3", "Team 6", "P","","","");
$bracket_game_numbers[5][7][12] = array("Team 1", "Team 5", "P","","","");
$bracket_game_numbers[5][7][13] = array("Team 4", "Team 7", "P","","","");
$bracket_game_numbers[5][7][14] = array("Team 6", "Team 2", "P","","","");
$bracket_game_numbers[5][7][15] = array("Number 1", "Number 2", "W","","N-1","N-2");


$bracket_game_numbers[5][8][1] = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[5][8][2] = array("Team 3", "Team 4", "P","","","");
$bracket_game_numbers[5][8][3] = array("Team 5", "Team 6", "P","","","");
$bracket_game_numbers[5][8][4] = array("Team 7", "Team 8", "P","","","");
$bracket_game_numbers[5][8][5] = array("Team 2", "Team 3", "P","","","");
$bracket_game_numbers[5][8][6]= array("Team 4", "Team 1", "P","","","");
$bracket_game_numbers[5][8][7] = array("Team 6", "Team 7", "P","","","");
$bracket_game_numbers[5][8][8] = array("Team 8", "Team 5", "P","","","");
$bracket_game_numbers[5][8][9] = array("Team 3", "Team 1", "P","","","");
$bracket_game_numbers[5][8][10] = array("Team 2", "Team 4", "P","","","");
$bracket_game_numbers[5][8][11] = array("Team 7", "Team 5", "P","","","");
$bracket_game_numbers[5][8][12] = array("Team 6", "Team 8", "P","","","");
$bracket_game_numbers[5][8][13] = array("Team 1", "Team 7", "P","","","");
$bracket_game_numbers[5][8][14] = array("Team 5", "Team 3", "P","","","");
$bracket_game_numbers[5][8][15] = array("Team 8", "Team 2", "P","","","");
$bracket_game_numbers[5][8][16] = array("Team 4", "Team 6", "P","","","");
$bracket_game_numbers[5][8][17] = array("Number 1", "Number 2", "W","","N-1","N-2");



$bracket_game_numbers[5][9][1] = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[5][9][2] = array("Team 3", "Team 4", "P","","","");
$bracket_game_numbers[5][9][3] = array("Team 5", "Team 6", "P","","","");
$bracket_game_numbers[5][9][4] = array("Team 7", "Team 8", "P","","","");
$bracket_game_numbers[5][9][5] = array("Team 9", "Team 1", "P","","","");
$bracket_game_numbers[5][9][6] = array("Team 2", "Team 3", "P","","","");
$bracket_game_numbers[5][9][7] = array("Team 4", "Team 5", "P","","","");
$bracket_game_numbers[5][9][8] = array("Team 6", "Team 7", "P","","","");
$bracket_game_numbers[5][9][9] = array("Team 8", "Team 9", "P","","","");
$bracket_game_numbers[5][9][10] = array("Team 1", "Team 3", "P","","","");
$bracket_game_numbers[5][9][11] = array("Team 2", "Team 4", "P","","","");
$bracket_game_numbers[5][9][12] = array("Team 5", "Team 7", "P","","","");
$bracket_game_numbers[5][9][13] = array("Team 6", "Team 8", "P","","","");
$bracket_game_numbers[5][9][14] = array("Team 9", "Team 3", "P","","","");
$bracket_game_numbers[5][9][15] = array("Team 1", "Team 4", "P","","","");
$bracket_game_numbers[5][9][16] = array("Team 2", "Team 6", "P","","","");
$bracket_game_numbers[5][9][17] = array("Team 5", "Team 8", "P","","","");
$bracket_game_numbers[5][9][18] = array("Team 7", "Team 9", "P","","","");
$bracket_game_numbers[5][9][19] = array("Number 1", "Number 2", "W","","N-1","N-2");


$bracket_game_numbers[5][10][1] = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[5][10][2] = array("Team 3", "Team 4", "P","","","");
$bracket_game_numbers[5][10][3] = array("Team 5", "Team 6", "P","","","");
$bracket_game_numbers[5][10][4] = array("Team 7", "Team 8", "P","","","");
$bracket_game_numbers[5][10][5] = array("Team 9", "Team 10", "P","","","");
$bracket_game_numbers[5][10][6]= array("Team 2", "Team 3", "P","","","");
$bracket_game_numbers[5][10][7] = array("Team 4", "Team 1", "P","","","");
$bracket_game_numbers[5][10][8] = array("Team 6", "Team 8", "P","","","");
$bracket_game_numbers[5][10][9] = array("Team 5", "Team 9", "P","","","");
$bracket_game_numbers[5][10][10] = array("Team 10", "Team 7", "P","","","");
$bracket_game_numbers[5][10][11] = array("Team 1", "Team 3", "P","","","");
$bracket_game_numbers[5][10][12] = array("Team 2", "Team 4", "P","","","");
$bracket_game_numbers[5][10][13] = array("Team 8", "Team 9", "P","","","");
$bracket_game_numbers[5][10][14] = array("Team 7", "Team 5", "P","","","");
$bracket_game_numbers[5][10][15] = array("Team 6", "Team 10", "P","","","");
$bracket_game_numbers[5][10][16] = array("Team 3", "Team 8", "P","","","");
$bracket_game_numbers[5][10][17] = array("Team 9", "Team 1", "P","","","");
$bracket_game_numbers[5][10][18] = array("Team 4", "Team 7", "P","","","");
$bracket_game_numbers[5][10][19] = array("Team 2", "Team 6", "P","","","");
$bracket_game_numbers[5][10][20] = array("Team 5", "Team 10", "P","","","");
$bracket_game_numbers[5][10][21] = array("Number 1", "Number 2", "W","","N-1","N-2");


$bracket_game_numbers[5][11][1] = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[5][11][2] = array("Team 3", "Team 4", "P","","","");
$bracket_game_numbers[5][11][3] = array("Team 5", "Team 6", "P","","","");
$bracket_game_numbers[5][11][4] = array("Team 7", "Team 8", "P","","","");
$bracket_game_numbers[5][11][5] = array("Team 9", "Team 10", "P","","","");
$bracket_game_numbers[5][11][6]= array("Team 11", "Team 1", "P","","","");
$bracket_game_numbers[5][11][7] = array("Team 2", "Team 3", "P","","","");
$bracket_game_numbers[5][11][8] = array("Team 4", "Team 5", "P","","","");
$bracket_game_numbers[5][11][9] = array("Team 6", "Team 7", "P","","","");
$bracket_game_numbers[5][11][10] = array("Team 8", "Team 9", "P","","","");
$bracket_game_numbers[5][11][11] = array("Team 10", "Team 11", "P","","","");
$bracket_game_numbers[5][11][12] = array("Team 1", "Team 3", "P","","","");
$bracket_game_numbers[5][11][13] = array("Team 2", "Team 4", "P","","","");
$bracket_game_numbers[5][11][14] = array("Team 3", "Team 5", "P","","","");
$bracket_game_numbers[5][11][15] = array("Team 6", "Team 8", "P","","","");
$bracket_game_numbers[5][11][16] = array("Team 9", "Team 11", "P","","","");
$bracket_game_numbers[5][11][17] = array("Team 3", "Team 10", "P","","","");
$bracket_game_numbers[5][11][18] = array("Team 4", "Team 1", "P","","","");
$bracket_game_numbers[5][11][19] = array("Team 7", "Team 2", "P","","","");
$bracket_game_numbers[5][11][20] = array("Team 9", "Team 5", "P","","","");
$bracket_game_numbers[5][11][21] = array("Team 10", "Team 6", "P","","","");
$bracket_game_numbers[5][11][22] = array("Team 8", "Team 11", "P","","","");
$bracket_game_numbers[5][11][23] = array("Number 1", "Number 2", "W","","N-1","N-2");


$bracket_game_numbers[5][12][1] = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[5][12][2] = array("Team 3", "Team 4", "P","","","");
$bracket_game_numbers[5][12][3] = array("Team 5", "Team 6", "P","","","");
$bracket_game_numbers[5][12][4] = array("Team 7", "Team 8", "P","","","");
$bracket_game_numbers[5][12][5] = array("Team 9", "Team 10", "P","","","");
$bracket_game_numbers[5][12][6]= array("Team 11", "Team 12", "P","","","");
$bracket_game_numbers[5][12][7] = array("Team 4", "Team 1", "P","","","");
$bracket_game_numbers[5][12][8] = array("Team 2", "Team 3", "P","","","");
$bracket_game_numbers[5][12][9] = array("Team 8", "Team 5", "P","","","");
$bracket_game_numbers[5][12][10] = array("Team 6", "Team 7", "P","","","");
$bracket_game_numbers[5][12][11] = array("Team 12", "Team 9", "P","","","");
$bracket_game_numbers[5][12][12] = array("Team 10", "Team 11", "P","","","");
$bracket_game_numbers[5][12][13] = array("Team 1", "Team 3", "P","","","");
$bracket_game_numbers[5][12][14] = array("Team 2", "Team 4", "P","","","");
$bracket_game_numbers[5][12][15] = array("Team 5", "Team 7", "P","","","");
$bracket_game_numbers[5][12][16] = array("Team 6", "Team 8", "P","","","");
$bracket_game_numbers[5][12][17] = array("Team 9", "Team 11", "P","","","");
$bracket_game_numbers[5][12][18] = array("Team 10", "Team 12", "P","","","");
$bracket_game_numbers[5][12][19] = array("Team 7", "Team 1", "P","","","");
$bracket_game_numbers[5][12][20] = array("Team 3", "Team 5", "P","","","");
$bracket_game_numbers[5][12][21] = array("Team 11", "Team 2", "P","","","");
$bracket_game_numbers[5][12][22] = array("Team 10", "Team 4", "P","","","");
$bracket_game_numbers[5][12][23] = array("Team 6", "Team 9", "P","","","");
$bracket_game_numbers[5][12][24] = array("Team 8", "Team 12", "P","","","");
$bracket_game_numbers[5][12][25] = array("Number 1", "Number 2", "W","","N-1","N-2");











$bracket_game_numbers[6][4][1] = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[6][4][2] = array("Team 3", "Team 4", "P","","","");
$bracket_game_numbers[6][4][3] = array("Team 2", "Team 3", "P","","","");
$bracket_game_numbers[6][4][4] = array("Team 4", "Team 1", "P","","","");
$bracket_game_numbers[6][4][5] = array("Team 1", "Team 3", "P","","","");
$bracket_game_numbers[6][4][6]= array("Team 2", "Team 4", "P","","","");
$bracket_game_numbers[6][4][7] = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[6][4][8] =array("Team 2", "Team 3", "P","","","");
$bracket_game_numbers[6][4][9] = array("Team 3", "Team 4", "P","","","");
$bracket_game_numbers[6][4][10] =  array("Team 4", "Team 1", "P","","","");
$bracket_game_numbers[6][4][11] = array("Number 1", "Number 2", "W","","N-1","N-2");

$bracket_game_numbers[6][5][1] = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[6][5][2] = array("Team 3", "Team 4", "P","","","");
$bracket_game_numbers[6][5][3] = array("Team 5", "Team 1", "P","","","");
$bracket_game_numbers[6][5][4] = array("Team 2", "Team 3", "P","","","");
$bracket_game_numbers[6][5][5] = array("Team 4", "Team 5", "P","","","");
$bracket_game_numbers[6][5][6]= array("Team 1", "Team 3", "P","","","");
$bracket_game_numbers[6][5][7] = array("Team 2", "Team 4", "P","","","");
$bracket_game_numbers[6][5][8] =array("Team 5", "Team 3", "P","","","");
$bracket_game_numbers[6][5][9] = array("Team 4", "Team 1", "P","","","");
$bracket_game_numbers[6][5][10] =  array("Team 2", "Team 5", "P","","","");
$bracket_game_numbers[6][5][11] = array("#3 Seed", "#4 Seed", "W","","#3","#4");
$bracket_game_numbers[6][5][12] =  array("#2 Seed", "#5 Seed", "W","","#2","#5");
$bracket_game_numbers[6][5][13] = array("#1 Seed", "Winner Game 11", "W","","#1","W-11");
$bracket_game_numbers[6][5][14] = array("Winner Game 12", "Winner Game 13", "W","","W-12","W-13");


$bracket_game_numbers[6][6][1]  = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[6][6][2]  = array("Team 3", "Team 4", "P","","","");
$bracket_game_numbers[6][6][3]  = array("Team 5", "Team 6", "P","","","");
$bracket_game_numbers[6][6][4]  = array("Team 4", "Team 1", "P","","","");
$bracket_game_numbers[6][6][5]  = array("Team 2", "Team 5", "P","","","");
$bracket_game_numbers[6][6][6]  = array("Team 6", "Team 3", "P","","","");
$bracket_game_numbers[6][6][7]  = array("Team 1", "Team 5", "P","","","");
$bracket_game_numbers[6][6][8]  = array("Team 4", "Team 6", "P","","","");
$bracket_game_numbers[6][6][9]  = array("Team 3", "Team 2", "P","","","");
$bracket_game_numbers[6][6][10] = array("Team 6", "Team 1", "P","","","");
$bracket_game_numbers[6][6][11] = array("Team 5", "Team 3", "P","","","");
$bracket_game_numbers[6][6][12] = array("Team 2", "Team 4", "P","","","");
$bracket_game_numbers[6][6][13] = array("Team 1", "Team 3", "P","","","");
$bracket_game_numbers[6][6][14] = array("Team 6", "Team 2", "P","","","");
$bracket_game_numbers[6][6][15] = array("Team 4", "Team 5", "P","","","");
$bracket_game_numbers[6][6][16] = array("Number 1", "Number 2", "W","","N-1","N-2");



$bracket_game_numbers[6][7][1]  = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[6][7][2]  = array("Team 3", "Team 4", "P","","","");
$bracket_game_numbers[6][7][3]  = array("Team 5", "Team 6", "P","","","");
$bracket_game_numbers[6][7][4]  = array("Team 7", "Team 1", "P","","","");
$bracket_game_numbers[6][7][5]  = array("Team 2", "Team 3", "P","","","");
$bracket_game_numbers[6][7][6]  = array("Team 4", "Team 5", "P","","","");
$bracket_game_numbers[6][7][7]  = array("Team 6", "Team 7", "P","","","");
$bracket_game_numbers[6][7][8]  = array("Team 1", "Team 3", "P","","","");
$bracket_game_numbers[6][7][9]  = array("Team 2", "Team 4", "P","","","");
$bracket_game_numbers[6][7][10] = array("Team 5", "Team 7", "P","","","");
$bracket_game_numbers[6][7][11] = array("Team 3", "Team 6", "P","","","");
$bracket_game_numbers[6][7][12] = array("Team 1", "Team 5", "P","","","");
$bracket_game_numbers[6][7][13] = array("Team 4", "Team 7", "P","","","");
$bracket_game_numbers[6][7][14] = array("Team 6", "Team 2", "P","","","");
$bracket_game_numbers[6][7][15] = array("#4 Seed", "#5 Seed", "W","","#4","#5");
$bracket_game_numbers[6][7][16] = array("#3 Seed", "#6 Seed", "W","","#3","#6");
$bracket_game_numbers[6][7][17] = array("#2 Seed", "#7 Seed", "W","","#2","#7");
$bracket_game_numbers[6][7][18] = array("#1 Seed", "Winner Game 15", "W","","#1","W-15");
$bracket_game_numbers[6][7][19] = array("Winner Game 16", "Winner Game 17", "W","","W-16","W-17");
$bracket_game_numbers[6][7][20] = array("Winner Game 18", "Winner Game 19", "W","","W-18","W-19");


$bracket_game_numbers[6][8][1]  = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[6][8][2]  = array("Team 3", "Team 4", "P","","","");
$bracket_game_numbers[6][8][3]  = array("Team 5", "Team 6", "P","","","");
$bracket_game_numbers[6][8][4]  = array("Team 7", "Team 8", "P","","","");
$bracket_game_numbers[6][8][5]  = array("Team 2", "Team 3", "P","","","");
$bracket_game_numbers[6][8][6]  = array("Team 4", "Team 1", "P","","","");
$bracket_game_numbers[6][8][7]  = array("Team 6", "Team 7", "P","","","");
$bracket_game_numbers[6][8][8]  = array("Team 8", "Team 5", "P","","","");
$bracket_game_numbers[6][8][9]  = array("Team 3", "Team 1", "P","","","");
$bracket_game_numbers[6][8][10] = array("Team 2", "Team 4", "P","","","");
$bracket_game_numbers[6][8][11] = array("Team 7", "Team 5", "P","","","");
$bracket_game_numbers[6][8][12] = array("Team 6", "Team 8", "P","","","");
$bracket_game_numbers[6][8][13] = array("Team 1", "Team 7", "P","","","");
$bracket_game_numbers[6][8][14] = array("Team 5", "Team 3", "P","","","");
$bracket_game_numbers[6][8][15] = array("Team 8", "Team 2", "P","","","");
$bracket_game_numbers[6][8][16] = array("Team 4", "Team 6", "P","","","");
$bracket_game_numbers[6][8][17] = array("Team 8", "Team 1", "P","","","");
$bracket_game_numbers[6][8][18] = array("Team 7", "Team 3", "P","","","");
$bracket_game_numbers[6][8][19] = array("Team 5", "Team 4", "P","","","");
$bracket_game_numbers[6][8][20] = array("Team 2", "Team 6", "P","","","");
$bracket_game_numbers[6][8][21] = array("Number 1", "Number 2", "W","","N-1","N-2");


$bracket_game_numbers[6][9][1]  = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[6][9][2]  = array("Team 3", "Team 4", "P","","","");
$bracket_game_numbers[6][9][3]  = array("Team 5", "Team 6", "P","","","");
$bracket_game_numbers[6][9][4]  = array("Team 7", "Team 8", "P","","","");
$bracket_game_numbers[6][9][5]  = array("Team 9", "Team 1", "P","","","");
$bracket_game_numbers[6][9][6]  = array("Team 2", "Team 3", "P","","","");
$bracket_game_numbers[6][9][7]  = array("Team 4", "Team 5", "P","","","");
$bracket_game_numbers[6][9][8]  = array("Team 6", "Team 7", "P","","","");
$bracket_game_numbers[6][9][9]  = array("Team 8", "Team 9", "P","","","");
$bracket_game_numbers[6][9][10] = array("Team 1", "Team 3", "P","","","");
$bracket_game_numbers[6][9][11] = array("Team 2", "Team 4", "P","","","");
$bracket_game_numbers[6][9][12] = array("Team 5", "Team 7", "P","","","");
$bracket_game_numbers[6][9][13] = array("Team 6", "Team 8", "P","","","");
$bracket_game_numbers[6][9][14] = array("Team 9", "Team 3", "P","","","");
$bracket_game_numbers[6][9][15] = array("Team 1", "Team 4", "P","","","");
$bracket_game_numbers[6][9][16] = array("Team 2", "Team 6", "P","","","");
$bracket_game_numbers[6][9][17] = array("Team 5", "Team 8", "P","","","");
$bracket_game_numbers[6][9][18] = array("Team 7", "Team 9", "P","","","");
$bracket_game_numbers[6][9][19] = array("#5 Seed", "#6 Seed", "W","","#5","#6");
$bracket_game_numbers[6][9][20] = array("#3 Seed", "#8 Seed", "W","","#3","#8");
$bracket_game_numbers[6][9][21] = array("#2 Seed", "#9 Seed", "W","","#2","#9");
$bracket_game_numbers[6][9][22] = array("#4 Seed", "#7 Seed", "W","","#4","#7");
$bracket_game_numbers[6][9][23] = array("#1 Seed", "Winner Game 19", "W","","#1","W-19");
$bracket_game_numbers[6][9][24] = array("Winner Game 20", "Winner Game 21", "W","","W-20","W-21");
$bracket_game_numbers[6][9][25] = array("Winner Game 22", "Winner Game 23", "W","","W-22","W-23");
$bracket_game_numbers[6][9][26] = array("Winner Game 24", "Winner Game 25", "W","","W-24","W-25");


$bracket_game_numbers[6][10][1]  = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[6][10][2]  = array("Team 3", "Team 4", "P","","","");
$bracket_game_numbers[6][10][3]  = array("Team 5", "Team 6", "P","","","");
$bracket_game_numbers[6][10][4]  = array("Team 7", "Team 8", "P","","","");
$bracket_game_numbers[6][10][5]  = array("Team 9", "Team 10", "P","","","");
$bracket_game_numbers[6][10][6]  = array("Team 2", "Team 3", "P","","","");
$bracket_game_numbers[6][10][7]  = array("Team 4", "Team 1", "P","","","");
$bracket_game_numbers[6][10][8]  = array("Team 6", "Team 8", "P","","","");
$bracket_game_numbers[6][10][9]  = array("Team 5", "Team 9", "P","","","");
$bracket_game_numbers[6][10][10] = array("Team 10", "Team 7", "P","","","");
$bracket_game_numbers[6][10][11] = array("Team 1", "Team 3", "P","","","");
$bracket_game_numbers[6][10][12] = array("Team 2", "Team 4", "P","","","");
$bracket_game_numbers[6][10][13] = array("Team 8", "Team 9", "P","","","");
$bracket_game_numbers[6][10][14] = array("Team 7", "Team 5", "P","","","");
$bracket_game_numbers[6][10][15] = array("Team 6", "Team 10", "P","","","");
$bracket_game_numbers[6][10][16] = array("Team 3", "Team 8", "P","","","");
$bracket_game_numbers[6][10][17] = array("Team 9", "Team 1", "P","","","");
$bracket_game_numbers[6][10][18] = array("Team 4", "Team 7", "P","","","");
$bracket_game_numbers[6][10][19] = array("Team 2", "Team 6", "P","","","");
$bracket_game_numbers[6][10][20] = array("Team 5", "Team 10", "P","","","");
$bracket_game_numbers[6][10][21] = array("Team 1", "Team 8", "P","","","");
$bracket_game_numbers[6][10][22] = array("Team 7", "Team 3", "P","","","");
$bracket_game_numbers[6][10][23] = array("Team 6", "Team 4", "P","","","");
$bracket_game_numbers[6][10][24] = array("Team 5", "Team 9", "P","","","");
$bracket_game_numbers[6][10][25] = array("Team 10", "Team 2", "P","","","");
$bracket_game_numbers[6][10][26] = array("Number 1", "Number 2", "W","","N-1","N-2");



$bracket_game_numbers[6][11][1]  = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[6][11][2]  = array("Team 3", "Team 4", "P","","","");
$bracket_game_numbers[6][11][3]  = array("Team 5", "Team 6", "P","","","");
$bracket_game_numbers[6][11][4]  = array("Team 7", "Team 8", "P","","","");
$bracket_game_numbers[6][11][5]  = array("Team 9", "Team 10", "P","","","");
$bracket_game_numbers[6][11][6]  = array("Team 11", "Team 1", "P","","","");
$bracket_game_numbers[6][11][7]  = array("Team 2", "Team 3", "P","","","");
$bracket_game_numbers[6][11][8]  = array("Team 4", "Team 5", "P","","","");
$bracket_game_numbers[6][11][9]  = array("Team 6", "Team 7", "P","","","");
$bracket_game_numbers[6][11][10] = array("Team 8", "Team 9", "P","","","");
$bracket_game_numbers[6][11][11] = array("Team 10", "Team 11", "P","","","");
$bracket_game_numbers[6][11][12] = array("Team 1", "Team 3", "P","","","");
$bracket_game_numbers[6][11][13] = array("Team 2", "Team 4", "P","","","");
$bracket_game_numbers[6][11][14] = array("Team 5", "Team 7", "P","","","");
$bracket_game_numbers[6][11][15] = array("Team 6", "Team 8", "P","","","");
$bracket_game_numbers[6][11][16] = array("Team 9", "Team 11", "P","","","");
$bracket_game_numbers[6][11][17] = array("Team 3", "Team 10", "P","","","");
$bracket_game_numbers[6][11][18] = array("Team 4", "Team 1", "P","","","");
$bracket_game_numbers[6][11][19] = array("Team 7", "Team 2", "P","","","");
$bracket_game_numbers[6][11][20] = array("Team 9", "Team 5", "P","","","");
$bracket_game_numbers[6][11][21] = array("Team 10", "Team 6", "P","","","");
$bracket_game_numbers[6][11][22] = array("Team 8", "Team 11", "P","","","");
$bracket_game_numbers[6][11][23] = array("#7 Seed", "#8 Seed", "W","","#7","#8");
$bracket_game_numbers[6][11][24] = array("#4 Seed", "#11 Seed", "W","","#4","#11");
$bracket_game_numbers[6][11][25] = array("#6 Seed", "#9 Seed", "W","","#6","#9");
$bracket_game_numbers[6][11][26] = array("#5 Seed", "#10 Seed", "W","","#5","#10");
$bracket_game_numbers[6][11][27] = array("#1 Seed", "Winner Game 23", "W","","#1","W-23");
$bracket_game_numbers[6][11][28] = array("#3 Seed", "Winner Game 24", "W","","#3","W-24");
$bracket_game_numbers[6][11][29] = array("#2 Seed", "Winner Game 25", "W","","#2","W-25");
$bracket_game_numbers[6][11][30] = array("Winner Game 26", "Winner Game 27", "W","","W-26","W-27");
$bracket_game_numbers[6][11][31] = array("Winner Game 28", "Winner Game 29", "W","","W-28","W-29");
$bracket_game_numbers[6][11][32] = array("Winner Game 30", "Winner Game 31", "W","","W-30","W-31");


$bracket_game_numbers[6][12][1]  = array("Team 1", "Team 2", "P","","","");
$bracket_game_numbers[6][12][2]  = array("Team 3", "Team 4", "P","","","");
$bracket_game_numbers[6][12][3]  = array("Team 5", "Team 6", "P","","","");
$bracket_game_numbers[6][12][4]  = array("Team 7", "Team 8", "P","","","");
$bracket_game_numbers[6][12][5]  = array("Team 9", "Team 10", "P","","","");
$bracket_game_numbers[6][12][6]  = array("Team 11", "Team 12", "P","","","");
$bracket_game_numbers[6][12][7]  = array("Team 4", "Team 1", "P","","","");
$bracket_game_numbers[6][12][8]  = array("Team 2", "Team 3", "P","","","");
$bracket_game_numbers[6][12][9]  = array("Team 8", "Team 5", "P","","","");
$bracket_game_numbers[6][12][10] = array("Team 6", "Team 7", "P","","","");
$bracket_game_numbers[6][12][11] = array("Team 12", "Team 9", "P","","","");
$bracket_game_numbers[6][12][12] = array("Team 10", "Team 11", "P","","","");
$bracket_game_numbers[6][12][13] = array("Team 1", "Team 3", "P","","","");
$bracket_game_numbers[6][12][14] = array("Team 2", "Team 4", "P","","","");
$bracket_game_numbers[6][12][15] = array("Team 5", "Team 7", "P","","","");
$bracket_game_numbers[6][12][16] = array("Team 6", "Team 8", "P","","","");
$bracket_game_numbers[6][12][17] = array("Team 9", "Team 11", "P","","","");
$bracket_game_numbers[6][12][18] = array("Team 10", "Team 12", "P","","","");
$bracket_game_numbers[6][12][19] = array("Team 7", "Team 1", "P","","","");
$bracket_game_numbers[6][12][20] = array("Team 3", "Team 5", "P","","","");
$bracket_game_numbers[6][12][21] = array("Team 11", "Team 2", "P","","","");
$bracket_game_numbers[6][12][22] = array("Team 10", "Team 4", "P","","","");
$bracket_game_numbers[6][12][23] = array("Team 6", "Team 9", "P","","","");
$bracket_game_numbers[6][12][24] = array("Team 8", "Team 12", "P","","","");
$bracket_game_numbers[6][12][25] = array("Number 1", "Number 2", "W","","N-1","N-2");











$bracket_game_numbers[7][3][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[7][3][2] = array("Team 3", "Team 1", "P", "", "", "");
$bracket_game_numbers[7][3][3] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[7][3][4] = array("#2 Seed", "#3 Seed", "W", "", "#2", "#3");
$bracket_game_numbers[7][3][5] = array("#1 Seed", "Winner Game 4", "", "W", "#1", "W-4");


$bracket_game_numbers[7][4][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[7][4][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[7][4][3] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[7][4][4] = array("Team 4", "Team 1", "P", "", "", "");
$bracket_game_numbers[7][4][5] = array("#1 Seed", "#4 Seed", "W", "", "#1", "#4");
$bracket_game_numbers[7][4][6] = array("#2 Seed", "#3 Seed", "W", "", "#2", "#3");
$bracket_game_numbers[7][4][7] = array("Winner Game 5", "Winner Game 6", "W", "", "W-5", "W-6");


$bracket_game_numbers[7][5][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[7][5][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[7][5][3] = array("Team 5", "Team 1", "P", "", "", "");
$bracket_game_numbers[7][5][4] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[7][5][5] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[7][5][6] = array("#4 Seed", "#5 Seed", "W", "", "#4", "#5");
$bracket_game_numbers[7][5][7] = array("#1 Seed", "Winner Game 6", "W", "", "#1", "W-6");
$bracket_game_numbers[7][5][8] = array("#2 Seed", "#3 Seed", "W", "", "#2", "#3");
$bracket_game_numbers[7][5][9] = array("Winner Game 7", "Winner Game 8", "W", "", "W-7", "W-8");


$bracket_game_numbers[7][6][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[7][6][2] = array("Team 3", "Team 1", "P", "", "", "");
$bracket_game_numbers[7][6][3] = array("Team 2", "Team 4", "P", "", "", "");
$bracket_game_numbers[7][6][4] = array("Team 5", "Team 3", "P", "", "", "");
$bracket_game_numbers[7][6][5] = array("Team 6", "Team 5", "P", "", "", "");
$bracket_game_numbers[7][6][6] = array("Team 4", "Team 6", "P", "", "", "");
$bracket_game_numbers[7][6][7] = array("#4 Seed", "#5 Seed", "W", "", "#4", "#5");
$bracket_game_numbers[7][6][8] = array("#3 Seed", "#6 Seed", "W", "", "#3", "#6");
$bracket_game_numbers[7][6][9] = array("#1 Seed", "Winner Game 7", "W", "", "#1", "W-7");
$bracket_game_numbers[7][6][10] = array("#2 Seed", "Winner Game 8", "W", "", "#2", "W-8");
$bracket_game_numbers[7][6][11] = array("Winner Game 9", "Winner Game 10", "W", "", "W-9", "W-10");


$bracket_game_numbers[7][7][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[7][7][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[7][7][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[7][7][4] = array("Team 7", "Team 1", "P", "", "", "");
$bracket_game_numbers[7][7][5] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[7][7][6] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[7][7][7] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[7][7][8] = array("#4 Seed", "#5 Seed", "W", "", "#4", "#5");
$bracket_game_numbers[7][7][9] = array("#3 Seed", "#6 Seed", "W", "", "#3", "#6");
$bracket_game_numbers[7][7][10] = array("#2 Seed", "#7 Seed", "W", "", "#2", "#7");
$bracket_game_numbers[7][7][11] = array("#1 Seed", "Winner Game 8", "W", "", "#1", "W-8");
$bracket_game_numbers[7][7][12] = array("Winner Game 9", "Winner Game 10", "W", "", "W-9", "W-10");
$bracket_game_numbers[7][7][13] = array("Winner Game 11", "Winner Game 12", "W", "", "W-11", "W-12");


$bracket_game_numbers[7][8][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[7][8][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[7][8][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[7][8][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[7][8][5] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[7][8][6] = array("Team 4", "Team 1", "P", "", "", "");
$bracket_game_numbers[7][8][7] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[7][8][8] = array("Team 8", "Team 5", "P", "", "", "");
$bracket_game_numbers[7][8][9] = array("#4 Seed", "#5 Seed", "W", "", "#4", "#5");
$bracket_game_numbers[7][8][10] = array("#1 Seed", "#8 Seed", "W", "", "#1", "#8");
$bracket_game_numbers[7][8][11] = array("#3 Seed", "#6 Seed", "W", "", "#3", "#6");
$bracket_game_numbers[7][8][12] = array("#2 Seed", "#7 Seed", "W", "", "#2", "#7");
$bracket_game_numbers[7][8][13] = array("Winner Game 9", "Winner Game 10", "W", "", "W-9", "W-10");
$bracket_game_numbers[7][8][14] = array("Winner Game 11", "Winner Game 12", "W", "", "W-11", "W-12");
$bracket_game_numbers[7][8][15] = array("Winner Game 13", "Winner Game 14", "W", "", "W-13", "W-14");


$bracket_game_numbers[7][9][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[7][9][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[7][9][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[7][9][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[7][9][5] = array("Team 9", "Team 1", "P", "", "", "");
$bracket_game_numbers[7][9][6] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[7][9][7] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[7][9][8] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[7][9][9] = array("Team 8", "Team 9", "P", "", "", "");
$bracket_game_numbers[7][9][10] = array("#6 Seed", "#7 Seed", "W", "", "#6", "#7");
$bracket_game_numbers[7][9][11] = array("#5 Seed", "#8 Seed", "W", "", "#5", "#8");
$bracket_game_numbers[7][9][12] = array("#4 Seed", "#9 Seed", "W", "", "#4", "#9");
$bracket_game_numbers[7][9][13] = array("#2 Seed", "Winner Game 11", "W", "", "#2", "W-11");
$bracket_game_numbers[7][9][14] = array("#3 Seed", "Winner Game 12", "W", "", "#3", "W-12");
$bracket_game_numbers[7][9][15] = array("#1 Seed", "Winner Game 10", "W", "", "#1", "W-10");
$bracket_game_numbers[7][9][16] = array("Winner Game 13", "Winner Game 14", "W", "", "W-13", "W-14");
$bracket_game_numbers[7][9][17] = array("Winner Game 15", "Winner Game 16", "W", "", "W-15", "W-16");


$bracket_game_numbers[7][10][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[7][10][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[7][10][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[7][10][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[7][10][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[7][10][6] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[7][10][7] = array("Team 4", "Team 1", "P", "", "", "");
$bracket_game_numbers[7][10][8] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[7][10][9] = array("Team 5", "Team 9", "P", "", "", "");
$bracket_game_numbers[7][10][10] = array("Team 8", "Team 10", "P", "", "", "");
$bracket_game_numbers[7][10][11] = array("#5 Seed", "#6 Seed", "W", "", "#5", "#6");
$bracket_game_numbers[7][10][12] = array("#4 Seed", "#7 Seed", "W", "", "#4", "#7");
$bracket_game_numbers[7][10][13] = array("#3 Seed", "#8 Seed", "W", "", "#3", "#8");
$bracket_game_numbers[7][10][14] = array("#2 Seed", "#9 Seed", "W", "", "#2", "#9");
$bracket_game_numbers[7][10][15] = array("#1 Seed", "#10 Seed", "W", "", "#1", "#10");
$bracket_game_numbers[7][10][16] = array("Winner Game 11", "Winner Game 12", "W", "", "W-11", "W-12");
$bracket_game_numbers[7][10][17] = array("Winner Game 13", "Winner Game 14", "W", "", "W-13", "W-14");
$bracket_game_numbers[7][10][18] = array("Winner Game 15", "Winner Game 16", "W", "", "W-15", "W-16");
$bracket_game_numbers[7][10][19] = array("Winner Game 17", "Winner Game 18", "W", "", "W-17", "W-18");


$bracket_game_numbers[7][11][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[7][11][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[7][11][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[7][11][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[7][11][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[7][11][6] = array("Team 11", "Team 1", "P", "", "", "");
$bracket_game_numbers[7][11][7] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[7][11][8] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[7][11][9] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[7][11][10] = array("Team 8", "Team 9", "P", "", "", "");
$bracket_game_numbers[7][11][11] = array("Team 10", "Team 11", "P", "", "", "");
$bracket_game_numbers[7][11][12] = array("#6 Seed", "#7 Seed", "W", "", "#6", "#7");
$bracket_game_numbers[7][11][13] = array("#5 Seed", "#8 Seed", "W", "", "#5", "#8");
$bracket_game_numbers[7][11][14] = array("#4 Seed", "#9 Seed", "W", "", "#4" ,"#9");
$bracket_game_numbers[7][11][15] = array("#3 Seed", "#10 Seed", "W", "", "#3", "#10");
$bracket_game_numbers[7][11][16] = array("#2 Seed", "#11 Seed", "W", "", "#2", "#11");
$bracket_game_numbers[7][11][17] = array("#1 Seed", "Winner Game 12", "W", "", "#1", "W-12");
$bracket_game_numbers[7][11][18] = array("Winner Game 13", "Winner Game 14", "W", "", "W-13", "W-14");
$bracket_game_numbers[7][11][19] = array("Winner Game 15", "Winner Game 16", "W", "", "W-15", "W-16");
$bracket_game_numbers[7][11][20] = array("Winner Game 17", "Winner Game 18", "W", "", "W-17", "W-18");
$bracket_game_numbers[7][11][21] = array("Winner Game 19", "Winner Game 20", "W", "", "W-19", "W-20");


$bracket_game_numbers[7][12][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[7][12][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[7][12][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[7][12][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[7][12][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[7][12][6] = array("Team 11", "Team 12", "P", "", "", "");
$bracket_game_numbers[7][12][7] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[7][12][8] = array("Team 4", "Team 1", "P", "", "", "");
$bracket_game_numbers[7][12][9] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[7][12][10] = array("Team 8", "Team 5", "P", "", "", "");
$bracket_game_numbers[7][12][11] = array("Team 10", "Team 11", "P", "", "", "");
$bracket_game_numbers[7][12][12] = array("Team 12", "Team 9", "P", "", "", "");
$bracket_game_numbers[7][12][13] = array("#6 Seed", "#7 Seed", "W", "", "#6", "#7");
$bracket_game_numbers[7][12][14] = array("#1 Seed", "#12 Seed", "W", "", "#1", "#12");
$bracket_game_numbers[7][12][15] = array("#5 Seed", "#8 Seed", "W", "", "#5", "%8");
$bracket_game_numbers[7][12][16] = array("#3 Seed", "#10 Seed", "W", "", "#3", "#10");
$bracket_game_numbers[7][12][17] = array("#4 Seed", "#9 Seed", "W", "", "#4", "#9");
$bracket_game_numbers[7][12][18] = array("#2 Seed", "#11 Seed", "W", "", "#2", "#11");
$bracket_game_numbers[7][12][19] = array("Winner Game 15", "Winner Game 16", "W", "", "W-15", "W-16");
$bracket_game_numbers[7][12][20] = array("Winner Game 17", "Winner Game 18", "W", "", "W-17", "W-18");
$bracket_game_numbers[7][12][21] = array("Winner Game 13", "Winner Game 14", "W", "", "W-13", "W-14");
$bracket_game_numbers[7][12][22] = array("Winner Game 19", "Winner Game 20", "W", "", "W-19", "W-20");
$bracket_game_numbers[7][12][23] = array("Winner Game 21", "Winner Game 22", "W", "", "W-21", "W-22");


$bracket_game_numbers[7][13][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[7][13][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[7][13][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[7][13][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[7][13][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[7][13][6] = array("Team 11", "Team 12", "P", "", "", "");
$bracket_game_numbers[7][13][7] = array("Team 13", "Team 1", "P", "", "" ,"");
$bracket_game_numbers[7][13][8] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[7][13][9] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[7][13][10] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[7][13][11] = array("Team 8", "Team 9", "P", "", "", "");
$bracket_game_numbers[7][13][12] = array("Team 10", "Team 11", "P", "", "", "");
$bracket_game_numbers[7][13][13] = array("Team 12", "Team 13", "P", "", "", "");
$bracket_game_numbers[7][13][14] = array("#7 Seed", "#8 Seed", "W", "", "#7", "#8");
$bracket_game_numbers[7][13][15] = array("#6 Seed", "#9 Seed", "W", "", "#6", "#9");
$bracket_game_numbers[7][13][16] = array("#5 Seed", "#10 Seed", "W", "", "#5", "#10");
$bracket_game_numbers[7][13][17] = array("#4 Seed", "#11 Seed", "W", "", "#4", "#11");
$bracket_game_numbers[7][13][18] = array("#3 Seed", "#12 Seed", "W", "", "#3", "#12");
$bracket_game_numbers[7][13][19] = array("#2 Seed", "#13 Seed", "W", "", "#2", "#13");
$bracket_game_numbers[7][13][20] = array("#1 Seed", "Winner Game 14", "W", "", "#1", "W-14");
$bracket_game_numbers[7][13][21] = array("Winner Game 15", "Winner Game 16", "W", "", "W-15", "W-16");
$bracket_game_numbers[7][13][22] = array("Winner Game 17", "Winner Game 18", "W", "", "W-17", "W-18");
$bracket_game_numbers[7][13][23] = array("Winner Game 19", "Winner Game 20", "W", "", "W-19", "W-20");
$bracket_game_numbers[7][13][24] = array("Winner Game 21", "Winner Game 22", "W", "", "W-21", "W-22");
$bracket_game_numbers[7][13][25] = array("Winner Game 23", "Winner Game 24", "W", "", "W-23", "W-24");

$bracket_game_numbers[7][14][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[7][14][2] = array("Team 3", "Team 1", "P", "", "", "");
$bracket_game_numbers[7][14][3] = array("Team 2", "Team 4", "P", "", "", "");
$bracket_game_numbers[7][14][4] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[7][14][5] = array("Team 7", "Team 3", "P", "", "", "");
$bracket_game_numbers[7][14][6] = array("Team 4", "Team 8", "P", "", "", "");
$bracket_game_numbers[7][14][7] = array("Team 9", "Team 5", "P", "", "" ,"");
$bracket_game_numbers[7][14][8] = array("Team 6", "Team 10", "P", "", "", "");
$bracket_game_numbers[7][14][9] = array("Team 11", "Team 7", "P", "", "", "");
$bracket_game_numbers[7][14][10] = array("Team 8", "Team 12", "P", "", "", "");
$bracket_game_numbers[7][14][11] = array("Team 13", "Team 9", "P", "", "", "");
$bracket_game_numbers[7][14][12] = array("Team 10", "Team 14", "P", "", "", "");
$bracket_game_numbers[7][14][13] = array("Team 12", "Team 11", "P", "", "", "");
$bracket_game_numbers[7][14][14] = array("Team 14", "Team 13", "P", "", "", "");
$bracket_game_numbers[7][14][15] = array("#8 Seed", "#9 Seed", "W", "", "#8", "#9");
$bracket_game_numbers[7][14][16] = array("#4 Seed", "#13 Seed", "W", "", "#4", "#13");
$bracket_game_numbers[7][14][17] = array("#5 Seed", "#12 Seed", "W", "", "#5", "#12");
$bracket_game_numbers[7][14][18] = array("#7 Seed", "#10 Seed", "W", "", "#7", "#10");
$bracket_game_numbers[7][14][19] = array("#3 Seed", "#14 Seed", "W", "", "#3", "#14");
$bracket_game_numbers[7][14][20] = array("#6 Seed", "#11 Seed", "W", "", "#6", "#11");
$bracket_game_numbers[7][14][21] = array("#1 Seed", "Winner Game 15", "W", "", "#1", "W-15");
$bracket_game_numbers[7][14][22] = array("#2 Seed", "Winner Game 18", "W", "", "#2", "W-18");
$bracket_game_numbers[7][14][23] = array("Winner Game 16", "Winner Game 17", "W", "", "W-16", "W-17");
$bracket_game_numbers[7][14][24] = array("Winner Game 19", "Winner Game 20", "W", "", "W-19", "W-20");
$bracket_game_numbers[7][14][25] = array("Winner Game 21", "Winner Game 23", "W", "", "W-21", "W-23");
$bracket_game_numbers[7][14][26] = array("Winner Game 22", "Winner Game 24", "W", "", "W-22", "W-24");
$bracket_game_numbers[7][14][27] = array("Winner Game 25", "Winner Game 26", "W", "", "W-25", "W-26");

$bracket_game_numbers[7][15][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[7][15][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[7][15][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[7][15][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[7][15][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[7][15][6] = array("Team 11", "Team 12", "P", "", "", "");
$bracket_game_numbers[7][15][7] = array("Team 13", "Team 14", "P", "", "" ,"");
$bracket_game_numbers[7][15][8] = array("Team 15", "Team 1", "P", "", "", "");
$bracket_game_numbers[7][15][9] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[7][15][10] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[7][15][11] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[7][15][12] = array("Team 8", "Team 9", "P", "", "", "");
$bracket_game_numbers[7][15][13] = array("Team 10", "Team 11", "P", "", "", "");
$bracket_game_numbers[7][15][14] = array("Team 12", "Team 13", "P", "", "", "");
$bracket_game_numbers[7][15][15] = array("Team 14", "Team 15", "W", "", "", "");
$bracket_game_numbers[7][15][16] = array("#8 Seed", "#9 Seed", "W", "", "#8", "#9");
$bracket_game_numbers[7][15][17] = array("#7 Seed", "#10 Seed", "W", "", "#7", "#10");
$bracket_game_numbers[7][15][18] = array("#6 Seed", "#11 Seed", "W", "", "#6", "#11");
$bracket_game_numbers[7][15][19] = array("#5 Seed", "#12 Seed", "W", "", "#5", "#12");
$bracket_game_numbers[7][15][20] = array("#4 Seed", "#13 Seed", "W", "", "#4", "#13");
$bracket_game_numbers[7][15][21] = array("#3 Seed", "#14 Seed", "W", "", "#3", "#14");
$bracket_game_numbers[7][15][22] = array("#2 Seed", "#15 Seed", "W", "", "#2", "#15");
$bracket_game_numbers[7][15][23] = array("#1 Seed", "Winner Game 16", "W", "", "#1", "W-16");
$bracket_game_numbers[7][15][24] = array("Winner Game 17", "Winner Game 21", "W", "", "W-17", "W-21");
$bracket_game_numbers[7][15][25] = array("Winner Game 18", "Winner Game 20", "W", "", "W-18", "W-20");
$bracket_game_numbers[7][15][26] = array("Winner Game 19", "Winner Game 22", "W", "", "W-19", "W-22");
$bracket_game_numbers[7][15][27] = array("Winner Game 23", "Winner Game 24", "W", "", "W-23", "W-24");
$bracket_game_numbers[7][15][28] = array("Winner Game 25", "Winner Game 26", "W", "", "W-25", "W-26");
$bracket_game_numbers[7][15][29] = array("Winner Game 27", "Winner Game 28", "W", "", "W-27", "W-28");


$bracket_game_numbers[7][16][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[7][16][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[7][16][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[7][16][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[7][16][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[7][16][6] = array("Team 11", "Team 12", "P", "", "", "");
$bracket_game_numbers[7][16][7] = array("Team 13", "Team 14", "P", "", "" ,"");
$bracket_game_numbers[7][16][8] = array("Team 15", "Team 16", "P", "", "", "");
$bracket_game_numbers[7][16][9] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[7][16][10] = array("Team 4", "Team 1", "P", "", "", "");
$bracket_game_numbers[7][16][11] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[7][16][12] = array("Team 8", "Team 5", "P", "", "", "");
$bracket_game_numbers[7][16][13] = array("Team 10", "Team 11", "P", "", "", "");
$bracket_game_numbers[7][16][14] = array("Team 12", "Team 9", "P", "", "", "");
$bracket_game_numbers[7][16][15] = array("Team 14", "Team 15", "W", "", "", "");
$bracket_game_numbers[7][16][16] = array("Team 16", "Team 13", "W", "", "", "");
$bracket_game_numbers[7][16][17] = array("#9 Seed", "#10 Seed", "W", "", "#9", "#10");
$bracket_game_numbers[7][16][18] = array("#8 Seed", "#11 Seed", "W", "", "#8", "#11");
$bracket_game_numbers[7][16][19] = array("#7 Seed", "#12 Seed", "W", "", "#7", "#12");
$bracket_game_numbers[7][16][20] = array("#6 Seed", "#13 Seed", "W", "", "#6", "#13");
$bracket_game_numbers[7][16][21] = array("#5 Seed", "#14 Seed", "W", "", "#5", "#14");
$bracket_game_numbers[7][16][22] = array("#4 Seed", "#15 Seed", "W", "", "#4", "#15");
$bracket_game_numbers[7][16][23] = array("#3 Seed", "#16 Seed", "W", "", "#3", "#16");
$bracket_game_numbers[7][16][24] = array("#2 Seed", "Winner Game 18", "W", "", "#2", "W-18");
$bracket_game_numbers[7][16][25] = array("#1 Seed", "Winner Game 17", "W", "", "#1", "W-17");
$bracket_game_numbers[7][16][26] = array("Winner Game 19", "Winner Game 21", "W", "", "W-19", "W-21");
$bracket_game_numbers[7][16][27] = array("Winner Game 20", "Winner Game 23", "W", "", "W-20", "W-23");
$bracket_game_numbers[7][16][28] = array("Winner Game 25", "Winner Game 26", "W", "", "W-25", "W-26");
$bracket_game_numbers[7][16][29] = array("Winner Game 22", "Winner Game 24", "W", "", "W-22", "W-24");
$bracket_game_numbers[7][16][30] = array("Winner Game 27", "Winner Game 28", "W", "", "W-27", "W-28");
$bracket_game_numbers[7][16][31] = array("Winner Game 29", "Winner Game 30", "W", "", "W-29", "W-30");


$bracket_game_numbers[7][17][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[7][17][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[7][17][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[7][17][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[7][17][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[7][17][6] = array("Team 11", "Team 12", "P", "", "", "");
$bracket_game_numbers[7][17][7] = array("Team 13", "Team 14", "P", "", "" ,"");
$bracket_game_numbers[7][17][8] = array("Team 15", "Team 16", "P", "", "", "");
$bracket_game_numbers[7][17][9] = array("Team 17", "Team 1", "P", "", "", "");
$bracket_game_numbers[7][17][10] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[7][17][11] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[7][17][12] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[7][17][13] = array("Team 8", "Team 9", "P", "", "", "");
$bracket_game_numbers[7][17][14] = array("Team 10", "Team 11", "P", "", "", "");
$bracket_game_numbers[7][17][15] = array("Team 12", "Team 13", "W", "", "", "");
$bracket_game_numbers[7][17][16] = array("Team 14", "Team 15", "W", "", "", "");
$bracket_game_numbers[7][17][17] = array("Team 16", "Team 17", "W", "", "", "");
$bracket_game_numbers[7][17][18] = array("#9 Seed", "#10 Seed", "W", "", "#9", "#10");
$bracket_game_numbers[7][17][19] = array("#8 Seed", "#11 Seed", "W", "", "#8", "#11");
$bracket_game_numbers[7][17][20] = array("#7 Seed", "#12 Seed", "W", "", "#7", "#12");
$bracket_game_numbers[7][17][21] = array("#6 Seed", "#13 Seed", "W", "", "#6", "#13");
$bracket_game_numbers[7][17][22] = array("#5 Seed", "#14 Seed", "W", "", "#5", "#14");
$bracket_game_numbers[7][17][23] = array("#4 Seed", "#14 Seed", "W", "", "#4", "#15");
$bracket_game_numbers[7][17][24] = array("#3 Seed", "#16 Seed", "W", "", "#3", "#16");
$bracket_game_numbers[7][17][25] = array("#2 Seed", "#17 Seed", "W", "", "#2", "#17");
$bracket_game_numbers[7][17][26] = array("#1 Seed", "Winner Game 18", "W", "", "#1", "W-18");
$bracket_game_numbers[7][17][27] = array("Winner Game 19", "Winner Game 21", "W", "", "W-19", "W-21");
$bracket_game_numbers[7][17][28] = array("Winner Game 20", "Winner Game 24", "W", "", "W-20", "W-24");
$bracket_game_numbers[7][17][29] = array("Winner Game 22", "Winner Game 25", "W", "", "W-22", "W-25");
$bracket_game_numbers[7][17][30] = array("Winner Game 23", "Winner Game 26", "W", "", "W-23", "W-26");
$bracket_game_numbers[7][17][31] = array("Winner Game 27", "Winner Game 29", "W", "", "W-27", "W-29");
$bracket_game_numbers[7][17][32] = array("Winner Game 28", "Winner Game 30", "W", "", "W-28", "W-30");
$bracket_game_numbers[7][17][33] = array("Winner Game 31", "Winner Game 32", "W", "", "W-31", "W-32");


$bracket_game_numbers[7][18][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[7][18][2] = array("Team 3", "Team 1", "P", "", "", "");
$bracket_game_numbers[7][18][3] = array("Team 2", "Team 4", "P", "", "", "");
$bracket_game_numbers[7][18][4] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[7][18][5] = array("Team 7", "Team 3", "P", "", "", "");
$bracket_game_numbers[7][18][6] = array("Team 4", "Team 8", "P", "", "", "");
$bracket_game_numbers[7][18][7] = array("Team 9", "Team 10", "P", "", "" ,"");
$bracket_game_numbers[7][18][8] = array("Team 8", "Team 5", "P", "", "", "");
$bracket_game_numbers[7][18][9] = array("Team 6", "Team 11", "P", "", "", "");
$bracket_game_numbers[7][18][10] = array("Team 12", "Team 7", "P", "", "", "");
$bracket_game_numbers[7][18][11] = array("Team 13", "Team 9", "P", "", "", "");
$bracket_game_numbers[7][18][12] = array("Team 10", "Team 14", "P", "", "", "");
$bracket_game_numbers[7][18][13] = array("Team 11", "Team 12", "P", "", "", "");
$bracket_game_numbers[7][18][14] = array("Team 15", "Team 13", "P", "", "", "");
$bracket_game_numbers[7][18][15] = array("Team 14", "Team 16", "P", "", "", "");
$bracket_game_numbers[7][18][16] = array("Team 17", "Team 15", "P", "", "", "");
$bracket_game_numbers[7][18][17] = array("Team 16", "Team 18", "P", "", "", "");
$bracket_game_numbers[7][18][18] = array("Team 18", "Team 17", "P", "", "", "");
$bracket_game_numbers[7][18][19] = array("#16 Seed", "#17 Seed", "P", "", "#16", "#17");
$bracket_game_numbers[7][18][20] = array("#15 Seed", "#18 Seed", "P", "", "#15", "#18");
$bracket_game_numbers[7][18][21] = array("#8 Seed", "#9 Seed", "P", "", "#8", "#9");
$bracket_game_numbers[7][18][22] = array("#4 Seed", "#13 Seed", "P", "", "#4", "#13");
$bracket_game_numbers[7][18][23] = array("#5 Seed", "#12 Seed", "P", "", "#5", "#12");
$bracket_game_numbers[7][18][24] = array("#7 Seed", "#10 Seed", "P", "", "#7", "#10");
$bracket_game_numbers[7][18][25] = array("#3 Seed", "#14 Seed", "P", "", "#3", "#14");
$bracket_game_numbers[7][18][26] = array("#6 Seed", "#11 Seed", "W", "", "#6", "#11");
$bracket_game_numbers[7][18][27] = array("#1 Seed", "Winner Game 19", "W", "", "#1", "W-19");
$bracket_game_numbers[7][18][28] = array("#2 Seed", "Winner Game 20", "W", "", "#2", "W-20");
$bracket_game_numbers[7][18][29] = array("Winner Game 21", "Winner Game 27", "W", "", "W-21", "W-27");
$bracket_game_numbers[7][18][30] = array("Winner Game 22", "Winner Game 23", "W", "", "W-22", "W-23");
$bracket_game_numbers[7][18][31] = array("Winner Game 24", "Winner Game 28", "W", "", "W-24", "W-28");
$bracket_game_numbers[7][18][32] = array("Winner Game 25", "Winner Game 26", "W", "", "W-25", "W-26");
$bracket_game_numbers[7][18][33] = array("Winner Game 29", "Winner Game 30", "W", "", "W-29", "W-30");
$bracket_game_numbers[7][18][34] = array("Winner Game 31", "Winner Game 32", "W", "", "W-31", "W-32");
$bracket_game_numbers[7][18][35] = array("Winner Game 33", "Winner Game 34", "W", "", "W-33", "W-34");





//------------------3 Team $ Game Guarntee Braket By Sumit----------------


/*$bracket_game_numbers[9][3][1] = array("Team 1", "Team 2", "P");
$bracket_game_numbers[9][3][2] = array("Team 3", "Team 1", "P");
$bracket_game_numbers[9][3][3] = array("Team 2", "Team 3", "P");
$bracket_game_numbers[9][3][4] = array("Team 1", "Team 2", "P");
$bracket_game_numbers[9][3][5] = array("Team 3", "Team 1", "P");
$bracket_game_numbers[9][3][6] = array("Team 2", "Team 3", "P");
$bracket_game_numbers[9][3][7] = array("#1 Seed", "#2 Seed", "P");*/




//--------------------End-------------------------------------------------

//--------------Team Struture For 3 Game wrap ----------------//

// Start 3 teams
$bracket_game_numbers[8][3][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[8][3][2] = array("Team 3", "Winner Game 1", "P", "", "", "W-1");
$bracket_game_numbers[8][3][3] = array("Loser 1", "Loser 2", "P", "", "L-1", "L-2");
$bracket_game_numbers[8][3][4] = array("Winner Game 2", "Winner Game 4", "P", "", "W-2", "W-4");
$bracket_game_numbers[8][3][5] = array("Winner Game 4", "Loser 4 If 1st Loss", "P", "", "W-4", "L-4");
// end 3 teams
 
// Start 4 teams
$bracket_game_numbers[8][4][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[8][4][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[8][4][3] = array("Loser Game 1", "Loser Game 2", "P", "", "L-1", "L-2");
$bracket_game_numbers[8][4][4] = array("Winner Game 1", "Winner Game 2", "P", "", "W-1", "W-2");
$bracket_game_numbers[8][4][5] = array("Winner Game 3", "Loser Game 4", "P", "", "W-3", "L-4");
$bracket_game_numbers[8][4][6]= array("Winner Game 4", "Winner Game 5", "P", "", "W-4", "W-5");
$bracket_game_numbers[8][4][7] = array("Winner Game 6", "Loser 6 If 1st Loss", "W", "", "W-6", "L-6");
// end 4 teams

//start 5 teams
$bracket_game_numbers[8][5][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[8][5][2] = array("Team 2", "Team 3", "P", "", "" ,"");
$bracket_game_numbers[8][5][3] = array("Team 5", "Winner Game 1", "P", "", "", "W-1");
$bracket_game_numbers[8][5][4] =  array("Loser Game 1", "Loser Game 2", "P", "", "L-1", "L-2");
$bracket_game_numbers[8][5][5] =  array("Winner Game 2", "Winner Game 3", "P", "", "W-2", "W-3");
$bracket_game_numbers[8][5][6]= array("Winner Game 4", "Loser Game 3", "P", "", "W-4", "L-3");
$bracket_game_numbers[8][5][7] = array("Winner Game 6", "Loser Game 5", "P", "", "W-6", "L-5");
$bracket_game_numbers[8][5][8] = array("Winner Game 5", "Winner Game 7", "P", "", "W-5", "W-7");
$bracket_game_numbers[8][5][9]=  array("Winner Game 8", "Loser 8 If 1st Loss", "W", "", "W-8", "L-8");

//end 5 teams


//start 6 teams
$bracket_game_numbers[8][6][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[8][6][2] = array("Team 3", "Team 1", "P", "", "", "");
$bracket_game_numbers[8][6][3] = array("Team 5", "Winner Game 1", "P", "", "", "W-1");
$bracket_game_numbers[8][6][4] = array("Team 6", "Winner Game 2", "P", "", "", "W-2");
$bracket_game_numbers[8][6][5] =array("Loser Game 1", "Loser Game 2", "P", "", "L-1", "L-2");
$bracket_game_numbers[8][6][6]= array("Loser Game 3", "Loser Game 4", "P", "", "L-3", "L-4");
$bracket_game_numbers[8][6][7] =  array("Winner Game 3", "Winner Game 4", "P", "", "W-3", "W-4");
$bracket_game_numbers[8][6][8]=   array("Winner Game 5", "Winner Game 6", "P", "", "W-5", "W-6");
$bracket_game_numbers[8][6][9] = array("Winner Game 8", "Loser Game 7", "P", "", "W-8", "L-7");
$bracket_game_numbers[8][6][10]=  array("Winner Game 7", "Winner Game 9", "P", "", "W-7", "W-9");
$bracket_game_numbers[8][6][11] = array("Winner Game 10", "Loser 10 If 1st Loss", "W", "", "W-10", "L-10");

//end 6 teams

//Star 7 teams
$bracket_game_numbers[8][7][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[8][7][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[8][7][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][7][4] =  array("Team 7", "Winner Game 1", "P", "", "" ,"W-1");
$bracket_game_numbers[8][7][5] = array("Winner Game 2", "Winner Game 3", "P", "", "W-2", "W-3");
$bracket_game_numbers[8][7][6]= array("Loser Game 1", "Loser Game 2", "P", "", "L-1", "L-2");
$bracket_game_numbers[8][7][7] =  array("Loser Game 3", "Loser Game 4", "P", "", "L-3", "L-4");
$bracket_game_numbers[8][7][8]=  array("Winner Game 6", "Loser Game 5", "P", "", "W-6", "L-5");
$bracket_game_numbers[8][7][9] = array("Winner Game 4", "Winner Game 5", "P", "", "W-4", "W-5");
$bracket_game_numbers[8][7][10]= array("Winner Game 7", "Winner Game 8", "P", "", "W-7", "W-8");
$bracket_game_numbers[8][7][11] =  array("Winner Game 10", "Loser Game 9", "P", "", "W-10", "L-9");
$bracket_game_numbers[8][7][12] = array("Winner Game 9", "Winner Game 11", "P", "", "W-9", "W-11");
$bracket_game_numbers[8][7][13] = array("Winner Game 12", "Loser 12 If 1st Loss", "W", "", "W-12", "L-12");


//end 7 teams 

//Star 8 teams
$bracket_game_numbers[8][8][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[8][8][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[8][8][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][8][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[8][8][5] = array("Loser Game 1", "Loser Game 2", "P", "", "L-1", "L-2");
$bracket_game_numbers[8][8][6]=  array("Loser Game 3", "Loser Game 4", "P", "", "L-3", "L-4");
$bracket_game_numbers[8][8][7] =  array("Winner Game 1", "Winner Game 2", "P", "", "W-1", "W-2");
$bracket_game_numbers[8][8][8]=   array("Winner Game 3", "Winner Game 4", "P", "", "W-3", "W-4");
$bracket_game_numbers[8][8][9] =array("Winner Game 5", "Loser Game 8", "P", "", "W-5", "L-8");
$bracket_game_numbers[8][8][10]=array("Winner Game 6", "Loser Game 7", "P", "", "W-6", "L-7");
$bracket_game_numbers[8][8][11] =  array("Winner Game 7", "Winner Game 8", "P", "", "W-7", "W-8");
$bracket_game_numbers[8][8][12] = array("Winner Game 9", "Winner Game 10", "P", "", "W-9", "W-10");
$bracket_game_numbers[8][8][13] =array("Winner Game 12", "Loser Game 11", "P", "", "W-12", "L-11");
$bracket_game_numbers[8][8][14] =  array("Winner Game 11", "Winner Game 13", "P", "", "W-11", "W-13");
$bracket_game_numbers[8][8][15] =array("Winner Game 14", "Loser 14 If 1st Loss", "W", "", "W-14", "L-14");

//end 8 teams




//Star 9 teams

$bracket_game_numbers[8][9][1] = array("Team 1","Team 2", "P", "", "", "");
$bracket_game_numbers[8][9][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][9][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][9][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[8][9][5] =array("Team 9","Winner Game 1", "P", "", "", "W-1");
$bracket_game_numbers[8][9][6]=  array("Loser Game 1", "Loser Game 2", "P", "", "L-1", "L-2");
$bracket_game_numbers[8][9][7] =  array("Loser Game 3", "Loser Game 4", "P", "", "L-3", "L-4");
$bracket_game_numbers[8][9][8]= array("Winner Game 6", "Loser Game 5", "P", "", "W-6", "L-5");
$bracket_game_numbers[8][9][9] = array("Winner Game 2", "Winner Game 3", "P", "", "W-2", "W-3");
$bracket_game_numbers[8][9][10]= array("Winner Game 4", "Winner Game 5", "P", "", "W-4", "W-5");
$bracket_game_numbers[8][9][11] = array("Winner Game 7", "Loser Game 9", "P", "", "W-7", "L-9");
$bracket_game_numbers[8][9][12] =array("Winner Game 8", "Loser Game 10", "P", "", "W-8", "L-10");
$bracket_game_numbers[8][9][13] =array("Winner Game 9", "Winner Game 10", "P", "", "W-9", "W-10");
$bracket_game_numbers[8][9][14] =array("Winner Game 11", "Winner Game 12", "P", "", "W-11", "W-12");
$bracket_game_numbers[8][9][15] =array("Winner Game 14", "Loser Game 13", "P", "", "W-14", "L-13");
$bracket_game_numbers[8][9][16] = array("Winner Game 13", "Winner Game 15", "P", "", "W-13", "W-15");
$bracket_game_numbers[8][9][17] =array("Winner Game 16", "Loser 16 If 1st Loss", "W", "", "W-16", "L-16");


//end 9 teams


//Start 10 teams
$bracket_game_numbers[8][10][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][10][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][10][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][10][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[8][10][5] = array("Team 9","Winner Game 2", "P", "", "", "W-2");
$bracket_game_numbers[8][10][6]=  array("Team 10","Winner Game 3", "P", "", "", "W-3");
$bracket_game_numbers[8][10][7] =array("Loser Game 1", "Loser Game 2", "P", "", "L-1", "L-2");
$bracket_game_numbers[8][10][8]= array("Loser Game 3", "Loser Game 4", "P", "", "L-3", "L-4");
$bracket_game_numbers[8][10][9] = array("Winner Game 7", "Loser Game 6", "P", "", "W-7", "L-6");
$bracket_game_numbers[8][10][10]= array("Winner Game 8", "Loser Game 5", "P", "", "W-8", "L-5");
$bracket_game_numbers[8][10][11] =array("Winner Game 1", "Winner Game 5", "P", "", "W-1", "W-5");
$bracket_game_numbers[8][10][12] =array("Winner Game 4", "Winner Game 6", "P", "", "W-4", "W-6");
$bracket_game_numbers[8][10][13] =array("Winner Game 9", "Loser Game 11", "P", "", "W-9", "L-11");
$bracket_game_numbers[8][10][14] = array("Winner Game 10", "Loser Game 12", "P", "", "W-10", "L-12");
$bracket_game_numbers[8][10][15] =array("Winner Game 11", "Winner Game 12", "P", "", "W-11", "W-12");
$bracket_game_numbers[8][10][16] =array("Winner Game 13","Winner Game 14","P", "", "W-13", "W-14");
$bracket_game_numbers[8][10][17] =array("Winner Game 16", "Loser Game 15", "P", "", "W-16", "L-15");
$bracket_game_numbers[8][10][18] = array("Winner Game 15","Winner Game 17","P", "", "W-15", "W-17");
$bracket_game_numbers[8][10][19] = array("Winner Game 18", "Loser 18 If 1st Loss", "W", "", "W-18", "L-18");

//end 10 teams


//Start 11 teams
$bracket_game_numbers[8][11][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][11][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][11][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][11][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[8][11][5] = array("Team 9","Winner Game 1","P", "", "", "W-1");
$bracket_game_numbers[8][11][6]=  array("Team 10","Winner Game 2","P", "", "", "W-2");
$bracket_game_numbers[8][11][7] = array("Team 11","Winner Game 3","P", "", "", "W-3");
$bracket_game_numbers[8][11][8]=  array("Loser Game 1","Loser Game 2","P", "", "L-1" ,"L-2");
$bracket_game_numbers[8][11][9] = array("Loser Game 3","Loser Game 4","P", "", "L-3", "L-4");
$bracket_game_numbers[8][11][10]=  array("Loser Game 5","Loser Game 6","P", "", "L-5", "L-6");
$bracket_game_numbers[8][11][11] = array("Winner Game 8","Winner Game 9","P", "", "W-8", "W-9");
$bracket_game_numbers[8][11][12] = array("Winner Game 10","Loser Game 7","P", "", "W-10", "W-7");
$bracket_game_numbers[8][11][13] = array("Winner Game 4","Winner Game 5","P", "", "W-4", "W-5");
$bracket_game_numbers[8][11][14] = array("Winner Game 6","Winner Game 7","P", "", "W-6", "W-7");
$bracket_game_numbers[8][11][15] = array("Winner Game 12","Loser Game 13","P", "", "W-12", "L-13");
$bracket_game_numbers[8][11][16] = array("Winner Game 11", "Loser Game 14", "P", "", "W-11", "L-14");
$bracket_game_numbers[8][11][17] = array("Winner Game 13","Winner Game 14","P", "", "W-13", "W-14");
$bracket_game_numbers[8][11][18] = array("Winner Game 15","Winner Game 16","P", "", "W-15", "W-16");
$bracket_game_numbers[8][11][19] = array("Winner Game 18","Loser Game 17","P", "", "W-18", "L-17");
$bracket_game_numbers[8][11][20] = array("Winner Game 17","Winner Game 19","P", "", "W-17", "W-19");
$bracket_game_numbers[8][11][21] = array("Winner Game 20","Loser 20 If 1st Loss","P", "", "W-20", "L-20");

//end 11 teams


//Start 12 teams
$bracket_game_numbers[8][12][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][12][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][12][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][12][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[8][12][5] = array("Team 9","Winner Game 1","P", "", "", "W-1");
$bracket_game_numbers[8][12][6]=  array("Team 10","Winner Game 2","P", "", "", "W-2");
$bracket_game_numbers[8][12][7] = array("Team 11","Winner Game 3","P", "", "", "W-3");
$bracket_game_numbers[8][12][8]=  array("Team 12","Winner Game 4","P", "", "", "W-4");
$bracket_game_numbers[8][12][9] = array("Loser Game 1","Loser Game 2","P", "", "L-1", "L-2");
$bracket_game_numbers[8][12][10]= array("Loser Game 3","Loser Game 4","P", "", "L-3", "L-4");
$bracket_game_numbers[8][12][11] = array("Loser Game 5","Loser Game 6","P", "", "L-5","L-6");
$bracket_game_numbers[8][12][12] = array("Loser Game 7","Loser Game 8","P", "", "L-7", "L-8");
$bracket_game_numbers[8][12][13] = array("Winner Game 5","Winner Game 6","P", "", "W-5", "W-6");
$bracket_game_numbers[8][12][14] = array("Winner Game 7","Winner Game 8","P", "", "W-7", "W-8");
$bracket_game_numbers[8][12][15] = array("Winner Game 9","Winner Game 10","P", "", "W-9", "W-10");
$bracket_game_numbers[8][12][16] = array("Winner Game 11","Winner Game 12", "P", "", "W-11", "W-12");
$bracket_game_numbers[8][12][17] = array("Winner Game 15","Loser Game 14","P", "", "W-15" , "L-14");
$bracket_game_numbers[8][12][18] = array("Winner Game 16","Loser Game 13","P", "", "W-16", "L-13");
$bracket_game_numbers[8][12][19] = array("Winner Game 13","Winner Game 14","P", "", "W-13", "W-14");
$bracket_game_numbers[8][12][20] = array("Winner Game 17","Winner Game 18","P", "", "W-17", "W-18");
$bracket_game_numbers[8][12][21] = array("Winner Game 20","Loser Game 19","P", "", "W-20", "L-19");
$bracket_game_numbers[8][12][22] = array("Winner Game 19","Winner Game 21","P", "", "W-19", "W-21");
$bracket_game_numbers[8][12][23] = array("Winner Game 22","Loser 22 If 1st Loss","P", "", "W-22", "L-22");

//end 12 teams

//Start 13 teams
$bracket_game_numbers[8][13][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][13][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][13][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][13][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[8][13][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[8][13][6]=  array("Team 11","Winner Game 1","P", "", "", "W-1");
$bracket_game_numbers[8][13][7] = array("Team 12","Winner Game 2","P", "", "", "W-2");
$bracket_game_numbers[8][13][8]=  array("Team 13","Winner Game 5","P", "", "", "W-5");
$bracket_game_numbers[8][13][9] = array("Winner Game 3","Winner Game 4","P", "", "W-3", "W-4");
$bracket_game_numbers[8][13][10]= array("Loser Game 1","Loser Game 2","P", "", "L-1", "L-2");
$bracket_game_numbers[8][13][11] = array("Loser Game 3","Loser Game 4","P", "", "L-3", "L-4");
$bracket_game_numbers[8][13][12] = array("Loser Game 5","Loser Game 6","P", "", "L-5", "L-6");
$bracket_game_numbers[8][13][13] = array("Loser Game 7","Loser Game 8","P", "", "L-7", "L-8");
$bracket_game_numbers[8][13][14] = array("Winner Game 10","Loser Game 9","P", "", "W-10", "L-9");
$bracket_game_numbers[8][13][15] = array("Winner Game 6","Winner Game 7","P", "", "W-6", "W-7");
$bracket_game_numbers[8][13][16] = array("Winner Game 8","Winner Game 9", "P", "", "W-8", "W-9");
$bracket_game_numbers[8][13][17] = array("Winner Game 11","Winner Game 14","P", "", "W-11", "W-12");
$bracket_game_numbers[8][13][18] = array("Winner Game 12","Winner Game 13","P", "", "W-12", "W-13");
$bracket_game_numbers[8][13][19] = array("Winner Game 17","Loser Game 15","P", "", "W-17", "L-15");
$bracket_game_numbers[8][13][20] = array("Winner Game 18","Loser Game 16","P", "", "W-18", "L-16");
$bracket_game_numbers[8][13][21] = array("Winner Game 15","Winner Game 16","P", "", "W-15", "W-16");
$bracket_game_numbers[8][13][22] = array("Winner Game 19","Winner Game 20","P", "", "W-19", "W-20");
$bracket_game_numbers[8][13][23] = array("Winner Game 22","Loser Game 21","P", "", "W-22", "W-21");
$bracket_game_numbers[8][13][24] = array("Winner Game 21","Winner Game 23","P", "", "W-24", "W-23");
$bracket_game_numbers[8][13][25] = array("Winner Game 24","Loser 24 If 1st Loss","P", "", "W-24", "L-24");

//end 13 teams

//Start 14 teams 
$bracket_game_numbers[8][14][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][14][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][14][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][14][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[8][14][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[8][14][6]=  array("Team 11","Team 12","P", "", "", "");
$bracket_game_numbers[8][14][7] = array("Team 13","Winner Game 3","P", "", "", "W-3");
$bracket_game_numbers[8][14][8]=  array("Team 14","Winner Game 6","P", "", "", "W-6");
$bracket_game_numbers[8][14][9] = array("Winner Game 1","Winner Game 2","P", "", "W-1", "W-2");
$bracket_game_numbers[8][14][10]= array("Winner Game 4","Winner Game 5","P", "", "W-4", "W-5");
$bracket_game_numbers[8][14][11] = array("Loser Game 1","Loser Game 2","P", "", "L-1", "L-2");
$bracket_game_numbers[8][14][12] = array("Loser Game 3","Loser Game 4","P", "", "L-3", "L-4");
$bracket_game_numbers[8][14][13] = array("Loser Game 5","Loser Game 6","P", "", "L-5", "L-6");
$bracket_game_numbers[8][14][14] = array("Loser Game 7","Loser Game 8","P", "", "L-7", "L-8");
$bracket_game_numbers[8][14][15] = array("Winner Game 11","Loser Game 9","P", "", "W-11", "L-9");
$bracket_game_numbers[8][14][16] = array("Winner Game 12","Loser Game 10", "P", "", "W-12", "L-10");
$bracket_game_numbers[8][14][17] = array("Winner Game 7","Winner Game 9","P", "", "W-7", "W-9");
$bracket_game_numbers[8][14][18] = array("Winner Game 8","Winner Game 10","P", "", "W-8", "W-10");
$bracket_game_numbers[8][14][19] = array("Winner Game 13","Winner Game 15","P", "", "W-13", "W-15");
$bracket_game_numbers[8][14][20] = array("Winner Game 14","Winner Game 16","P", "", "W-14", "W-16");
$bracket_game_numbers[8][14][21] = array("Winner Game 19","Loser Game 18","P", "", "W-19", "L-18");
$bracket_game_numbers[8][14][22] = array("Winner Game 20","Loser Game 17","P", "", "W-20", "L-17");
$bracket_game_numbers[8][14][23] = array("Winner Game 17","Winner Game 18","P", "", "W-17", "W-18");
$bracket_game_numbers[8][14][24] = array("Winner Game 21","Winner Game 22","P", "", "W-21", "W-22");
$bracket_game_numbers[8][14][25] = array("Winner Game 24","Loser Game 23","P", "", "W-24", "L-23");
$bracket_game_numbers[8][14][26] = array("Winner Game 23","Winner Game 25","P", "", "W-23", "W-25");
$bracket_game_numbers[8][14][27] = array("Winner Game 26","Loser 26 If 1st Loss","P", "", "W-26", "L-26");

//End 14 Teams

//Start 15 teams 
$bracket_game_numbers[8][15][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][15][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][15][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][15][4] = array("Team 7", "Team 8", "P", "", "" ,"");
$bracket_game_numbers[8][15][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[8][15][6]=  array("Team 11","Team 12","P", "", "", "");
$bracket_game_numbers[8][15][7] = array("Team 13","Team 14","P", "", "", "");
$bracket_game_numbers[8][15][8]=  array("Team 15","Winner Game 1","P", "", "", "W-1");
$bracket_game_numbers[8][15][9] = array("Winner Game 2","Winner Game 3","P", "", "W-2", "W-3");
$bracket_game_numbers[8][15][10]= array("Winner Game 4","Winner Game 5","P", "", "W-4", "W-5");
$bracket_game_numbers[8][15][11] = array("Winner Game 6","Winner Game 7","P", "", "W-6", "W-7");
$bracket_game_numbers[8][15][12] = array("Loser Game 1","Loser Game 2","P", "", "L-1", "L-2");
$bracket_game_numbers[8][15][13] = array("Loser Game 3","Loser Game 4","P", "", "L-3", "L-4");
$bracket_game_numbers[8][15][14] = array("Loser Game 5","Loser Game 6","P", "", "L-5", "L-6");
$bracket_game_numbers[8][15][15] = array("Loser Game 7","Loser Game 8","P", "", "L-7", "L-8");
$bracket_game_numbers[8][15][16] = array("Winner Game 14","Loser Game 9", "P", "", "W-14", "L-9");
$bracket_game_numbers[8][15][17] = array("Winner Game 12","Loser Game 10","P", "", "W-12", "L-10");
$bracket_game_numbers[8][15][18] = array("Winner Game 13","Loser Game 11","P", "", "W-13", "L-11");
$bracket_game_numbers[8][15][19] = array("Winner Game 8","Winner Game 9","P", "", "W-8", "W-9");
$bracket_game_numbers[8][15][20] = array("Winner Game 10","Winner Game 11","P", "", "W-10", "W-11");
$bracket_game_numbers[8][15][21] = array("Winner Game 15","Winner Game 16","P", "", "W-15", "W-16");
$bracket_game_numbers[8][15][22] = array("Winner Game 17","Winner Game 18","P", "", "W-17", "W-18");
$bracket_game_numbers[8][15][23] = array("Winner Game 21","Loser Game 19","P", "", "W-21", "L-19");
$bracket_game_numbers[8][15][24] = array("Winner Game 22","Loser Game 20","P", "", "W-22", "L-20");
$bracket_game_numbers[8][15][25] = array("Winner Game 24","Loser Game 23","P", "", "W-24", "L-23");
$bracket_game_numbers[8][15][26] = array("Winner Game 23","Winner Game 24","P", "", "W-23", "W-24");
$bracket_game_numbers[8][15][27] = array("Winner Game 26","Loser Game 25","P", "", "W-26", "L-25");
$bracket_game_numbers[8][15][28] = array("Winner Game 25","Winner Game 27","P", "", "W-25", "W-27");
$bracket_game_numbers[8][15][29] = array("Winner Game 28","Loser 28 If 1st Loss","P", "", "W-28", "L-28");


$bracket_game_numbers[8][16][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][16][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][16][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][16][4] = array("Team 7", "Team 8", "P", "", "" ,"");
$bracket_game_numbers[8][16][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[8][16][6]=  array("Team 11","Team 12","P", "", "", "");
$bracket_game_numbers[8][16][7] = array("Team 13","Team 14","P", "", "", "");
$bracket_game_numbers[8][16][8]=  array("Team 15","Team 16","P", "", "", "W-1");
$bracket_game_numbers[8][16][9] = array("Loser Game 1","Loser Game 2","P", "", "L-1", "L-2");
$bracket_game_numbers[8][16][10]= array("Loser Game 3","Loser Game 4","P", "", "L-3", "L-4");
$bracket_game_numbers[8][16][11] = array("Loser Game 5","Loser Game 6","P", "", "L-5", "L-6");
$bracket_game_numbers[8][16][12] = array("Loser Game 7","Loser Game 8","P", "", "L-7", "L-8");
$bracket_game_numbers[8][16][13] = array("Winner Game 1","Winner Game 2", "P", "", "W-1", "W-2");
$bracket_game_numbers[8][16][14] = array("Winner Game 3","Winner Game 4","P", "", "W-3", "W-4");
$bracket_game_numbers[8][16][15] = array("Winner Game 5","Winner Game 6","P", "", "W-5", "W-6");
$bracket_game_numbers[8][16][16] = array("Winner Game 7","Winner Game 8","P", "", "W-7", "W-8");
$bracket_game_numbers[8][16][17] = array("Winner Game 12","Loser Game 13","P", "", "W-12", "L-13");
$bracket_game_numbers[8][16][18] = array("Winner Game 11","Loser Game 14","P", "", "W-11", "L-14");
$bracket_game_numbers[8][16][19] = array("Winner Game 10","Loser Game 15","P", "", "W-10", "L-15");
$bracket_game_numbers[8][16][20] = array("Winner Game 9","Loser Game 16","P", "", "W-9", "L-16");
$bracket_game_numbers[8][16][21] = array("Winner Game 13","Winner Game 14","P", "", "W-13", "W-14");
$bracket_game_numbers[8][16][22] = array("Winner Game 15","Winner Game 16","P", "", "W-15", "W-16");
$bracket_game_numbers[8][16][23] = array("Winner Game 17","Winner Game 18","P", "", "W-17", "W-18");
$bracket_game_numbers[8][16][24] = array("Winner Game 19","Winner Game 20","P", "", "W-19", "W-20");
$bracket_game_numbers[8][16][25] = array("Winner Game 23","Loser Game 21","P", "", "W-23", "L-21");
$bracket_game_numbers[8][16][26] = array("Winner Game 24","Loser Game 22","P", "", "W-24", "L-22");
$bracket_game_numbers[8][16][27] = array("Winner Game 21","Winner Game 22","P", "", "W-21", "W-22");
$bracket_game_numbers[8][16][28] = array("Winner Game 25","Winner Game 26","P", "", "W-25", "W-26");
$bracket_game_numbers[8][16][29] = array("Winner Game 28","Loser Game 27","P", "", "W-28", "L-27");
$bracket_game_numbers[8][16][30] = array("Winner Game 27","Winner Game 29","P", "", "W-27", "W-29");
$bracket_game_numbers[8][16][31] = array("Winner Game 30","Loser 30 If 1st Loss","P", "", "W-30", "L-30");


$bracket_game_numbers[8][17][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][17][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][17][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][17][4] = array("Team 7", "Team 8", "P", "", "" ,"");
$bracket_game_numbers[8][17][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[8][17][6]=  array("Team 11","Team 12","P", "", "", "");
$bracket_game_numbers[8][17][7] = array("Team 13","Team 14","P", "", "", "");
$bracket_game_numbers[8][17][8]=  array("Team 15","Team 16","P", "", "", "");
$bracket_game_numbers[8][17][9] = array("Team 17","Winner Game 1","P", "", "", "W-1");
$bracket_game_numbers[8][17][10]= array("Loser Game 1","Loser Game 2","P", "", "L-1", "L-2");
$bracket_game_numbers[8][17][11] = array("Loser Game 4","Loser Game 5","P", "", "L-4", "L-5");
$bracket_game_numbers[8][17][12] = array("Loser Game 6","Loser Game 7","P", "", "L-6", "L-7");
$bracket_game_numbers[8][17][13] = array("Loser Game 8","Loser Game 9", "P", "", "L-8", "L-9");
$bracket_game_numbers[8][17][14] = array("Loser Game 3","Loser Game 10","P", "", "L-3", "L-10");
$bracket_game_numbers[8][17][15] = array("Winner Game 2","Winner Game 3","P", "", "W-2", "W-3");
$bracket_game_numbers[8][17][16] = array("Winner Game 4","Winner Game 5","P", "", "W-4", "W-5");
$bracket_game_numbers[8][17][17] = array("Winner Game 6","Loser Game 9","P", "", "W-6", "L-9");
$bracket_game_numbers[8][17][18] = array("Winner Game 7","Winner Game 8","P", "", "W-7", "W-8");
$bracket_game_numbers[8][17][19] = array("Winner Game 13","Loser Game 15","P", "", "W-13", "L-15");
$bracket_game_numbers[8][17][20] = array("Winner Game 12","Loser Game 16","P", "", "W-12", "L-16");
$bracket_game_numbers[8][17][21] = array("Winner Game 11","Loser Game 17","P", "", "W-11", "L-17");
$bracket_game_numbers[8][17][22] = array("Winner Game 14","Loser Game 18","P", "", "W-14", "L-18");
$bracket_game_numbers[8][17][23] = array("Winner Game 15","Winner Game 16","P", "", "W-15", "W-16");
$bracket_game_numbers[8][17][24] = array("Winner Game 17","Winner Game 18","P", "", "W-17", "W-18");
$bracket_game_numbers[8][17][25] = array("Winner Game 19","Winner Game 20","P", "", "W-19", "W-20");
$bracket_game_numbers[8][17][26] = array("Winner Game 21","Winner Game 22","P", "", "W-21", "W-22");
$bracket_game_numbers[8][17][27] = array("Winner Game 25","Loser Game 23","P", "", "W-25", "L-23");
$bracket_game_numbers[8][17][28] = array("Winner Game 26","Loser Game 24","P", "", "W-26", "L-24");
$bracket_game_numbers[8][17][29] = array("Winner Game 23","Winner Game 24","P", "", "W-23", "W-24");
$bracket_game_numbers[8][17][30] = array("Winner Game 27","Winner Game 28","P", "", "W-27", "W-28");
$bracket_game_numbers[8][17][31] = array("Winner Game 30","Loser Game 29","P", "", "W-30", "L-29");
$bracket_game_numbers[8][17][32] = array("Winner Game 29","Winner Game 31","P", "", "W-29", "W-31");
$bracket_game_numbers[8][17][33] = array("Winner Game 32","Loser 32 If 1st Loss","P", "", "W-32", "L-32");


$bracket_game_numbers[8][18][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][18][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][18][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][18][4] = array("Team 7", "Team 8", "P", "", "" ,"");
$bracket_game_numbers[8][18][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[8][18][6]=  array("Team 11","Team 12","P", "", "", "");
$bracket_game_numbers[8][18][7] = array("Team 13","Team 14","P", "", "", "");
$bracket_game_numbers[8][18][8]=  array("Team 15","Team 16","P", "", "", "");
$bracket_game_numbers[8][18][9] = array("Team 17","Winner Game 1","P", "", "", "W-1");
$bracket_game_numbers[8][18][10]= array("Team 18","Winner Game 2","P", "", "", "W-2");
$bracket_game_numbers[8][18][11] = array("Loser Game 1","Loser Game 2","P", "", "L-1", "L-2");
$bracket_game_numbers[8][18][12] = array("Loser Game 3","Loser Game 4","P", "", "L-3", "L-4");
$bracket_game_numbers[8][18][13] = array("Loser Game 5","Loser Game 6", "P", "", "L-5", "L-6");
$bracket_game_numbers[8][18][14] = array("Loser Game 7","Loser Game 9","P", "", "L-7", "L-9");
$bracket_game_numbers[8][18][15] = array("Winner Game 11","Loser Game 8","P", "", "W-11", "L-8");
$bracket_game_numbers[8][18][16] = array("Winner Game 12","Loser Game 10","P", "", "W-12", "L-10");
$bracket_game_numbers[8][18][17] = array("Winner Game 3","Winner Game 4","P", "", "W-3", "W-4");
$bracket_game_numbers[8][18][18] = array("Winner Game 9","Winner Game 5","P", "", "W-9", "W-5");
$bracket_game_numbers[8][18][19] = array("Winner Game 6","Winner Game 10","P", "", "W-6", "W-10");
$bracket_game_numbers[8][18][20] = array("Winner Game 7","Winner Game 8","P", "", "W-7", "W-8");
$bracket_game_numbers[8][18][21] = array("Winner Game 16","Loser Game 17","P", "", "W-16", "L-17");
$bracket_game_numbers[8][18][22] = array("Winner Game 14","Loser Game 18","P", "", "W-14", "L-18");
$bracket_game_numbers[8][18][23] = array("Winner Game 13","Loser Game 19","P", "", "W-13", "L-19");
$bracket_game_numbers[8][18][24] = array("Winner Game 15","Loser Game 20","P", "", "W-15", "L-20");
$bracket_game_numbers[8][18][25] = array("Winner Game 17","Winner Game 18","P", "", "W-17", "W-18");
$bracket_game_numbers[8][18][26] = array("Winner Game 19","Winner Game 20","P", "", "W-19", "W-20");
$bracket_game_numbers[8][18][27] = array("Winner Game 21","Winner Game 22","P", "", "W-21", "W-22");
$bracket_game_numbers[8][18][28] = array("Winner Game 23","Winner Game 24","P", "", "W-22", "W-24");
$bracket_game_numbers[8][18][29] = array("Winner Game 27","Loser Game 26","P", "", "W-27", "L-26");
$bracket_game_numbers[8][18][30] = array("Winner Game 25","Loser Game 25","P", "", "W-25", "L-25");
$bracket_game_numbers[8][18][31] = array("Winner Game 25","Winner Game 26","P", "", "W-25", "W-26");
$bracket_game_numbers[8][18][32] = array("Winner Game 29","Winner Game 30","P", "", "W-29", "W-30");
$bracket_game_numbers[8][18][33] = array("Winner Game 32","Loser Game 31","P", "", "W-32", "L-31");
$bracket_game_numbers[8][18][34] = array("Winner Game 31","Winner Game 33","P", "", "W-31", "W-33");
$bracket_game_numbers[8][18][35] = array("Winner Game 34","Loser 34 If 1st Loss","P", "", "W-34", "L-34");

$bracket_game_numbers[8][19][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][19][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][19][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][19][4] = array("Team 7", "Team 8", "P", "", "" ,"");
$bracket_game_numbers[8][19][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[8][19][6]=  array("Team 11","Team 12","P", "", "", "");
$bracket_game_numbers[8][19][7] = array("Team 13","Team 14","P", "", "", "");
$bracket_game_numbers[8][19][8]=  array("Team 15","Team 16","P", "", "", "");
$bracket_game_numbers[8][19][9] = array("Team 17","Winner Game 1","P", "", "", "W-1");
$bracket_game_numbers[8][19][10]= array("Team 18","Winner Game 2","P", "", "", "W-2");
$bracket_game_numbers[8][19][11] = array("Team 19","Winner Game 3","P", "", "", "W-3");
$bracket_game_numbers[8][19][12] = array("Loser Game 5","Loser Game 6","P", "", "L-5", "L-6");
$bracket_game_numbers[8][19][13] = array("Loser Game 3","Loser Game 4", "P", "", "L-3", "L-4");
$bracket_game_numbers[8][19][14] = array("Loser Game 1","Loser Game 2","P", "", "L-1", "L-2");
$bracket_game_numbers[8][19][15] = array("Loser Game 7","Loser Game 8","P", "", "L-7", "L-8");
$bracket_game_numbers[8][19][16] = array("Loser Game 9","Winner Game 12","P", "", "L-9", "W-12");
$bracket_game_numbers[8][19][17] = array("Loser Game 10","Winner Game 13","P", "", "L-10", "W-13");
$bracket_game_numbers[8][19][18] = array("Loser Game 11","Winner Game 14","P", "", "L-11", "W-14");
$bracket_game_numbers[8][19][19] = array("Winner Game 4","Winner Game 5 ","P", "", "W-4", "W-5");
$bracket_game_numbers[8][19][20] = array("Winner Game 6","Winner Game 9","P", "", "W-6", "W-9");
$bracket_game_numbers[8][19][21] = array("Winner Game 7","Winner Game 10","P", "", "W-7", "W-10");
$bracket_game_numbers[8][19][22] = array("Winner Game 8","Winner Game 11","P", "", "W-8", "W-11");
$bracket_game_numbers[8][19][23] = array("Winner Game 18","Loser Game 19","P", "", "W-18", "L-19");
$bracket_game_numbers[8][19][24] = array("Winner Game 17","Loser Game 20","P", "", "W-17", "L-20");
$bracket_game_numbers[8][19][25] = array("Winner Game 15","Loser Game 21","P", "", "W-15", "L-21");
$bracket_game_numbers[8][19][26] = array("Winner Game 16","Loser Game 22","P", "", "W-16", "L-22");
$bracket_game_numbers[8][19][27] = array("Winner Game 19","Winner Game 20","P", "", "W-19", "W-20");
$bracket_game_numbers[8][19][28] = array("Winner Game 21","Winner Game 24","P", "", "W-21", "W-24");
$bracket_game_numbers[8][19][29] = array("Winner Game 23","Winner Game 24","P", "", "W-23", "W-24");
$bracket_game_numbers[8][19][30] = array("Winner Game 25","Winner Game 26","P", "", "W-25", "W-26");
$bracket_game_numbers[8][19][31] = array("Winner Game 29","Loser Game 28","P", "", "W-29", "L-28");
$bracket_game_numbers[8][19][32] = array("Winner Game 23","Loser Game 27","P", "", "W-23", "L-27");
$bracket_game_numbers[8][19][33] = array("Winner Game 27","Winner Game 28","P", "", "W-27", "W-28");
$bracket_game_numbers[8][19][34] = array("Winner Game 31","Winner Game 32","P", "", "W-31", "W-32");
$bracket_game_numbers[8][19][35] = array("Winner Game 34","Loser Game 33","P", "", "W-34", "L-33");
$bracket_game_numbers[8][19][36] = array("Winner Game 33","Winner Game 35","P", "", "W-33", "W-35");
$bracket_game_numbers[8][19][37] = array("Winner Game 36","Loser 36 If 1st Loss","P", "", "W-36", "L-36");


$bracket_game_numbers[8][20][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][20][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][20][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][20][4] = array("Team 7", "Team 8", "P", "", "" ,"");
$bracket_game_numbers[8][20][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[8][20][6]=  array("Team 11","Team 12","P", "", "", "");
$bracket_game_numbers[8][20][7] = array("Team 13","Team 14","P", "", "", "");
$bracket_game_numbers[8][20][8]=  array("Team 15","Team 16","P", "", "", "");
$bracket_game_numbers[8][20][9] = array("Team 17","Winner Game 1","P", "", "", "W-1");
$bracket_game_numbers[8][20][10]= array("Team 18","Winner Game 2","P", "", "", "W-2");
$bracket_game_numbers[8][20][11] = array("Team 19","Winner Game 3","P", "", "", "W-3");
$bracket_game_numbers[8][20][12] = array("Team 20","Winner Game 4","P", "", "", "W-4");
$bracket_game_numbers[8][20][13] = array("Loser Game 1","Loser Game 2", "P", "", "L-1", "L-2");
$bracket_game_numbers[8][20][14] = array("Loser Game 3","Loser Game 4","P", "", "L-3", "L-4");
$bracket_game_numbers[8][20][15] = array("Loser Game 5","Loser Game 6","P", "", "L-5", "L-6");
$bracket_game_numbers[8][20][16] = array("Loser Game 7","Loser Game 8","P", "", "L-7", "L-8");
$bracket_game_numbers[8][20][17] = array("Loser Game 12","Winner Game 13","P", "", "L-12", "W-13");
$bracket_game_numbers[8][20][18] = array("Loser Game 11","Winner Game 14","P", "", "W-11", "W-14");
$bracket_game_numbers[8][20][19] = array("Loser Game 10","Winner Game 9 ","P", "", "L-10", "W-9");
$bracket_game_numbers[8][20][20] = array("Loser Game 15","Winner Game 16","P", "", "W-15", "W-16");
$bracket_game_numbers[8][20][21] = array("Winner Game 5","Winner Game 9","P", "", "W-5", "W-9");
$bracket_game_numbers[8][20][22] = array("Winner Game 6","Winner Game 10","P", "", "W-6", "W-10");
$bracket_game_numbers[8][20][23] = array("Winner Game 7","Winner Game 11","P", "", "W-7", "W-11");
$bracket_game_numbers[8][20][24] = array("Winner Game 8","Winner Game 12","P", "", "W-8", "W-12");
$bracket_game_numbers[8][20][25] = array("Winner Game 18","Loser Game 21","P", "", "W-18", "L-21");
$bracket_game_numbers[8][20][26] = array("Winner Game 19","Loser Game 22","P", "", "W-19", "L-22");
$bracket_game_numbers[8][20][27] = array("Winner Game 17","Loser Game 23","P", "", "W-17", "L-23");
$bracket_game_numbers[8][20][28] = array("Winner Game 20","Loser Game 24","P", "", "W-20", "L-24");
$bracket_game_numbers[8][20][29] = array("Winner Game 21","Winner Game 22","P", "", "W-21", "W-22");
$bracket_game_numbers[8][20][30] = array("Winner Game 23","Winner Game 24","P", "", "W-23", "W-24");
$bracket_game_numbers[8][20][31] = array("Winner Game 25","Winner Game 27","P", "", "W-25", "W-27");
$bracket_game_numbers[8][20][32] = array("Winner Game 26","Winner Game 28","P", "", "W-26", "W-28");
$bracket_game_numbers[8][20][33] = array("Winner Game 31","Loser Game 29","P", "", "W-31", "L-29");
$bracket_game_numbers[8][20][34] = array("Winner Game 32","Loser Game 30","P", "", "W-32", "L-30");
$bracket_game_numbers[8][20][35] = array("Winner Game 29","Winner Game 30","P", "", "W-29", "W-30");
$bracket_game_numbers[8][20][36] = array("Winner Game 33","Winner Game 34","P", "", "W-33", "W-34");
$bracket_game_numbers[8][20][37] = array("Winner Game 36","Loser Game 35","P", "", "W-36", "L-35");
$bracket_game_numbers[8][20][38] = array("Winner Game 35","Winner Game 37","P", "", "W-35", "W-37");
$bracket_game_numbers[8][20][39] = array("Winner Game 38","Loser 38 If 1st Loss","P", "", "W-38", "L-38");

$bracket_game_numbers[8][21][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][21][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][21][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][21][4] = array("Team 7", "Team 8", "P", "", "" ,"");
$bracket_game_numbers[8][21][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[8][21][6]=  array("Team 11","Team 12","P", "", "", "");
$bracket_game_numbers[8][21][7] = array("Team 13","Team 14","P", "", "", "");
$bracket_game_numbers[8][21][8]=  array("Team 15","Team 16","P", "", "", "");
$bracket_game_numbers[8][21][9] = array("Team 17","Winner Game 1","P", "", "", "W-1");
$bracket_game_numbers[8][21][10]= array("Team 18","Winner Game 2","P", "", "", "W-2");
$bracket_game_numbers[8][21][11] = array("Team 19","Winner Game 3","P", "", "", "W-3");
$bracket_game_numbers[8][21][12] = array("Team 20","Winner Game 4","P", "", "", "W-4");
$bracket_game_numbers[8][21][13] = array("Team 21","Winner Game 5", "P", "", "", "W-5");
$bracket_game_numbers[8][21][14] = array("Loser Game 1","Loser Game 2","P", "", "L-1", "L-2");
$bracket_game_numbers[8][21][15] = array("Loser Game 3","Loser Game 4","P", "", "L-3", "L-4");
$bracket_game_numbers[8][21][16] = array("Loser Game 5","Loser Game 6","P", "", "L-5", "L-6");
$bracket_game_numbers[8][21][17] = array("Loser Game 7","Loser Game 8","P", "", "L-7", "L-8");
$bracket_game_numbers[8][21][18] = array("Loser Game 9","Loser Game 10","P", "", "L-9", "L-10");
$bracket_game_numbers[8][21][19] = array("Winner Game 14","Winner Game 15 ","P", "", "W-14", "W-15");
$bracket_game_numbers[8][21][20] = array("Loser Game 11","Winner Game 16","P", "", "L-11", "W-16");
$bracket_game_numbers[8][21][21] = array("Loser Game 12","Winner Game 17","P", "", "L-12", "W-17");
$bracket_game_numbers[8][21][22] = array("Loser Game 13","Winner Game 18","P", "", "L-13", "W-18");
$bracket_game_numbers[8][21][23] = array("Winner Game 6","Winner Game 9","P", "", "W-6", "W-9");
$bracket_game_numbers[8][21][24] = array("Winner Game 7","Winner Game 10","P", "", "W-7", "W-10");
$bracket_game_numbers[8][21][25] = array("Winner Game 11","Winner Game 12","P", "", "W-11", "W-12");
$bracket_game_numbers[8][21][26] = array("Winner Game 8","Winner Game 13","P", "", "W-8", "W-13");
$bracket_game_numbers[8][21][27] = array("Winner Game 19","Loser Game 23","P", "", "W-19", "L-23");
$bracket_game_numbers[8][21][28] = array("Winner Game 20","Loser Game 24","P", "", "W-20", "L-24");
$bracket_game_numbers[8][21][29] = array("Winner Game 21","Loser Game 26","P", "", "W-21", "L-26");
$bracket_game_numbers[8][21][30] = array("Winner Game 22","Loser Game 25","P", "", "W-22", "L-25");
$bracket_game_numbers[8][21][31] = array("Winner Game 23","Winner Game 24","P", "", "W-23", "W-24");
$bracket_game_numbers[8][21][32] = array("Winner Game 25","Winner Game 26","P", "", "W-25", "W-26");
$bracket_game_numbers[8][21][33] = array("Winner Game 27","Winner Game 28","P", "", "W-27", "W-28");
$bracket_game_numbers[8][21][34] = array("Winner Game 29","Winner Game 30","P", "", "W-29", "W-30");
$bracket_game_numbers[8][21][35] = array("Winner Game 33","Loser Game 32","P", "", "W-33", "L-32");
$bracket_game_numbers[8][21][36] = array("Winner Game 34","Loser Game 31","P", "", "W-34", "L-31");
$bracket_game_numbers[8][21][37] = array("Winner Game 31","Winner Game 32","P", "", "W-31", "W-32");
$bracket_game_numbers[8][21][38] = array("Winner Game 35","Winner Game 36","P", "", "W-35", "W-36");
$bracket_game_numbers[8][21][39] = array("Winner Game 38","Loser Game 37","P", "", "W-38", "L-37");
$bracket_game_numbers[8][21][40] = array("Winner Game 37","Winner Game 39","P", "", "W-37", "W-39");
$bracket_game_numbers[8][21][41] = array("Winner Game 40","Loser 40 If 1st Loss","P", "", "W-40", "L-40");


$bracket_game_numbers[8][22][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][22][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][22][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][22][4] = array("Team 7", "Team 8", "P", "", "" ,"");
$bracket_game_numbers[8][22][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[8][22][6]=  array("Team 11","Team 12","P", "", "", "");
$bracket_game_numbers[8][22][7] = array("Team 13","Team 14","P", "", "", "");
$bracket_game_numbers[8][22][8]=  array("Team 15","Team 16","P", "", "", "");
$bracket_game_numbers[8][22][9] = array("Team 17","Winner Game 1","P", "", "", "W-1");
$bracket_game_numbers[8][22][10]= array("Team 18","Winner Game 2","P", "", "", "W-2");
$bracket_game_numbers[8][22][11] = array("Team 19","Winner Game 3","P", "", "", "W-3");
$bracket_game_numbers[8][22][12] = array("Team 20","Winner Game 4","P", "", "", "W-4");
$bracket_game_numbers[8][22][13] = array("Team 21","Winner Game 5", "P", "", "", "W-5");
$bracket_game_numbers[8][22][14] = array("Team 22","Winner Game 6","P", "", "", "W-6");
$bracket_game_numbers[8][22][15] = array("Loser Game 1","Loser Game 2","P", "", "L-1", "L-2");
$bracket_game_numbers[8][22][16] = array("Loser Game 3","Loser Game 4","P", "", "L-3", "L-4");
$bracket_game_numbers[8][22][17] = array("Loser Game 5","Loser Game 6","P", "", "L-5", "L-6");
$bracket_game_numbers[8][22][18] = array("Loser Game 7","Loser Game 8","P", "", "L-7", "L-8");
$bracket_game_numbers[8][22][19] = array("Loser Game 9","Loser Game 10 ","P", "", "L-9", "L-10");
$bracket_game_numbers[8][22][20] = array("Loser Game 11","Loser Game 13","P", "", "L-11", "L-13");
$bracket_game_numbers[8][22][21] = array("Winner Game 15","Winner Game 16","P", "", "W-15", "W-16");
$bracket_game_numbers[8][22][22] = array("Loser Game 12","Winner Game 17","P", "", "L-12", "W-17");
$bracket_game_numbers[8][22][23] = array("Loser Game 14","Winner Game 18","P", "", "L-14", "W-18");
$bracket_game_numbers[8][22][24] = array("Winner Game 19","Winner Game 20","P", "", "W-19", "W-20");
$bracket_game_numbers[8][22][25] = array("Winner Game 7","Winner Game 9","P", "", "W-7", "W-9");
$bracket_game_numbers[8][22][26] = array("Winner Game 10","Winner Game 11","P", "", "W-10", "W-11");
$bracket_game_numbers[8][22][27] = array("Winner Game 12","Winner Game 13","P", "", "W-12", "W-13");
$bracket_game_numbers[8][22][28] = array("Winner Game 8","Winner Game 14","P", "", "W-8", "W-14");
$bracket_game_numbers[8][22][29] = array("Winner Game 24","Loser Game 25","P", "", "W-24", "L-25");
$bracket_game_numbers[8][22][30] = array("Winner Game 23","Loser Game 26","P", "", "W-23", "L-26");
$bracket_game_numbers[8][22][31] = array("Winner Game 22","Loser Game 27","P", "", "W-22", "L-27");
$bracket_game_numbers[8][22][32] = array("Winner Game 21","Loser Game 28","P", "", "W-21", "L-28");
$bracket_game_numbers[8][22][33] = array("Winner Game 25","Winner Game 26","P", "", "W-25", "W-26");
$bracket_game_numbers[8][22][34] = array("Winner Game 27","Winner Game 28","P", "", "W-27", "W-28");
$bracket_game_numbers[8][22][35] = array("Winner Game 29","Winner Game 30","P", "", "W-29", "W-30");
$bracket_game_numbers[8][22][36] = array("Winner Game 31","Winner Game 32","P", "", "W-31", "W-32");
$bracket_game_numbers[8][22][37] = array("Loser Game 34","Winner Game 35","P", "", "L-34", "W-35");
$bracket_game_numbers[8][22][38] = array("Loser Game 33","Winner Game 36","P", "", "L-33", "W-36");
$bracket_game_numbers[8][22][39] = array("Winner Game 33","Winner Game 34","P", "", "W-33", "W-34");
$bracket_game_numbers[8][22][40] = array("Winner Game 37","Winner Game 38","P", "", "W-37", "W-38");
$bracket_game_numbers[8][22][41] = array("Loser Game 39","Winner Game 40","P", "", "L-39", "W-40");
$bracket_game_numbers[8][22][42] = array("Winner Game 39","Winner Game 41","P", "", "W-39", "W-41");
$bracket_game_numbers[8][22][43] = array("Winner Game 42","Loser 42 If 1st Loss","P", "", "W-42", "L-42");


$bracket_game_numbers[8][23][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][23][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][23][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][23][4] = array("Team 7", "Team 8", "P", "", "" ,"");
$bracket_game_numbers[8][23][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[8][23][6]=  array("Team 11","Team 12","P", "", "", "");
$bracket_game_numbers[8][23][7] = array("Team 13","Team 14","P", "", "", "");
$bracket_game_numbers[8][23][8]=  array("Team 15","Team 16","P", "", "", "");
$bracket_game_numbers[8][23][9] = array("Team 17","Winner Game 1","P", "", "", "W-1");
$bracket_game_numbers[8][23][10]= array("Team 18","Winner Game 2","P", "", "", "W-2");
$bracket_game_numbers[8][23][11] = array("Team 19","Winner Game 3","P", "", "", "W-3");
$bracket_game_numbers[8][23][12] = array("Team 20","Winner Game 4","P", "", "", "W-4");
$bracket_game_numbers[8][23][13] = array("Team 21","Winner Game 5", "P", "", "", "W-5");
$bracket_game_numbers[8][23][14] = array("Team 22","Winner Game 6","P", "", "", "W-6");
$bracket_game_numbers[8][23][15] = array("Team 23","Winner Game 7","P", "", "", "W-7");
$bracket_game_numbers[8][23][16] = array("Loser Game 1","Loser Game 2","P", "", "L-1", "L-2");
$bracket_game_numbers[8][23][17] = array("Loser Game 3","Loser Game 4","P", "", "L-3", "L-4");
$bracket_game_numbers[8][23][18] = array("Loser Game 5","Loser Game 6","P", "", "L-5", "L-6");
$bracket_game_numbers[8][23][19] = array("Loser Game 7","Loser Game 8","P", "", "L-7", "L-8");
$bracket_game_numbers[8][23][20] = array("Loser Game 9","Loser Game 10","P", "", "L-9", "L-10");
$bracket_game_numbers[8][23][21] = array("Loser Game 11","Loser Game 12","P", "", "L-11", "L-12");
$bracket_game_numbers[8][23][22] = array("Loser Game 13","Loser Game 14","P", "", "L-13", "L-14");
$bracket_game_numbers[8][23][23] = array("Winner Game 16","Winner Game 17","P", "", "W-16", "W-17");
$bracket_game_numbers[8][23][24] = array("Winner Game 18","Winner Game 19","P", "", "W-18", "W-19");
$bracket_game_numbers[8][23][25] = array("Winner Game 20","Loser Game 15","P", "", "W-20", "L-15");
$bracket_game_numbers[8][23][26] = array("Winner Game 21","Winner Game 22","P", "", "W-21", "W-22");
$bracket_game_numbers[8][23][27] = array("Winner Game 8","Winner Game 9","P", "", "W-8", "W-9");
$bracket_game_numbers[8][23][28] = array("Winner Game 10","Winner Game 11","P", "", "W-10", "W-11");
$bracket_game_numbers[8][23][29] = array("Winner Game 12","Winner Game 13","P", "", "W-12", "W-13");
$bracket_game_numbers[8][23][30] = array("Winner Game 14","Winner Game 15","P", "", "W-14", "W-15");
$bracket_game_numbers[8][23][31] = array("Winner Game 26","Loser Game 27","P", "", "W-26", "L-27");
$bracket_game_numbers[8][23][32] = array("Winner Game 25","Loser Game 28","P", "", "W-25", "L-28");
$bracket_game_numbers[8][23][33] = array("Winner Game 24","Loser Game 29","P", "", "W-24", "L-29");
$bracket_game_numbers[8][23][34] = array("Winner Game 23","Loser Game 30","P", "", "W-23", "L-30");
$bracket_game_numbers[8][23][35] = array("Winner Game 27","Winner Game 28","P", "", "W-27", "W-28");
$bracket_game_numbers[8][23][36] = array("Winner Game 29","Winner Game 30","P", "", "W-29", "W-30");
$bracket_game_numbers[8][23][37] = array("Winner Game 31","Winner Game 32","P", "", "W-31", "W-32");
$bracket_game_numbers[8][23][38] = array("Winner Game 33","Winner Game 34","P", "", "W-33", "W-34");
$bracket_game_numbers[8][23][39] = array("Winner Game 37","Loser Game 36","P", "", "W-37", "L-36");
$bracket_game_numbers[8][23][40] = array("Winner Game 38","Loser Game 35","P", "", "W-38", "L-35");
$bracket_game_numbers[8][23][41] = array("Winner Game 35","Winner Game 36","P", "", "W-35", "W-36");
$bracket_game_numbers[8][23][42] = array("Winner Game 39","Winner Game 40","P", "", "W-39", "W-40");
$bracket_game_numbers[8][23][43] = array("Winner Game 42","Loser Game 41","P", "", "W-42", "L-41");
$bracket_game_numbers[8][23][44] = array("Winner Game 41","Winner Game 43","P", "", "W-41", "W-43");
$bracket_game_numbers[8][23][45] = array("Winner Game 44","Loser 44 If 1st Loss","P", "", "W-44", "L-44");


$bracket_game_numbers[8][24][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][24][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][24][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][24][4] = array("Team 7", "Team 8", "P", "", "" ,"");
$bracket_game_numbers[8][24][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[8][24][6]=  array("Team 11","Team 12","P", "", "", "");
$bracket_game_numbers[8][24][7] = array("Team 13","Team 14","P", "", "", "");
$bracket_game_numbers[8][24][8]=  array("Team 15","Team 16","P", "", "", "");
$bracket_game_numbers[8][24][9] = array("Team 17","Winner Game 1","P", "", "", "W-1");
$bracket_game_numbers[8][24][10]= array("Team 18","Winner Game 2","P", "", "", "W-2");
$bracket_game_numbers[8][24][11] = array("Team 19","Winner Game 3","P", "", "", "W-3");
$bracket_game_numbers[8][24][12] = array("Team 20","Winner Game 4","P", "", "", "W-4");
$bracket_game_numbers[8][24][13] = array("Team 21","Winner Game 5", "P", "", "", "W-5");
$bracket_game_numbers[8][24][14] = array("Team 22","Winner Game 6","P", "", "", "W-6");
$bracket_game_numbers[8][24][15] = array("Team 23","Winner Game 7","P", "", "", "W-7");
$bracket_game_numbers[8][24][16] = array("Team 24","Winner Game 8","P", "", "", "W-8");
$bracket_game_numbers[8][24][17] = array("Loser Game 1","Loser Game 2","P", "", "L-1", "L-2");
$bracket_game_numbers[8][24][18] = array("Loser Game 3","Loser Game 4","P", "", "L-3", "L-4");
$bracket_game_numbers[8][24][19] = array("Loser Game 5","Loser Game 6","P", "", "L-5", "L-6");
$bracket_game_numbers[8][24][20] = array("Loser Game 7","Loser Game 8","P", "", "L-7", "L-8");
$bracket_game_numbers[8][24][21] = array("Loser Game 9","Loser Game 10","P", "", "L-9", "L-10");
$bracket_game_numbers[8][24][22] = array("Loser Game 11","Loser Game 12","P", "", "L-11", "L-12");
$bracket_game_numbers[8][24][23] = array("Loser Game 13","Loser Game 14","P", "", "L-13", "L-14");
$bracket_game_numbers[8][24][24] = array("Loser Game 15","Loser Game 16","P", "", "L-15", "L-16");
$bracket_game_numbers[8][24][25] = array("Winner Game 9","Winner Game 10","P", "", "W-9", "W-10");
$bracket_game_numbers[8][24][26] = array("Winner Game 11","Winner Game 12","P", "", "W-11", "W-12");
$bracket_game_numbers[8][24][27] = array("Winner Game 13","Winner Game 14","P", "", "W-13", "W-14");
$bracket_game_numbers[8][24][28] = array("Winner Game 15","Winner Game 16","P", "", "W-15", "W-16");
$bracket_game_numbers[8][24][29] = array("Winner Game 17","Winner Game 18","P", "", "W-17", "W-18");
$bracket_game_numbers[8][24][30] = array("Winner Game 19","Winner Game 20","P", "", "W-19", "W-20");
$bracket_game_numbers[8][24][31] = array("Winner Game 21","Winner Game 22","P", "", "W-21", "W-22");
$bracket_game_numbers[8][24][32] = array("Winner Game 23","Winner Game 24","P", "", "W-23", "W-24");
$bracket_game_numbers[8][24][33] = array("Winner Game 29","Loser Game 28","P", "", "W-29", "L-28");
$bracket_game_numbers[8][24][34] = array("Winner Game 30","Loser Game 27","P", "", "W-30", "L-27");
$bracket_game_numbers[8][24][35] = array("Winner Game 31","Loser Game 26","P", "", "W-31", "L-26");
$bracket_game_numbers[8][24][36] = array("Winner Game 32","Loser Game 25","P", "", "W-32", "L-25");
$bracket_game_numbers[8][24][37] = array("Winner Game 25","Winner Game 26","P", "", "W-25", "W-26");
$bracket_game_numbers[8][24][38] = array("Winner Game 27","Winner Game 28","P", "", "W-27", "W-28");
$bracket_game_numbers[8][24][39] = array("Winner Game 33","Winner Game 34","P", "", "W-33", "W-34");
$bracket_game_numbers[8][24][40] = array("Winner Game 35","Winner Game 36","P", "", "W-35", "W-36");
$bracket_game_numbers[8][24][41] = array("Winner Game 39","Loser Game 37","P", "", "W-39", "L-37");
$bracket_game_numbers[8][24][42] = array("Winner Game 40","Loser Game 38","P", "", "W-40", "L-38");
$bracket_game_numbers[8][24][43] = array("Winner Game 37","Winner Game 38","P", "", "W-37", "W-38");
$bracket_game_numbers[8][24][44] = array("Winner Game 41","Winner Game 42","P", "", "W-41", "W-42");
$bracket_game_numbers[8][24][45] = array("Winner Game 44","Loser Game 43","P", "", "W-44", "L-43");
$bracket_game_numbers[8][24][46] = array("Winner Game 43","Winner Game 45","P", "", "W-43", "W-45");
$bracket_game_numbers[8][24][47] = array("Winner Game 46","Loser 46 If 1st Loss","P", "", "W-46", "L-46");


$bracket_game_numbers[8][25][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][25][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][25][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][25][4] = array("Team 7", "Team 8", "P", "", "" ,"");
$bracket_game_numbers[8][25][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[8][25][6]=  array("Team 11","Team 12","P", "", "", "");
$bracket_game_numbers[8][25][7] = array("Team 13","Team 14","P", "", "", "");
$bracket_game_numbers[8][25][8]=  array("Team 15","Team 16","P", "", "", "");
$bracket_game_numbers[8][25][9] = array("Team 17","Team 18","P", "", "", "");
$bracket_game_numbers[8][25][10] = array("Team 19","Winner Game 1","P", "", "", "W-1");
$bracket_game_numbers[8][25][11] = array("Team 20","Winner Game 2","P", "", "", "W-2");
$bracket_game_numbers[8][25][12] = array("Team 21","Winner Game 3", "P", "", "", "W-3");
$bracket_game_numbers[8][25][13] = array("Team 22","Winner Game 4","P", "", "", "W-4");
$bracket_game_numbers[8][25][14] = array("Team 23","Winner Game 5","P", "", "", "W-5");
$bracket_game_numbers[8][25][15] = array("Winner Game 6","Winner Game 7","P", "", "W-6", "W-7");
$bracket_game_numbers[8][25][16] = array("Team 24","Winner Game 7","P", "", "", "W-7");
$bracket_game_numbers[8][25][17] = array("Team 25","Winner Game 8","P", "", "", "W-8");
$bracket_game_numbers[8][25][18] = array("Loser Game 1","Loser Game 2","P", "", "L-1", "L-2");
$bracket_game_numbers[8][25][19] = array("Loser Game 3","Loser Game 4","P", "", "L-3", "L-4");
$bracket_game_numbers[8][25][20] = array("Loser Game 5","Loser Game 6","P", "", "L-5", "L-6");
$bracket_game_numbers[8][25][21] = array("Loser Game 7","Loser Game 8","P", "", "L-7", "L-8");
$bracket_game_numbers[8][25][22] = array("Loser Game 9","Loser Game 10","P", "", "L-9", "L-10");
$bracket_game_numbers[8][25][23] = array("Loser Game 11","Loser Game 12","P", "", "L-11", "L-12");
$bracket_game_numbers[8][25][24] = array("Loser Game 13","Loser Game 14","P", "", "L-13", "L-14");
$bracket_game_numbers[8][25][25] = array("Loser Game 15","Loser Game 16","P", "", "L-15", "L-16");
$bracket_game_numbers[8][25][26] = array("Loser Game 17","Winner Game 18","P", "", "L-17", "W-18");
$bracket_game_numbers[8][25][27] = array("Winner Game 10","Winner Game 11","P", "", "W-10", "W-11");
$bracket_game_numbers[8][25][28] = array("Winner Game 12","Winner Game 13","P", "", "W-12", "W-13");
$bracket_game_numbers[8][25][29] = array("Winner Game 14","Winner Game 15","P", "", "W-14", "W-15");
$bracket_game_numbers[8][25][30] = array("Winner Game 16","Winner Game 17","P", "", "W-16", "W-17");
$bracket_game_numbers[8][25][31] = array("Winner Game 19","Winner Game 20","P", "", "W-19", "W-20");
$bracket_game_numbers[8][25][32] = array("Winner Game 21","Winner Game 22","P", "", "W-21", "W-22");
$bracket_game_numbers[8][25][33] = array("Winner Game 23","Winner Game 24","P", "", "W-23", "W-24");
$bracket_game_numbers[8][25][34] = array("Winner Game 25","Winner Game 26","P", "", "W-25", "W-26");
$bracket_game_numbers[8][25][35] = array("Winner Game 31","Loser Game 27","P", "", "W-31", "L-27");
$bracket_game_numbers[8][25][36] = array("Winner Game 32","Loser Game 25","P", "", "W-32", "L-25");
$bracket_game_numbers[8][25][37] = array("Winner Game 33","Loser Game 29","P", "", "W-33", "L-29");
$bracket_game_numbers[8][25][38] = array("Winner Game 34","Loser Game 30","P", "", "W-34", "L-30");
$bracket_game_numbers[8][25][39] = array("Winner Game 27","Winner Game 28","P", "", "W-27", "W-28");
$bracket_game_numbers[8][25][40] = array("Winner Game 29","Winner Game 30","P", "", "W-29", "W-30");
$bracket_game_numbers[8][25][41] = array("Winner Game 35","Winner Game 36","P", "", "W-35", "W-36");
$bracket_game_numbers[8][25][42] = array("Winner Game 37","Winner Game 38","P", "", "W-37", "W-38");
$bracket_game_numbers[8][25][43] = array("Winner Game 41","Loser Game 40","P", "", "W-41", "L-40");
$bracket_game_numbers[8][25][44] = array("Winner Game 42","Loser Game 39","P", "", "W-42", "L-39");
$bracket_game_numbers[8][25][45] = array("Winner Game 39","Winner Game 40","P", "", "W-39", "W-40");
$bracket_game_numbers[8][25][46] = array("Winner Game 43","Winner Game 44","P", "", "W-43", "W-44");
$bracket_game_numbers[8][25][47] = array("Winner Game 46","Loser Game 45","P", "", "W-46", "L-45");
$bracket_game_numbers[8][25][48] = array("Winner Game 45","Winner Game 47","P", "", "W-45", "W-47");
$bracket_game_numbers[8][25][49] = array("Winner Game 48","Loser 48 If 1st Loss","P", "", "W-48", "L-48");

$bracket_game_numbers[8][26][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][26][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][26][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][26][4] = array("Team 7", "Team 8", "P", "", "" ,"");
$bracket_game_numbers[8][26][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[8][26][6]=  array("Team 11","Team 12","P", "", "", "");
$bracket_game_numbers[8][26][7] = array("Team 13","Team 14","P", "", "", "");
$bracket_game_numbers[8][26][8]=  array("Team 15","Team 16","P", "", "", "");
$bracket_game_numbers[8][26][9] = array("Team 17","Team 18","P", "", "", "");
$bracket_game_numbers[8][26][10] = array("Team 19","Team 20","P", "", "", "");
$bracket_game_numbers[8][26][11] = array("Team 21","Winner Game 1","P", "", "", "W-1");
$bracket_game_numbers[8][26][12] = array("Team 22","Winner Game 2", "P", "", "", "W-2");
$bracket_game_numbers[8][26][13] = array("Winner Game 3","Winner Game 4","P", "", "W-3", "W-4");
$bracket_game_numbers[8][26][14] = array("Team 23","Winner Game 5","P", "", "", "W-5");
$bracket_game_numbers[8][26][15] = array("Team 24","Winner Game 6","P", "", "", "W-6");
$bracket_game_numbers[8][26][16] = array("Winner Game 7","Winner Game 8","P", "", "W-7", "W-8");
$bracket_game_numbers[8][26][17] = array("Team 25","Winner Game 9","P", "", "", "W-9");
$bracket_game_numbers[8][26][18] = array("Team 26","Winner Game 10","P", "", "", "W-10");
$bracket_game_numbers[8][26][19] = array("Loser Game 1","Loser Game 2","P", "", "L-1", "L-2");
$bracket_game_numbers[8][26][20] = array("Loser Game 3","Loser Game 4","P", "", "L-3", "L-4");
$bracket_game_numbers[8][26][21] = array("Loser Game 5","Loser Game 6","P", "", "L-5", "L-6");
$bracket_game_numbers[8][26][22] = array("Loser Game 7","Loser Game 8","P", "", "L-7", "L-8");
$bracket_game_numbers[8][26][23] = array("Loser Game 9","Loser Game 10","P", "", "L-9", "L-10");
$bracket_game_numbers[8][26][24] = array("Loser Game 11","Loser Game 12","P", "", "L-11", "L-12");
$bracket_game_numbers[8][26][25] = array("Loser Game 13","Loser Game 14","P", "", "L-13", "L-14");
$bracket_game_numbers[8][26][26] = array("Loser Game 15","Loser Game 16","P", "", "L-15", "L-16");
$bracket_game_numbers[8][26][27] = array("Loser Game 17","Winner Game 19","P", "", "L-17", "W-19");
$bracket_game_numbers[8][26][28] = array("Loser Game 18","Winner Game 20","P", "", "L-18", "W-20");
$bracket_game_numbers[8][26][29] = array("Winner Game 11","Winner Game 12","P", "", "W-11", "W-12");
$bracket_game_numbers[8][26][30] = array("Winner Game 13","Winner Game 14","P", "", "W-13", "W-14");
$bracket_game_numbers[8][26][31] = array("Winner Game 15","Winner Game 16","P", "", "W-15", "W-16");
$bracket_game_numbers[8][26][32] = array("Winner Game 17","Winner Game 18","P", "", "W-17", "W-18");
$bracket_game_numbers[8][26][33] = array("Winner Game 21","Winner Game 27","P", "", "W-21", "W-27");
$bracket_game_numbers[8][26][34] = array("Winner Game 22","Winner Game 23","P", "", "W-22", "W-23");
$bracket_game_numbers[8][26][35] = array("Winner Game 24","Winner Game 25","P", "", "W-24", "W-25");
$bracket_game_numbers[8][26][36] = array("Winner Game 26","Winner Game 28","P", "", "W-26", "W-28");
$bracket_game_numbers[8][26][37] = array("Winner Game 33","Loser Game 29","P", "", "W-33", "L-29");
$bracket_game_numbers[8][26][38] = array("Winner Game 34","Loser Game 30","P", "", "W-34", "L-30");
$bracket_game_numbers[8][26][39] = array("Winner Game 35","Loser Game 31","P", "", "W-35", "L-31");
$bracket_game_numbers[8][26][40] = array("Winner Game 36","Loser Game 32","P", "", "W-36", "L-32");
$bracket_game_numbers[8][26][41] = array("Winner Game 29","Winner Game 30","P", "", "W-29", "W-30");
$bracket_game_numbers[8][26][42] = array("Winner Game 31","Winner Game 32","P", "", "W-31", "W-32");
$bracket_game_numbers[8][26][43] = array("Winner Game 37","Winner Game 38","P", "", "W-37", "W-38");
$bracket_game_numbers[8][26][44] = array("Winner Game 39","Winner Game 40","P", "", "W-39", "W-40");
$bracket_game_numbers[8][26][45] = array("Winner Game 43","Loser Game 42","P", "", "W-43", "L-42");
$bracket_game_numbers[8][26][46] = array("Winner Game 44","Loser Game 41","P", "", "W-44", "L-41");
$bracket_game_numbers[8][26][47] = array("Winner Game 41","Winner Game 42","P", "", "W-41", "W-42");
$bracket_game_numbers[8][26][48] = array("Winner Game 45","Winner Game 46","P", "", "W-45", "W-46");
$bracket_game_numbers[8][26][49] = array("Winner Game 48","Loser Game 47","P", "", "W-48", "L-47");
$bracket_game_numbers[8][26][50] = array("Winner Game 47","Winner Game 49","P", "", "W-47", "W-49");
$bracket_game_numbers[8][26][51] = array("Winner Game 50","Loser 50 If 1st Loss","P", "", "W-50", "L-50");


$bracket_game_numbers[8][27][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][27][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][27][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][27][4] = array("Team 7", "Team 8", "P", "", "" ,"");
$bracket_game_numbers[8][27][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[8][27][6]=  array("Team 11","Team 12","P", "", "", "");
$bracket_game_numbers[8][27][7] = array("Team 13","Team 14","P", "", "", "");
$bracket_game_numbers[8][27][8]=  array("Team 15","Team 16","P", "", "", "");
$bracket_game_numbers[8][27][9] = array("Team 17","Team 18","P", "", "", "");
$bracket_game_numbers[8][27][10] = array("Team 19","Team 20","P", "", "", "");
$bracket_game_numbers[8][27][11] = array("Team 21","Team 22","P", "", "", "");
$bracket_game_numbers[8][27][12] = array("Team 23","Winner Game 1", "P", "", "", "W-1");
$bracket_game_numbers[8][27][13] = array("Team 24","Winner Game 2","P", "", "", "W-2");
$bracket_game_numbers[8][27][14] = array("Winner Game 3","Winner Game 4","P", "", "W-3", "W-4");
$bracket_game_numbers[8][27][15] = array("Team 25","Winner Game 5","P", "", "", "W-5");
$bracket_game_numbers[8][27][16] = array("Team 26","Winner Game 6","P", "", "", "W-6");
$bracket_game_numbers[8][27][17] = array("Winner Game 7","Winner Game 8","P", "", "W-7", "W-8");
$bracket_game_numbers[8][27][18] = array("Winner Game 9","Winner Game 10","P", "", "W-9", "W-10");
$bracket_game_numbers[8][27][19] = array("Team 27","Winner Game 11","P", "", "", "W-11");
$bracket_game_numbers[8][27][20] = array("Loser Game 1","Loser Game 2","P", "", "L-1", "L-2");
$bracket_game_numbers[8][27][21] = array("Loser Game 3","Loser Game 4","P", "", "L-3", "L-4");
$bracket_game_numbers[8][27][22] = array("Loser Game 5","Loser Game 6","P", "", "L-5", "L-6");
$bracket_game_numbers[8][27][23] = array("Loser Game 7","Loser Game 8","P", "", "L-7", "L-8");
$bracket_game_numbers[8][27][24] = array("Loser Game 9","Loser Game 10","P", "", "L-9", "L-10");
$bracket_game_numbers[8][27][25] = array("Loser Game 11","Loser Game 12","P", "", "L-11", "L-12");
$bracket_game_numbers[8][27][26] = array("Loser Game 13","Loser Game 14","P", "", "L-23", "L-14");
$bracket_game_numbers[8][27][27] = array("Loser Game 15","Loser Game 16","P", "", "L-15", "L-16");
$bracket_game_numbers[8][27][28] = array("Loser Game 17","Winner Game 20","P", "", "L-17", "W-20");
$bracket_game_numbers[8][27][29] = array("Loser Game 18","Winner Game 21","P", "", "L-18", "W-21");
$bracket_game_numbers[8][27][30] = array("Loser Game 19","Winner Game 22","P", "", "L-19", "W-22");
$bracket_game_numbers[8][27][31] = array("Winner Game 12","Winner Game 13","P", "", "W-12", "W-13");
$bracket_game_numbers[8][27][32] = array("Winner Game 14","Winner Game 15","P", "", "W-14", "W-15");
$bracket_game_numbers[8][27][33] = array("Winner Game 16","Winner Game 17","P", "", "W-16", "W-17");
$bracket_game_numbers[8][27][34] = array("Winner Game 18","Winner Game 19","P", "", "W-18", "W-19");
$bracket_game_numbers[8][27][35] = array("Winner Game 23","Winner Game 28","P", "", "W-23", "W-28");
$bracket_game_numbers[8][27][36] = array("Winner Game 24","Winner Game 25","P", "", "W-24", "W-25");
$bracket_game_numbers[8][27][37] = array("Winner Game 26","Winner Game 29","P", "", "W-26", "W-29");
$bracket_game_numbers[8][27][38] = array("Winner Game 27","Winner Game 30","P", "", "W-27", "W-30");
$bracket_game_numbers[8][27][39] = array("Winner Game 35","Loser Game 31","P", "", "W-35", "L-31");
$bracket_game_numbers[8][27][40] = array("Winner Game 36","Loser Game 32","P", "", "W-36", "L-32");
$bracket_game_numbers[8][27][41] = array("Winner Game 37","Loser Game 33","P", "", "W-37", "L-33");
$bracket_game_numbers[8][27][42] = array("Winner Game 38","Loser Game 34","P", "", "W-38", "L-34");
$bracket_game_numbers[8][27][43] = array("Winner Game 31","Winner Game 32","P", "", "W-31", "W-32");
$bracket_game_numbers[8][27][44] = array("Winner Game 33","Winner Game 34","P", "", "W-33", "W-34");
$bracket_game_numbers[8][27][45] = array("Winner Game 39","Winner Game 40","P", "", "W-39", "W-40");
$bracket_game_numbers[8][27][46] = array("Winner Game 41","Winner Game 42","P", "", "W-41", "W-42");
$bracket_game_numbers[8][27][47] = array("Winner Game 45","Loser Game 44","P", "", "W-45", "L-44");
$bracket_game_numbers[8][27][48] = array("Winner Game 46","Loser Game 43","P", "", "W-46", "L-43");
$bracket_game_numbers[8][27][49] = array("Winner Game 43","Winner Game 44","P", "", "W-43", "W-44");
$bracket_game_numbers[8][27][50] = array("Winner Game 47","Winner Game 48","P", "", "W-47", "W-48");
$bracket_game_numbers[8][27][51] = array("Winner Game 50","Loser Game 49","P", "", "W-50", "L-49");
$bracket_game_numbers[8][27][52] = array("Winner Game 49","Winner Game 51","P", "", "W-49", "W-51");
$bracket_game_numbers[8][27][53] = array("Winner Game 51","Loser 51 If 1st Loss","P", "", "W-51", "L-51");


$bracket_game_numbers[8][28][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][28][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][28][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][28][4] = array("Team 7", "Team 8", "P", "", "" ,"");
$bracket_game_numbers[8][28][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[8][28][6]=  array("Team 11","Team 12","P", "", "", "");
$bracket_game_numbers[8][28][7] = array("Team 13","Team 14","P", "", "", "");
$bracket_game_numbers[8][28][8]=  array("Team 15","Team 16","P", "", "", "");
$bracket_game_numbers[8][28][9] = array("Team 17","Team 18","P", "", "", "");
$bracket_game_numbers[8][28][10] = array("Team 19","Team 20","P", "", "", "");
$bracket_game_numbers[8][28][11] = array("Team 21","Team 22","P", "", "", "");
$bracket_game_numbers[8][28][12] = array("Team 23","Team 24", "P", "", "", "");
$bracket_game_numbers[8][28][13] = array("Team 25","Winner Game 1","P", "", "", "W-1");
$bracket_game_numbers[8][28][14] = array("Winner Game 2","Winner Game 3","P", "", "W-2", "W-3");
$bracket_game_numbers[8][28][15] = array("Winner Game 4","Winner Game 5","P", "", "W-4", "W-5");
$bracket_game_numbers[8][28][16] = array("Team 26","Winner Game 6","P", "", "", "W-6");
$bracket_game_numbers[8][28][17] = array("Team 27","Winner Game 7","P", "", "", "W-7");
$bracket_game_numbers[8][28][18] = array("Winner Game 8","Winner Game 9","P", "", "W-8", "W-9");
$bracket_game_numbers[8][28][19] = array("Winner Game 10","Winner Game 11","P", "", "W-10", "W-11");
$bracket_game_numbers[8][28][20] = array("Team 28","Winner Game 12","P", "", "", "W-12");
$bracket_game_numbers[8][28][21] = array("Loser Game 1","Loser Game 2","P", "", "L-1", "L-2");
$bracket_game_numbers[8][28][22] = array("Loser Game 3","Loser Game 4","P", "", "L-3", "L-4");
$bracket_game_numbers[8][28][23] = array("Loser Game 5","Loser Game 6","P", "", "L-5", "L-6");
$bracket_game_numbers[8][28][24] = array("Loser Game 7","Loser Game 8","P", "", "L-7", "L-8");
$bracket_game_numbers[8][28][25] = array("Loser Game 9","Loser Game 10","P", "", "L-9", "L-10");
$bracket_game_numbers[8][28][26] = array("Loser Game 11","Loser Game 12","P", "", "L-11", "L-12");
$bracket_game_numbers[8][28][27] = array("Loser Game 13","Loser Game 14","P", "", "L-13", "L-14");
$bracket_game_numbers[8][28][28] = array("Loser Game 15","Loser Game 16","P", "", "L-15", "L-16");
$bracket_game_numbers[8][28][29] = array("Loser Game 17","Winner Game 21","P", "", "L-17", "W-21");
$bracket_game_numbers[8][28][30] = array("Loser Game 18","Winner Game 22","P", "", "L-18", "W-22");
$bracket_game_numbers[8][28][31] = array("Loser Game 19","Winner Game 23","P", "", "L-19", "W-23");
$bracket_game_numbers[8][28][32] = array("Loser Game 20","Winner Game 24","P", "", "L-20", "W-24");
$bracket_game_numbers[8][28][33] = array("Winner Game 25","Winner Game 29","P", "", "W-25", "W-26");
$bracket_game_numbers[8][28][34] = array("Winner Game 26","Winner Game 30","P", "", "W-26", "W-30");
$bracket_game_numbers[8][28][35] = array("Winner Game 27","Winner Game 31","P", "", "W-27", "W-31");
$bracket_game_numbers[8][28][36] = array("Winner Game 28","Winner Game 32","P", "", "W-28", "W-32");
$bracket_game_numbers[8][28][37] = array("Winner Game 13","Winner Game 14","P", "", "W-13", "W-14");
$bracket_game_numbers[8][28][38] = array("Winner Game 15","Winner Game 16","P", "", "W-15", "W-16");
$bracket_game_numbers[8][28][39] = array("Winner Game 17","Winner Game 18","P", "", "W-17", "W-18");
$bracket_game_numbers[8][28][40] = array("Winner Game 19","Winner Game 20","P", "", "W-19", "W-20");
$bracket_game_numbers[8][28][41] = array("Winner Game 33","Loser Game 37","P", "", "W-33", "L-37");
$bracket_game_numbers[8][28][42] = array("Winner Game 34","Loser Game 38","P", "", "W-34", "L-38");
$bracket_game_numbers[8][28][43] = array("Winner Game 35","Loser Game 39","P", "", "W-35", "L-39");
$bracket_game_numbers[8][28][44] = array("Winner Game 36","Loser Game 40","P", "", "W-36", "L-40");
$bracket_game_numbers[8][28][45] = array("Winner Game 37","Winner Game 38","P", "", "W-37", "W-38");
$bracket_game_numbers[8][28][46] = array("Winner Game 39","Winner Game 40","P", "", "W-39", "W-40");
$bracket_game_numbers[8][28][47] = array("Winner Game 41","Winner Game 42","P", "", "W-41", "W-42");
$bracket_game_numbers[8][28][48] = array("Winner Game 43","Winner Game 44","P", "", "W-43", "W-44");
$bracket_game_numbers[8][28][49] = array("Winner Game 47","Loser Game 46","P", "", "W-47", "L-46");
$bracket_game_numbers[8][28][50] = array("Winner Game 48","Loser Game 45","P", "", "W-48", "L-45");
$bracket_game_numbers[8][28][51] = array("Winner Game 45","Winner Game 46","P", "", "W-45", "W-46");
$bracket_game_numbers[8][28][52] = array("Winner Game 49","Winner Game 50","P", "", "W-49", "W-50");
$bracket_game_numbers[8][28][53] = array("Winner Game 52","Loser Game 51","P", "", "W-52", "L-51");
$bracket_game_numbers[8][28][54] = array("Winner Game 51","Winner Game 53","P", "", "W-51", "W-53");
$bracket_game_numbers[8][28][55] = array("Winner Game 54","Loser 55 If 1st Loss","P", "", "W-54", "L-54");


$bracket_game_numbers[8][29][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][29][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][29][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][29][4] = array("Team 7", "Team 8", "P", "", "" ,"");
$bracket_game_numbers[8][29][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[8][29][6]=  array("Team 11","Team 12","P", "", "", "");
$bracket_game_numbers[8][29][7] = array("Team 13","Team 14","P", "", "", "");
$bracket_game_numbers[8][29][8]=  array("Team 15","Team 16","P", "", "", "");
$bracket_game_numbers[8][29][9] = array("Team 17","Team 18","P", "", "", "");
$bracket_game_numbers[8][29][10] = array("Team 19","Team 20","P", "", "", "");
$bracket_game_numbers[8][29][11] = array("Team 21","Team 22","P", "", "", "");
$bracket_game_numbers[8][29][12] = array("Team 23","Team 24", "P", "", "", "");
$bracket_game_numbers[8][29][13] = array("Team 25","Team 26","P", "", "", "");
$bracket_game_numbers[8][29][14] = array("Team 27","Winner Game 1","P", "", "", "W-1");
$bracket_game_numbers[8][29][15] = array("Winner Game 2","Winner Game 3","P", "", "W-2", "W-3");
$bracket_game_numbers[8][29][16] = array("Winner Game 4","Winner Game 5","P", "", "W-4", "W-5");
$bracket_game_numbers[8][29][17] = array("Team 28","Winner Game 6","P", "", "", "W-6");
$bracket_game_numbers[8][29][18] = array("Winner Game 7","Winner Game 8","P", "", "W-7", "W-8");
$bracket_game_numbers[8][29][19] = array("Winner Game 9","Winner Game 10","P", "", "W-9", "W-10");
$bracket_game_numbers[8][29][20] = array("Winner Game 11","Winner Game 12","P", "", "W-11", "W-12");
$bracket_game_numbers[8][29][21] = array("Team 29","Winner Game 13","P", "", "", "W-13");
$bracket_game_numbers[8][29][22] = array("Loser Game 1","Loser Game 2","P", "", "L-1", "L-2");
$bracket_game_numbers[8][29][23] = array("Loser Game 3","Loser Game 4","P", "", "L-3", "L-4");
$bracket_game_numbers[8][29][24] = array("Loser Game 5","Loser Game 6","P", "", "L-5", "L-6");
$bracket_game_numbers[8][29][25] = array("Loser Game 7","Loser Game 8","P", "", "L-7", "L-8");
$bracket_game_numbers[8][29][26] = array("Loser Game 9","Loser Game 10","P", "", "L-9", "L-10");
$bracket_game_numbers[8][29][27] = array("Loser Game 11","Loser Game 12","P", "", "L-11", "L-12");
$bracket_game_numbers[8][29][28] = array("Loser Game 13","Loser Game 14","P", "", "L-13", "L-14");
$bracket_game_numbers[8][29][29] = array("Loser Game 15","Loser Game 16","P", "", "L-15", "L-16");
$bracket_game_numbers[8][29][30] = array("Loser Game 21","Winner Game 22","P", "", "L-21", "W-22");
$bracket_game_numbers[8][29][31] = array("Loser Game 20","Winner Game 23","P", "", "L-20", "W-23");
$bracket_game_numbers[8][29][32] = array("Loser Game 19","Winner Game 24","P", "", "L-19", "W-24");
$bracket_game_numbers[8][29][33] = array("Loser Game 16","Winner Game 25","P", "", "L-16", "W-25");
$bracket_game_numbers[8][29][34] = array("Loser Game 15","Winner Game 26","P", "", "L-15", "W-26");
$bracket_game_numbers[8][29][35] = array("Winner Game 14","Winner Game 15","P", "", "W-14", "W-15");
$bracket_game_numbers[8][29][36] = array("Winner Game 16","Winner Game 17","P", "", "W-16", "W-17");
$bracket_game_numbers[8][29][37] = array("Winner Game 18","Winner Game 19","P", "", "W-18", "W-19");
$bracket_game_numbers[8][29][38] = array("Winner Game 20","Winner Game 21","P", "", "W-20", "W-21");
$bracket_game_numbers[8][29][39] = array("Winner Game 30","Winner Game 31","P", "", "W-30", "W-31");
$bracket_game_numbers[8][29][40] = array("Winner Game 27","Winner Game 32","P", "", "W-27", "W-32");
$bracket_game_numbers[8][29][41] = array("Winner Game 28","Winner Game 33","P", "", "W-28", "W-33");
$bracket_game_numbers[8][29][42] = array("Winner Game 29","Winner Game 34","P", "", "W-29", "W-34");
$bracket_game_numbers[8][29][43] = array("Winner Game 39","Loser Game 35","P", "", "W-39", "L-35");
$bracket_game_numbers[8][29][44] = array("Winner Game 40","Loser Game 36","P", "", "W-40", "L-36");
$bracket_game_numbers[8][29][45] = array("Winner Game 41","Loser Game 37","P", "", "W-41", "L-37");
$bracket_game_numbers[8][29][46] = array("Winner Game 42","Loser Game 38","P", "", "W-42", "L-38");
$bracket_game_numbers[8][29][47] = array("Winner Game 35","Winner Game 36","P", "", "W-35", "W-36");
$bracket_game_numbers[8][29][48] = array("Winner Game 37","Winner Game 38","P", "", "W-37", "W-38");
$bracket_game_numbers[8][29][49] = array("Winner Game 43","Winner Game 44","P", "", "W-43", "W-44");
$bracket_game_numbers[8][29][50] = array("Winner Game 45","Winner Game 46","P", "", "W-45", "W-46");
$bracket_game_numbers[8][29][51] = array("Winner Game 49","Loser Game 48","P", "", "W-49", "L-48");
$bracket_game_numbers[8][29][52] = array("Winner Game 50","Loser Game 47","P", "", "W-50", "L-47");
$bracket_game_numbers[8][29][53] = array("Winner Game 47","Winner Game 48","P", "", "W-47", "W-48");
$bracket_game_numbers[8][29][54] = array("Winner Game 51","Winner Game 52","P", "", "W-51", "W-52");
$bracket_game_numbers[8][29][55] = array("Winner Game 54","Loser Game 53","P", "", "W-54", "L-53");
$bracket_game_numbers[8][29][56] = array("Winner Game 53","Winner Game 55","P", "", "W-53", "W-55");
$bracket_game_numbers[8][29][57] = array("Winner Game 56","Loser 56 If 1st Loss","P", "", "W-56", "L-56");





$bracket_game_numbers[8][30][1] = array("Team 1","Team 2","P", "", "", "");
$bracket_game_numbers[8][30][2] = array("Team 3","Team 4", "P", "", "", "");
$bracket_game_numbers[8][30][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[8][30][4] = array("Team 7", "Team 8", "P", "", "" ,"");
$bracket_game_numbers[8][30][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[8][30][6]=  array("Team 11","Team 12","P", "", "", "");
$bracket_game_numbers[8][30][7] = array("Team 13","Team 14","P", "", "", "");
$bracket_game_numbers[8][30][8]=  array("Team 15","Team 16","P", "", "", "");
$bracket_game_numbers[8][30][9] = array("Team 17","Team 18","P", "", "", "");
$bracket_game_numbers[8][30][10] = array("Team 19","Team 20","P", "", "", "");
$bracket_game_numbers[8][30][11] = array("Team 21","Team 22","P", "", "", "");
$bracket_game_numbers[8][30][12] = array("Team 23","Team 24", "P", "", "", "");
$bracket_game_numbers[8][30][13] = array("Team 25","Team 26","P", "", "", "");
$bracket_game_numbers[8][30][14] = array("Team 27","Team 28","P", "", "", "");
$bracket_game_numbers[8][30][15] = array("Team 29","Winner Game 1","P", "", "", "W-1");
$bracket_game_numbers[8][30][16] = array("Winner Game 2","Winner Game 3","P", "", "W-2", "W-3");
$bracket_game_numbers[8][30][17] = array("Winner Game 4","Winner Game 5","P", "", "W-4", "W-5");
$bracket_game_numbers[8][30][18] = array("Winner Game 6","Winner Game 7","P", "", "W-6", "W-7");
$bracket_game_numbers[8][30][19] = array("Winner Game 8","Winner Game 9","P", "", "W-8", "W-9");
$bracket_game_numbers[8][30][20] = array("Winner Game 10","Winner Game 11","P", "", "W-10", "W-11");
$bracket_game_numbers[8][30][21] = array("Winner Game 12","Winner Game 13","P", "", "W-12", "W-13");
$bracket_game_numbers[8][30][22] = array("Team 30","Winner Game 14","P", "", "", "W-14");
$bracket_game_numbers[8][30][23] = array("Loser Game 1","Loser Game 2","P", "", "L-1", "L-2");
$bracket_game_numbers[8][30][24] = array("Loser Game 3","Loser Game 4","P", "", "L-3", "L-4");
$bracket_game_numbers[8][30][25] = array("Loser Game 5","Loser Game 6","P", "", "L-5", "L-6");
$bracket_game_numbers[8][30][26] = array("Loser Game 7","Loser Game 8","P", "", "L-7", "L-8");
$bracket_game_numbers[8][30][27] = array("Loser Game 9","Loser Game 10","P", "", "L-9", "L-10");
$bracket_game_numbers[8][30][28] = array("Loser Game 11","Loser Game 12","P", "", "L-11", "L-12");
$bracket_game_numbers[8][30][29] = array("Loser Game 13","Loser Game 14","P", "", "L-13", "L-14");
$bracket_game_numbers[8][30][30] = array("Loser Game 15","Loser Game 16","P", "", "L-15", "L-16");
$bracket_game_numbers[8][30][31] = array("Loser Game 17","Winner Game 23","P", "", "L-17", "W-23");
$bracket_game_numbers[8][30][32] = array("Loser Game 18","Winner Game 24","P", "", "L-18", "W-24");
$bracket_game_numbers[8][30][33] = array("Loser Game 19","Winner Game 25","P", "", "L-19", "W-25");
$bracket_game_numbers[8][30][34] = array("Loser Game 20","Winner Game 26","P", "", "L-20", "W-26");
$bracket_game_numbers[8][30][35] = array("Loser Game 21","Winner Game 27","P", "", "L-21", "W-27");
$bracket_game_numbers[8][30][36] = array("Loser Game 22","Winner Game 28","P", "", "L-22", "W-28");
$bracket_game_numbers[8][30][37] = array("Winner Game 15","Winner Game 16","P", "", "W-15", "W-16");
$bracket_game_numbers[8][30][38] = array("Winner Game 17","Winner Game 18","P", "", "W-17", "W-18");
$bracket_game_numbers[8][30][39] = array("Winner Game 19","Winner Game 20","P", "", "W-19", "W-20");
$bracket_game_numbers[8][30][40] = array("Winner Game 21","Winner Game 22","P", "", "W-21", "W-22");
$bracket_game_numbers[8][30][41] = array("Winner Game 31","Winner Game 32","P", "", "W-31", "W-32");
$bracket_game_numbers[8][30][42] = array("Winner Game 29","Winner Game 33","P", "", "W-29", "W-33");
$bracket_game_numbers[8][30][43] = array("Winner Game 30","Winner Game 34","P", "", "W-30", "W-34");
$bracket_game_numbers[8][30][44] = array("Winner Game 35","Winner Game 36","P", "", "W-35", "W-36");
$bracket_game_numbers[8][30][45] = array("Loser Game 37","Winner Game 41","P", "", "L-37", "W-41");
$bracket_game_numbers[8][30][46] = array("Loser Game 38","Winner Game 42","P", "", "L-38", "W-42");
$bracket_game_numbers[8][30][47] = array("Loser Game 39","Winner Game 43","P", "", "L-39", "W-43");
$bracket_game_numbers[8][30][48] = array("Loser Game 40","Winner Game 44","P", "", "L-40", "W-44");
$bracket_game_numbers[8][30][49] = array("Winner Game 37","Winner Game 38","P", "", "W-37", "W-38");
$bracket_game_numbers[8][30][50] = array("Winner Game 39","Winner Game 40","P", "", "W-39", "W-40");
$bracket_game_numbers[8][30][51] = array("Winner Game 45","Winner Game 46","P", "", "W-45", "W-46");
$bracket_game_numbers[8][30][52] = array("Winner Game 47","Winner Game 48","P", "", "W-47", "W-48");
$bracket_game_numbers[8][30][53] = array("Loser Game 50","Winner Game 51","P", "", "L-50", "W-51");
$bracket_game_numbers[8][30][54] = array("Loser Game 49","Winner Game 52","P", "", "L-49", "W-52");
$bracket_game_numbers[8][30][55] = array("Winner Game 49","Winner Game 50","P", "", "W-49", "W-50");
$bracket_game_numbers[8][30][56] = array("Winner Game 53","Winner Game 54","P", "", "W-53", "W-54");
$bracket_game_numbers[8][30][57] = array("Loser Game 55","Winner Game 56","P", "", "L-55", "W-56");
$bracket_game_numbers[8][30][58] = array("Winner Game 55","Winner Game 57","P", "", "W-55", "W-57");
$bracket_game_numbers[8][30][59] = array("Winner Game 58","Loser 58 If 1st Loss","P", "", "W-58", "L-58");


//------------------------------3 Pool Single Elimination------------------------------------------//

$bracket_game_numbers[10][3][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[10][3][2] = array("Team 3", "Team 1", "P", "", "", "");
$bracket_game_numbers[10][3][3] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[10][3][4] = array("Team 1", "Team 2", "W", "", "", "");
$bracket_game_numbers[10][3][5] = array("Team 3", "Team 1", "", "W", "", "");
$bracket_game_numbers[10][3][6] = array("#2 Seed", "#3 Seed", "W", "", "#2", "#3");
$bracket_game_numbers[10][3][7] = array("#1 Seed", "Winner Game 6", "W", "", "#1", "W-6");

$bracket_game_numbers[10][4][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[10][4][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[10][4][3] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[10][4][4] = array("Team 4", "Team 1", "W", "", "", "");
$bracket_game_numbers[10][4][5] = array("Team 1", "Team 3", "", "W", "", "");
$bracket_game_numbers[10][4][6] = array("Team 2", "Team 3", "W", "", "", "");
$bracket_game_numbers[10][4][7] = array("#1 Seed", "#4 Seed", "", "W", "#1", "#4");
$bracket_game_numbers[10][4][8] = array("#2 Seed", "#3 Seed", "W", "", "#2", "#3");
$bracket_game_numbers[10][4][9] = array("Winner Game 7", "Winner Game 8", "W", "", "W-7", "W-8");


$bracket_game_numbers[10][5][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[10][5][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[10][5][3] = array("Team 5", "Team 1", "P", "", "", "");
$bracket_game_numbers[10][5][4] = array("Team 2", "Team 3", "", "W", "", "");
$bracket_game_numbers[10][5][5] = array("Team 4", "Team 5", "W", "", "", "");
$bracket_game_numbers[10][5][6] = array("Team 1", "Team 3", "", "W", "", "");
// $bracket_game_numbers[10][5][7] = array("Team 2", "Team 4", "W", "", "", "");//Old 
// $bracket_game_numbers[10][5][8] = array("Team 5", "Team 1", "W", "", "", "");
$bracket_game_numbers[10][5][7] = array("Team 5", "Team 2", "W", "", "", "");// change in 15 june 2015
$bracket_game_numbers[10][5][8] = array("Team 1", "Team 4", "W", "", "", "");
$bracket_game_numbers[10][5][9] = array("#4 Seed", "#5 Seed", "", "W", "#4", "#5");
$bracket_game_numbers[10][5][10] = array("#1 Seed", "Winner Game 9", "W", "", "#1", "W-9");
$bracket_game_numbers[10][5][11] = array("#2 Seed", "#3 Seed", "W", "", "#2", "#3");
$bracket_game_numbers[10][5][12] = array("Winner Game 10", "Winner Game 11", "W", "", "W-10", "W-11");


$bracket_game_numbers[10][6][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[10][6][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[10][6][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[10][6][4] = array("Team 2", "Team 3", "", "W", "", "");
$bracket_game_numbers[10][6][5] = array("Team 4", "Team 5", "W", "", "", "");
$bracket_game_numbers[10][6][6] = array("Team 6", "Team 1", "", "W", "", "");
$bracket_game_numbers[10][6][7] = array("Team 5", "Team 2", "W", "", "", "");
$bracket_game_numbers[10][6][8] = array("Team 3", "Team 6", "W", "", "#2", "#3");
$bracket_game_numbers[10][6][9] = array("Team 1", "Team 4", "", "W", "#1", "W-4");
$bracket_game_numbers[10][6][10] = array("#3 Seed", "#6 Seed", "W", "", "#3", "#6");
$bracket_game_numbers[10][6][11] = array("#4 Seed", "#5 Seed", "W", "", "#4", "#5");
$bracket_game_numbers[10][6][12] = array("#2 Seed", "Winner Game 10", "W", "", "#2", "W-10");
$bracket_game_numbers[10][6][13] = array("#1 Seed", "Winner Game 11", "W", "", "#1", "W-11");
$bracket_game_numbers[10][6][14] = array("Winner Game 12", "Winner Game 13", "W", "", "W-12", "W-13");


$bracket_game_numbers[10][7][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[10][7][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[10][7][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[10][7][4] = array("Team 7", "Team 1", "P", "", "", "");
$bracket_game_numbers[10][7][5] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[10][7][6] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[10][7][7] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[10][7][8] = array("Team 1", "Team 3", "P", "", "", "");
$bracket_game_numbers[10][7][9] = array("Team 2", "Team 4", "P", "", "", "");
$bracket_game_numbers[10][7][10] = array("Team 5", "Team 7", "W", "", "", "");
$bracket_game_numbers[10][7][11] = array("Team 6", "Team 1", "W", "", "", "");
$bracket_game_numbers[10][7][12] = array("#4 Seed", "#5 Seed", "W", "", "#4", "#5");
$bracket_game_numbers[10][7][13] = array("#3 Seed", "#6 Seed", "W", "", "#3", "#6");
$bracket_game_numbers[10][7][14] = array("#2 Seed", "#7 Seed", "W", "", "#2", "#7");
$bracket_game_numbers[10][7][15] = array("#1 Seed", "Winner Game 12", "W", "", "#1", "W-12");
$bracket_game_numbers[10][7][16] = array("Winner Game 13", "Winner Game 14", "W", "", "W-13", "W-14");
$bracket_game_numbers[10][7][17] = array("Winner Game 15", "Winner Game 16", "W", "", "W-15", "W-16");


$bracket_game_numbers[10][8][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[10][8][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[10][8][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[10][8][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[10][8][5] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[10][8][6] = array("Team 4", "Team 1", "P", "", "", "");
$bracket_game_numbers[10][8][7] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[10][8][8] = array("Team 8", "Team 5", "P", "", "", "");
$bracket_game_numbers[10][8][9] = array("Team 1", "Team 3", "P", "", "", "");
$bracket_game_numbers[10][8][10] = array("Team 2", "Team 4", "P", "", "", "");
// $bracket_game_numbers[10][8][11] = array("Team 3", "Team 5", "P", "", "", "");
$bracket_game_numbers[10][8][11] = array("Team 5", "Team 7", "P", "", "", ""); //changed on 07 july 2015
$bracket_game_numbers[10][8][12] = array("Team 6", "Team 8", "P", "", "", "");
$bracket_game_numbers[10][8][13] = array("#4 Seed", "#5 Seed", "W", "", "#4", "#5");
$bracket_game_numbers[10][8][14] = array("#1 Seed", "#8 Seed", "W", "", "#1", "#8");
$bracket_game_numbers[10][8][15] = array("#3 Seed", "#6 Seed", "W", "", "#3", "#6");
$bracket_game_numbers[10][8][16] = array("#2 Seed", "#7 Seed", "W", "", "#2", "#7");
$bracket_game_numbers[10][8][17] = array("Winner Game 13", "Winner Game 14", "W", "", "W-13", "W-14");
$bracket_game_numbers[10][8][18] = array("Winner Game 15", "Winner Game 16", "W", "", "W-15", "W-16");
$bracket_game_numbers[10][8][19] = array("Winner Game 17", "Winner Game 18", "W", "", "W-17", "W-18");



$bracket_game_numbers[10][9][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[10][9][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[10][9][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[10][9][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[10][9][5] = array("Team 9", "Team 1", "P", "", "", "");
$bracket_game_numbers[10][9][6] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[10][9][7] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[10][9][8] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[10][9][9] = array("Team 8", "Team 9", "P", "", "", "");
$bracket_game_numbers[10][9][10] = array("Team 1", "Team 3", "P", "", "", "");
$bracket_game_numbers[10][9][11] = array("Team 2", "Team 4", "P", "", "", "");
$bracket_game_numbers[10][9][12] = array("Team 5", "Team 7", "P", "", "", "");
$bracket_game_numbers[10][9][13] = array("Team 6", "Team 8", "P", "", "", "");
$bracket_game_numbers[10][9][14] = array("Team 9", "Team 1", "P", "", "", "");
$bracket_game_numbers[10][9][15] = array("#6 Seed", "#7 Seed", "P", "", "#6", "#7");
$bracket_game_numbers[10][9][16] = array("#5 Seed", "#8 Seed", "W", "", "#5", "#8");
$bracket_game_numbers[10][9][17] = array("#4 Seed", "#9 Seed", "W", "", "#4", "#9");
$bracket_game_numbers[10][9][18] = array("#2 Seed", "Winner Game 16", "W", "", "#2", "W-16");
$bracket_game_numbers[10][9][19] = array("#3 Seed", "Winner Game 17", "W", "", "#3", "W-17");
$bracket_game_numbers[10][9][20] = array("#1 Seed", "Winner Game 15", "W", "", "#1", "W-15");
$bracket_game_numbers[10][9][21] = array("Winner Game 18", "Winner Game 19", "W", "", "W-18", "W-19");
$bracket_game_numbers[10][9][22] = array("Winner Game 20", "Winner Game 21", "W", "", "W-20", "W-21");



$bracket_game_numbers[10][10][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[10][10][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[10][10][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[10][10][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[10][10][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[10][10][6] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[10][10][7] = array("Team 4", "Team 1", "P", "", "", "");
$bracket_game_numbers[10][10][8] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[10][10][9] = array("Team 5", "Team 9", "P", "", "", "");
$bracket_game_numbers[10][10][10] = array("Team 8", "Team 10", "P", "", "", "");
$bracket_game_numbers[10][10][11] = array("Team 1", "Team 3", "P", "", "", "");
$bracket_game_numbers[10][10][12] = array("Team 2", "Team 4", "P", "", "", "");
$bracket_game_numbers[10][10][13] = array("Team 5", "Team 7", "P", "", "", "");
$bracket_game_numbers[10][10][14] = array("Team 6", "Team 8", "P", "", "", "");
$bracket_game_numbers[10][10][15] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[10][10][16] = array("#5 Seed", "#6 Seed", "W", "", "#5", "#6");
$bracket_game_numbers[10][10][17] = array("#4 Seed", "#7 Seed", "W", "", "#4", "#7");
$bracket_game_numbers[10][10][18] = array("#3 Seed", "#8 Seed", "W", "", "#3", "#8");
$bracket_game_numbers[10][10][19] = array("#2 Seed", "#9 Seed", "W", "", "#2", "#9");
$bracket_game_numbers[10][10][20] = array("#1 Seed", "#10 Seed", "W", "", "#1", "#10");
$bracket_game_numbers[10][10][21] = array("Winner Game 16", "Winner Game 15", "W", "", "W-16", "W-15");
$bracket_game_numbers[10][10][22] = array("Winner Game 18", "Winner Game 17", "W", "", "W-18", "W-17");
$bracket_game_numbers[10][10][23] = array("Winner Game 20", "Winner Game 19", "W", "", "W-20", "W-19");
$bracket_game_numbers[10][10][24] = array("Winner Game 22", "Winner Game 21", "W", "", "W-22", "W-21");


$bracket_game_numbers[10][11][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[10][11][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[10][11][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[10][11][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[10][11][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[10][11][6] = array("Team 11", "Team 1", "P", "", "", "");
$bracket_game_numbers[10][11][7] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[10][11][8] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[10][11][9] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[10][11][10] = array("Team 8", "Team 9", "P", "", "", "");
$bracket_game_numbers[10][11][11] = array("Team 10", "Team 11", "P", "", "", "");
$bracket_game_numbers[10][11][12] = array("Team 1", "Team 3", "P", "", "", "");
$bracket_game_numbers[10][11][13] = array("Team 2", "Team 4", "P", "", "", "");
$bracket_game_numbers[10][11][14] = array("Team 5", "Team 7", "P", "", "", "");
$bracket_game_numbers[10][11][15] = array("Team 6", "Team 8", "P", "", "", "");
$bracket_game_numbers[10][11][16] = array("Team 9", "Team 11", "W", "", "", "");
$bracket_game_numbers[10][11][17] = array("Team 10", "Team 1", "W", "", "", "");
$bracket_game_numbers[10][11][18] = array("#6 Seed", "#7 Seed", "W", "", "#6", "#7");
$bracket_game_numbers[10][11][19] = array("#5 Seed", "#8 Seed", "W", "", "#5", "#8");
$bracket_game_numbers[10][11][20] = array("#4 Seed", "#9 Seed", "W", "", "#4", "#9");
$bracket_game_numbers[10][11][21] = array("#3 Seed", "#10 Seed", "W", "", "#3", "#10");
$bracket_game_numbers[10][11][22] = array("#2 Seed", "#11 Seed", "W", "", "#2", "#11");
$bracket_game_numbers[10][11][23] = array("#1 Seed", "Winner Game 18", "W", "", "#1", "W-18");
$bracket_game_numbers[10][11][24] = array("Winner Game 19", "Winner Game 20", "W", "", "W-19", "W-20");
$bracket_game_numbers[10][11][25] = array("Winner Game 21", "Winner Game 22", "W", "", "W-21", "W-22");
$bracket_game_numbers[10][11][26] = array("Winner Game 23", "Winner Game 24", "W", "", "W-23", "W-24");
$bracket_game_numbers[10][11][27] = array("Winner Game 25", "Winner Game 26", "W", "", "W-25", "W-26");


$bracket_game_numbers[10][12][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[10][12][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[10][12][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[10][12][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[10][12][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[10][12][6] = array("Team 11", "Team 12", "P", "", "", "");
$bracket_game_numbers[10][12][7] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[10][12][8] = array("Team 4", "Team 1", "P", "", "", "");
$bracket_game_numbers[10][12][9] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[10][12][10] = array("Team 8", "Team 5", "P", "", "", "");
$bracket_game_numbers[10][12][11] = array("Team 10", "Team 11", "P", "", "", "");
$bracket_game_numbers[10][12][12] = array("Team 12", "Team 9", "P", "", "", "");
$bracket_game_numbers[10][12][13] = array("Team 1", "Team 3", "P", "", "", "");
$bracket_game_numbers[10][12][14] = array("Team 2", "Team 4", "P", "", "", "");
$bracket_game_numbers[10][12][15] = array("Team 5", "Team 7", "P", "", "", "");
$bracket_game_numbers[10][12][16] = array("Team 6", "Team 8", "W", "", "", "");
$bracket_game_numbers[10][12][17] = array("Team 9", "Team 11", "W", "", "", "");
$bracket_game_numbers[10][12][18] = array("Team 10", "Team 12", "W", "", "", "");
$bracket_game_numbers[10][12][19] = array("#6 Seed", "#7 Seed", "W", "", "#6", "#7");
$bracket_game_numbers[10][12][20] = array("#1 Seed", "#12 Seed", "W", "", "#1", "#12");
$bracket_game_numbers[10][12][21] = array("#5 Seed", "#8 Seed", "W", "", "#5", "#8");
$bracket_game_numbers[10][12][22] = array("#3 Seed", "#10 Seed", "W", "", "#3", "#10");
$bracket_game_numbers[10][12][23] = array("#4 Seed", "#9 Seed", "W", "", "#4", "#9");
$bracket_game_numbers[10][12][24] = array("#2 Seed", "#11 Seed", "W", "", "#2", "#11");
$bracket_game_numbers[10][12][25] = array("Winner Game 21", "Winner Game 22", "W", "", "W-21", "W-22");
$bracket_game_numbers[10][12][26] = array("Winner Game 23", "Winner Game 24", "W", "", "W-23", "W-24");
$bracket_game_numbers[10][12][27] = array("Winner Game 19", "Winner Game 20", "W", "", "W-19", "W-20");
$bracket_game_numbers[10][12][28] = array("Winner Game 25", "Winner Game 26", "W", "", "W-25", "W-26");
$bracket_game_numbers[10][12][29] = array("Winner Game 27", "Winner Game 28", "W", "", "W-27", "W-28");


$bracket_game_numbers[10][13][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[10][13][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[10][13][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[10][13][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[10][13][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[10][13][6] = array("Team 11", "Team 12", "P", "", "", "");
$bracket_game_numbers[10][13][7] = array("Team 13", "Team 1", "P", "", "", "");
$bracket_game_numbers[10][13][8] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[10][13][9] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[10][13][10] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[10][13][11] = array("Team 8", "Team 9", "P", "", "", "");
$bracket_game_numbers[10][13][12] = array("Team 10", "Team 11", "P", "", "", "");
$bracket_game_numbers[10][13][13] = array("Team 12", "Team 13", "P", "", "", "");
$bracket_game_numbers[10][13][14] = array("Team 1", "Team 3", "P", "", "", "");
$bracket_game_numbers[10][13][15] = array("Team 2", "Team 4", "P", "", "", "");
$bracket_game_numbers[10][13][16] = array("Team 5", "Team 7", "W", "", "#4", "#5");
$bracket_game_numbers[10][13][17] = array("Team 6", "Team 8", "W", "", "#3", "#6");
$bracket_game_numbers[10][13][18] = array("Team 9", "Team 11", "W", "", "#1", "W-7");
$bracket_game_numbers[10][13][19] = array("Team 10", "Team 12", "W", "", "#2", "W-8");
$bracket_game_numbers[10][13][20] = array("Team 13", "Team 1", "W", "", "#1", "W-7");
$bracket_game_numbers[10][13][21] = array("#7 Seed", "#8 Seed", "W", "", "#2", "W-8");
$bracket_game_numbers[10][13][22] = array("#6 Seed", "#9 Seed", "W", "", "#1", "W-7");
$bracket_game_numbers[10][13][23] = array("#5 Seed", "#10 Seed", "W", "", "#2", "W-8");
$bracket_game_numbers[10][13][24] = array("#4 Seed", "#11 Seed", "W", "", "#2", "W-8");
$bracket_game_numbers[10][13][25] = array("#3 Seed", "#12 Seed", "W", "", "#2", "W-8");
$bracket_game_numbers[10][13][26] = array("#2 Seed", "#13 Seed", "W", "", "#2", "W-8");
$bracket_game_numbers[10][13][27] = array("#1 Seed", "Winner Game 21", "W", "", "#1", "W-21");
$bracket_game_numbers[10][13][28] = array("Winner Game 22", "Winner Game 23", "W", "", "W-22", "W-23");
$bracket_game_numbers[10][13][29] = array("Winner Game 24", "Winner Game 25", "W", "", "W-24", "W-25");
$bracket_game_numbers[10][13][30] = array("Winner Game 26", "Winner Game 27", "W", "", "W-26", "W-27");
$bracket_game_numbers[10][13][31] = array("Winner Game 28", "Winner Game 29", "W", "", "W-28", "W-29");
$bracket_game_numbers[10][13][32] = array("Winner Game 30", "Winner Game 31", "W", "", "W-30", "W-31");


/*---------------------2 Pool + Double Elimination--------------------------------*/

$bracket_game_numbers[11][3][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[11][3][2] = array("Team 3", "Team 1", "P", "", "", "");
$bracket_game_numbers[11][3][3] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][3][4] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[11][3][5] = array("Team 3", "Winner Game 4", "W", "", "", "");
$bracket_game_numbers[11][3][6] = array("Loser Game 4", "Loser Game 5", "W", "", "", "");
$bracket_game_numbers[11][3][7] = array("Winner Game 5", "Winner Game 6", "W", "", "W-5", "W-6");
$bracket_game_numbers[11][3][8] = array("Winner Game 7", "Loser 7 If 1st Loss", "W", "", "W-7", "L-7");


$bracket_game_numbers[11][4][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[11][4][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[11][4][3] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][4][4] = array("Team 4", "Team 1", "P", "", "", "");
$bracket_game_numbers[11][4][5] = array("Team 1", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][4][6] = array("Team 2", "Team 4", "P", "", "", "");
$bracket_game_numbers[11][4][7] = array("Winner Game 5", "Winner Game 6", "W", "", "W-5", "W-6");
$bracket_game_numbers[11][4][8] = array("Loser Game 5", "Loser Game 6", "W", "", "L-5", "L-6");
$bracket_game_numbers[11][4][9] = array("Winner Game 8", "Loser Game 7", "W", "", "W-8", "L-7");
$bracket_game_numbers[11][4][10] = array("Winner Game 7", "Winner Game 9", "W", "", "W-7", "W-9");
$bracket_game_numbers[11][4][11] = array("Winner Game 10", "Loser 10 If 1st Loss", "W", "", "W-10", "L-10");


$bracket_game_numbers[11][5][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[11][5][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[11][5][3] = array("Team 5", "Team 1", "P", "", "", "");
$bracket_game_numbers[11][5][4] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][5][5] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[11][5][6] = array("Team 1", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][5][7] = array("Team 2", "Team 4", "P", "", "", "");
$bracket_game_numbers[11][5][8] = array("Team 5", "Winner Game 6", "W", "", "", "W-6");
$bracket_game_numbers[11][5][9] = array("Loser Game 6", "Loser Game 7", "W", "", "L-6", "L-7");
$bracket_game_numbers[11][5][10] = array("Winner Game 7", "Winner Game 8", "W", "", "W-7", "W-8");
$bracket_game_numbers[11][5][11] = array("Winner Game 9", "Loser Game 8", "W", "", "W-9", "L-8");
$bracket_game_numbers[11][5][12] = array("Winner Game 11", "Loser Game 10", "W", "", "W-11", "L-10");
$bracket_game_numbers[11][5][13] = array("Winner Game 10", "Winner Game 12", "W", "", "W-10", "W-12");
$bracket_game_numbers[11][5][14] = array("Winner Game 13", "Loser 13 If 1st Loss", "W", "", "W-13", "L-13");


$bracket_game_numbers[11][6][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[11][6][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[11][6][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[11][6][4] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][6][5] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[11][6][6] = array("Team 6", "Team 1", "P", "", "", "");
$bracket_game_numbers[11][6][7] = array("Team 2", "Team 4", "P", "", "", "");
$bracket_game_numbers[11][6][8] = array("Team 1", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][6][9] = array("Team 5", "Winner Game 7", "W", "", "", "W-7");
$bracket_game_numbers[11][6][10] = array("Team 6", "Winner Game 8", "W", "", "", "W-8");
$bracket_game_numbers[11][6][11] = array("Loser Game 7", "Loser Game 8", "W", "", "L-7", "L-8");
$bracket_game_numbers[11][6][12] = array("Loser Game 9", "Loser Game 10", "W", "", "L-9", "L-10");
$bracket_game_numbers[11][6][13] = array("Winner Game 9", "Winner Game 10", "W", "", "W-9", "W-10");
$bracket_game_numbers[11][6][14] = array("Winner Game 11", "Winner Game 12", "W", "", "W-11", "W-12");
$bracket_game_numbers[11][6][15] = array("Winner Game 14", "Loser Game 13", "W", "", "W-14", "L-13");
$bracket_game_numbers[11][6][16] = array("Winner Game 13", "Winner Game 15", "W", "", "W-13", "W-15");
$bracket_game_numbers[11][6][17] = array("Winner Game 16", "Loser 16 If 1st Loss", "W", "", "W-16", "L-16");


$bracket_game_numbers[11][7][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[11][7][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[11][7][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[11][7][4] = array("Team 7", "Team 1", "P", "", "", "");
$bracket_game_numbers[11][7][5] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][7][6] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[11][7][7] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[11][7][8] = array("Team 1", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][7][9] = array("Team 2", "Team 4", "P", "", "", "");
$bracket_game_numbers[11][7][10] = array("Team 5", "Team 7", "P", "", "", "");
$bracket_game_numbers[11][7][11] = array("Team 6", "Winner Game 8", "W", "", "", "W-8");
$bracket_game_numbers[11][7][12] = array("Loser Game 8", "Loser Game 9", "W", "", "L-8", "L-9");
$bracket_game_numbers[11][7][13] = array("Winner Game 9", "Winner Game 10", "W", "", "W-9", "W-10");
$bracket_game_numbers[11][7][14] = array("Loser Game 10", "Loser Game 11", "W", "", "L-10", "L-11");
$bracket_game_numbers[11][7][15] = array("Winner Game 12", "Loser Game 13", "W", "", "W-12", "L-13");
$bracket_game_numbers[11][7][16] = array("Winner Game 11", "Winner Game 13", "W", "", "W-11", "W-13");
$bracket_game_numbers[11][7][17] = array("Winner Game 14", "Winner Game 15", "W", "", "W-14", "W-15");
$bracket_game_numbers[11][7][18] = array("Winner Game 17", "Loser Game 16", "W", "", "W-17", "L-16");
$bracket_game_numbers[11][7][19] = array("Winner Game 16", "Winner Game 18", "W", "", "W-16", "W-18");
$bracket_game_numbers[11][7][20] = array("Winner Game 19", "Loser 19 If 1st Loss", "W", "", "W-19", "L-19");


$bracket_game_numbers[11][8][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[11][8][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[11][8][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[11][8][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[11][8][5] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][8][6] = array("Team 4", "Team 1", "P", "", "", "");
$bracket_game_numbers[11][8][7] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[11][8][8] = array("Team 8", "Team 5", "P", "", "", "");
$bracket_game_numbers[11][8][9] = array("Team 1", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][8][10] = array("Team 2", "Team 4", "P", "", "", "");
$bracket_game_numbers[11][8][11] = array("Team 5", "Team 7", "P", "", "", "");
$bracket_game_numbers[11][8][12] = array("Team 6", "Team 8", "P", "", "", "");
$bracket_game_numbers[11][8][13] = array("Loser Game 9", "Loser Game 10", "W", "", "L-8", "L-10");
$bracket_game_numbers[11][8][14] = array("Loser Game 11", "Loser Game 12", "W", "", "L-11", "L-12");
$bracket_game_numbers[11][8][15] = array("Winner Game 9", "Winner Game 10", "W", "", "W-9", "W-10");
$bracket_game_numbers[11][8][16] = array("Winner Game 11", "Winner Game 12", "W", "", "W-11", "W-12");
$bracket_game_numbers[11][8][17] = array("Winner Game 14", "Loser Game 15", "W", "", "W-14", "L-15");
$bracket_game_numbers[11][8][18] = array("Winner Game 13", "Loser Game 16", "W", "", "W-13", "L-16");
$bracket_game_numbers[11][8][19] = array("Winner Game 15", "Winner Game 16", "W", "", "W-15", "W-16");
$bracket_game_numbers[11][8][20] = array("Winner Game 17", "Winner Game 18", "W", "", "W-17", "W-18");
$bracket_game_numbers[11][8][21] = array("Winner Game 20", "Loser Game 19", "W", "", "W-20", "L-19");
$bracket_game_numbers[11][8][22] = array("Winner Game 19", "Winner Game 21", "W", "", "W-19", "L-21");
$bracket_game_numbers[11][8][23] = array("Winner Game 22", "Loser 22 If 1st Loss", "W", "", "W-22", "L-22");


$bracket_game_numbers[11][9][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[11][9][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[11][9][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[11][9][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[11][9][5] = array("Team 9", "Team 1", "P", "", "", "");
$bracket_game_numbers[11][9][6] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][9][7] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[11][9][8] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[11][9][9] = array("Team 8", "Team 9", "P", "", "", "");
$bracket_game_numbers[11][9][10] = array("Team 1", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][9][11] = array("Team 2", "Team 4", "P", "", "", "");
$bracket_game_numbers[11][9][12] = array("Team 5", "Team 7", "P", "", "", "");
$bracket_game_numbers[11][9][13] = array("Team 6", "Team 8", "P", "", "", "");
$bracket_game_numbers[11][9][14] = array("Team 9", "Winner Game 10", "P", "", "", "W-10");
$bracket_game_numbers[11][9][15] = array("Loser Game 10", "Loser Game 11", "W", "", "L-10", "L-11");
$bracket_game_numbers[11][9][16] = array("Loser Game 12", "Loser Game 13", "W", "", "L-12", "L-13");
$bracket_game_numbers[11][9][17] = array("Winner Game 15", "Loser Game 14", "W", "", "W-15", "L-14");
$bracket_game_numbers[11][9][18] = array("Winner Game 11", "Winner Game 12", "W", "", "W-11", "W-12");
$bracket_game_numbers[11][9][19] = array("Winner Game 13", "Winner Game 14", "W", "", "W-13", "W-14");
$bracket_game_numbers[11][9][20] = array("Winner Game 17", "Loser Game 16", "W", "", "W-17", "L-16");
$bracket_game_numbers[11][9][21] = array("Winner Game 18", "Loser Game 19", "W", "", "W-18", "L-19");
$bracket_game_numbers[11][9][22] = array("Winner Game 18", "Winner Game 19", "W", "", "W-18", "W-19");
$bracket_game_numbers[11][9][23] = array("Winner Game 20", "Winner Game 21", "W", "", "W-20", "W-21");
$bracket_game_numbers[11][9][24] = array("Winner Game 23", "Loser Game 22", "W", "", "W-23", "L-22");
$bracket_game_numbers[11][9][25] = array("Winner Game 22", "Winner Game 24", "W", "", "W-22", "W-24");
$bracket_game_numbers[11][9][26] = array("Winner Game 25", "Loser 25 if 1st Loss ", "W", "", "W-25", "L-25");


$bracket_game_numbers[11][10][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[11][10][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[11][10][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[11][10][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[11][10][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[11][10][6] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][10][7] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[11][10][8] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[11][10][9] = array("Team 5", "Team 9", "P", "", "", "");
$bracket_game_numbers[11][10][10] = array("Team 8", "Team 10", "P", "", "", "");
$bracket_game_numbers[11][10][11] = array("Team 1", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][10][12] = array("Team 2", "Team 4", "P", "", "", "");
$bracket_game_numbers[11][10][13] = array("Team 5", "Team 7", "P", "", "", "");
$bracket_game_numbers[11][10][14] = array("Team 6", "Team 8", "P", "", "", "");
$bracket_game_numbers[11][10][15] = array("Team 9", "Winner Game 12", "W", "", "", "W-12");
$bracket_game_numbers[11][10][16] = array("Team 10", "Winner Game 13", "W", "", "", "W-13");
$bracket_game_numbers[11][10][17] = array("Loser Game 11", "Loser Game 12", "W", "", "L-11", "L-12");
$bracket_game_numbers[11][10][18] = array("Loser Game 13", "Loser Game 14", "W", "", "L-13", "L-14");
$bracket_game_numbers[11][10][19] = array("Winner Game 11", "Winner Game 15", "W", "", "W-11", "W-15");
$bracket_game_numbers[11][10][20] = array("Winner Game 17", "Loser Game 16", "W", "", "W-17", "L-16");
$bracket_game_numbers[11][10][21] = array("Winner Game 14", "Winner Game 16", "W", "", "W-14", "W-16");
$bracket_game_numbers[11][10][22] = array("Winner Game 18", "Loser Game 15", "W", "", "W-18", "L-15");
$bracket_game_numbers[11][10][23] = array("Winner Game 20", "Loser Game 19", "W", "", "W-20", "L-19");
$bracket_game_numbers[11][10][24] = array("Winner Game 22", "Loser Game 21", "W", "", "W-22", "L-21");
$bracket_game_numbers[11][10][25] = array("Winner Game 19", "Winner Game 21", "W", "", "W-19", "W-21");
$bracket_game_numbers[11][10][26] = array("Winner Game 23", "Winner Game 24", "W", "", "W-23", "W-24");
$bracket_game_numbers[11][10][27] = array("Winner Game 26", "Loser Game 25", "W", "", "W-26", "L-25");
$bracket_game_numbers[11][10][28] = array("Winner Game 25", "Winner Game 27", "W", "", "W-25", "W-27");
$bracket_game_numbers[11][10][29] = array("Winner Game 28", "Loser 28 if 1st Loss ", "W", "", "W-28", "L-28");



$bracket_game_numbers[11][11][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[11][11][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[11][11][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[11][11][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[11][11][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[11][11][6] = array("Team 11", "Team 1", "P", "", "", "");
$bracket_game_numbers[11][11][7] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][11][8] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[11][11][9] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[11][11][10] = array("Team 8", "Team 9", "P", "", "", "");
$bracket_game_numbers[11][11][11] = array("Team 10", "Team 11", "P", "", "", "");
$bracket_game_numbers[11][11][12] = array("Team 1", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][11][13] = array("Team 2", "Team 4", "P", "", "", "");
$bracket_game_numbers[11][11][14] = array("Team 5", "Team 7", "P", "", "", "");
$bracket_game_numbers[11][11][15] = array("Team 6", "Team 8", "W", "", "", "");
$bracket_game_numbers[11][11][16] = array("Team 9", "Team 8", "W", "", "#3", "#6");
$bracket_game_numbers[11][11][17] = array("Team 10", "Winner Game 12", "W", "", "", "W-12");
$bracket_game_numbers[11][11][18] = array("Team 11", "Winner Game 13", "W", "", "", "W-13");
$bracket_game_numbers[11][11][19] = array("Loser Game 12", "Loser Game 13", "W", "", "L-12", "L-13");
$bracket_game_numbers[11][11][20] = array("Loser Game 14", "Loser Game 15", "W", "", "L-14", "L-15");
$bracket_game_numbers[11][11][21] = array("Winner Game 15", "Winner Game 16", "W", "", "W-15", "W-16");
$bracket_game_numbers[11][11][22] = array("Loser Game 16", "Loser Game 17", "W", "", "L-16", "L-17");
$bracket_game_numbers[11][11][23] = array("Winner Game 17", "Winner Game 18", "W", "", "W-17", "W-18");
$bracket_game_numbers[11][11][24] = array("Winner Game 19", "Winner Game 20", "W", "", "W-19", "W-20");
$bracket_game_numbers[11][11][25] = array("Winner Game 22", "Loser Game 18", "W", "", "W-22", "L-18");
$bracket_game_numbers[11][11][26] = array("Winner Game 24", "Loser Game 21", "W", "", "W-24", "L-21");
$bracket_game_numbers[11][11][27] = array("Winner Game 25", "Loser Game 24", "W", "", "W-25", "L-23");
$bracket_game_numbers[11][11][28] = array("Winner Game 21", "Winner Game 23", "W", "", "W-21", "W-23");
$bracket_game_numbers[11][11][29] = array("Winner Game 26", "Loser Game 27", "W", "", "W-26", "W-27");
$bracket_game_numbers[11][11][30] = array("Winner Game 29", "Loser Game 28", "W", "", "W-29", "L-28");
$bracket_game_numbers[11][11][31] = array("Winner Game 28", "Winner Game 30", "W", "", "W-28", "W-30");
$bracket_game_numbers[11][11][32] = array("Winner Game 31", "Loser 31 if 1st Loss ", "W", "", "W-31", "L-31");


$bracket_game_numbers[11][12][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[11][12][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[11][12][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[11][12][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[11][12][5] = array("Team 9", "Team 11", "P", "", "", "");
$bracket_game_numbers[11][12][6] = array("Team 11", "Team 12", "P", "", "", "");
$bracket_game_numbers[11][12][7] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][12][8] = array("Team 4", "Team 1", "P", "", "", "");
$bracket_game_numbers[11][12][9] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[11][12][10] = array("Team 8", "Team 5", "P", "", "", "");
$bracket_game_numbers[11][12][11] = array("Team 10", "Team 11", "P", "", "", "");
$bracket_game_numbers[11][12][12] = array("Team 12", "Team 9", "P", "", "", "");
$bracket_game_numbers[11][12][13] = array("Team 1", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][12][14] = array("Team 2", "Team 4", "P", "", "", "");
$bracket_game_numbers[11][12][15] = array("Team 5", "Team 7", "W", "", "#4", "#5");
$bracket_game_numbers[11][12][16] = array("Team 6", "Team 8", "W", "", "#3", "#6");
$bracket_game_numbers[11][12][17] = array("Team 9", "Winner Game 13", "W", "", "", "W-13");
$bracket_game_numbers[11][12][18] = array("Team 10", "Winner Game 14", "W", "", "", "W-14");
$bracket_game_numbers[11][12][19] = array("Team 11", "Winner Game 15", "W", "", "", "W-15");
$bracket_game_numbers[11][12][20] = array("Team 12", "Winner Game 16", "W", "", "", "W-16");
$bracket_game_numbers[11][12][21] = array("Loser Game 13", "Loser Game 14", "W", "", "L-13", "L-14");
$bracket_game_numbers[11][12][22] = array("Loser Game 15", "Loser Game 16", "W", "", "L-15", "L-16");
$bracket_game_numbers[11][12][23] = array("Loser Game 17", "Loser Game 18", "W", "", "L-17", "L-18");
$bracket_game_numbers[11][12][24] = array("Loser Game 19", "Loser Game 20", "W", "", "L-19", "L-20");
$bracket_game_numbers[11][12][25] = array("Winner Game 17", "Winner Game 18", "W", "", "W-17", "W-18");
$bracket_game_numbers[11][12][26] = array("Winner Game 19", "Winner Game 20", "W", "", "W-19", "W-20");
$bracket_game_numbers[11][12][27] = array("Winner Game 21", "Winner Game 22", "W", "", "W-21", "W-22");
$bracket_game_numbers[11][12][28] = array("Winner Game 23", "Winner Game 24", "W", "", "W-23", "W-24");
$bracket_game_numbers[11][12][29] = array("Winner Game 27", "Loser Game 25", "W", "", "W-27", "L-25");
$bracket_game_numbers[11][12][30] = array("Winner Game 28", "Loser Game 26", "W", "", "W-28", "L-26");
$bracket_game_numbers[11][12][31] = array("Winner Game 25", "Winner Game 26", "W", "", "W-25", "W-26");
$bracket_game_numbers[11][12][32] = array("Winner Game 29", "Winner Game 30", "W", "", "W-29", "W-30");
$bracket_game_numbers[11][12][33] = array("Winner Game 32", "Loser Game 29", "W", "", "W-31", "L-29");
$bracket_game_numbers[11][12][34] = array("Winner Game 31", "Winner Game 33", "W", "", "W-31", "W-33");
$bracket_game_numbers[11][12][35] = array("Winner Game 34", "Loser 34 if 1st Loss ", "W", "", "W-34", "L-34");



$bracket_game_numbers[11][13][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[11][13][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[11][13][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[11][13][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[11][13][5] = array("Team 9", "Team 11", "P", "", "", "");
$bracket_game_numbers[11][13][6] = array("Team 11", "Team 12", "P", "", "", "");
$bracket_game_numbers[11][13][7] = array("Team 13", "Team 1", "P", "", "", "");
$bracket_game_numbers[11][13][8] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][13][9] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[11][13][10] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[11][13][11] = array("Team 8", "Team 9", "P", "", "", "");
$bracket_game_numbers[11][13][12] = array("Team 10", "Team 11", "P", "", "", "");
$bracket_game_numbers[11][13][13] = array("Team 12", "Team 13", "P", "", "", "");
$bracket_game_numbers[11][13][14] = array("Team 1", "Team 3", "P", "", "", "");
$bracket_game_numbers[11][13][15] = array("Team 2", "Team 4", "P", "", "", "");
$bracket_game_numbers[11][13][16] = array("Team 5", "Team 7", "W", "", "#4", "#5");
$bracket_game_numbers[11][13][17] = array("Team 6", "Team 8", "W", "", "#3", "#6");
$bracket_game_numbers[11][13][18] = array("Team 9", "Team 11", "W", "", "#1", "W-7");
$bracket_game_numbers[11][13][19] = array("Team 10", "Winner Game 14", "W", "", "", "W-14");
$bracket_game_numbers[11][13][20] = array("Team 12", "Winner Game 15", "W", "", "", "W-15");
$bracket_game_numbers[11][13][21] = array("Team 13", "Winner Game 16", "W", "", "", "W-16");
$bracket_game_numbers[11][13][22] = array("Winner Game 17", "Winner Game 18", "W", "", "W-17", "W-18");
$bracket_game_numbers[11][13][23] = array("Loser Game 14", "Loser Game 15", "W", "", "L-14", "L-15");
$bracket_game_numbers[11][13][24] = array("Loser Game 16", "Loser Game 17", "W", "", "L-16", "L-17");
$bracket_game_numbers[11][13][25] = array("Loser Game 18", "Loser Game 19", "W", "", "L-18", "L-19");
$bracket_game_numbers[11][13][26] = array("Loser Game 20", "Loser Game 21", "W", "", "L-20", "L-21");
$bracket_game_numbers[11][13][27] = array("Winner Game 23", "Loser Game 22", "W", "", "W-23", "L-22");
$bracket_game_numbers[11][13][28] = array("Winner Game 19", "Winner Game 20", "W", "", "W-19", "W-20");
$bracket_game_numbers[11][13][29] = array("Winner Game 21", "Winner Game 22", "W", "", "W-21", "W-22");
$bracket_game_numbers[11][13][30] = array("Winner Game 24", "Winner Game 27", "W", "", "W-24", "W-27");
$bracket_game_numbers[11][13][31] = array("Winner Game 25", "Winner Game 26", "W", "", "W-25", "W-26");
$bracket_game_numbers[11][13][32] = array("Winner Game 30", "Loser Game 28", "W", "", "W-30", "L-28");
$bracket_game_numbers[11][13][33] = array("Winner Game 31", "Loser Game 29", "W", "", "W-31", "L-29");
$bracket_game_numbers[11][13][34] = array("Winner Game 28", "Winner Game 29", "W", "", "W-28", "W-29");
$bracket_game_numbers[11][13][35] = array("Winner Game 32", "Winner Game 33", "W", "", "W-32", "W-33");
$bracket_game_numbers[11][13][36] = array("Winner Game 35", "Loser Game 34", "W", "", "W-35", "L-34");
$bracket_game_numbers[11][13][37] = array("Winner Game 34", "Winner Game 36", "W", "", "W-34", "W-36");
$bracket_game_numbers[11][13][38] = array("Winner Game 37", "Loser 37 if 1st Loss ", "W", "", "W-37", "L-37");


//-----------------------3 Game Elimination------------------------------------//

$bracket_game_numbers[12][4][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[12][4][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[12][4][3] = array("Winner Game 1", "Winner Game 2", "W", "", "W-1", "W-2");
$bracket_game_numbers[12][4][4] = array("Loser Game 1", "Loser Game 2", "L", "", "L-1", "L-2");
$bracket_game_numbers[12][4][5] = array("Loser Game 3", "Loser Game 4", "L", "", "L-3", "L-4");
$bracket_game_numbers[12][4][6] = array("Winner Game 4", "Winner Game 5", "W", "", "W-4", "W-5");
$bracket_game_numbers[12][4][7] = array("Winner Game 3", "Winner Game 6", "W", "", "W-3", "W-6");
$bracket_game_numbers[12][4][8] = array("Winner Game 7", "Loser 7 If 1st Loss", "W", "", "W-7", "L-7");

$bracket_game_numbers[12][5][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[12][5][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[12][5][3] = array("Team 5", "Winner Game 1", "W", "", "", "W-1");
$bracket_game_numbers[12][5][4] = array("Loser Game 1", "Loser Game 2", "W", "", "L-1", "L-2");
$bracket_game_numbers[12][5][5] = array("Winner Game 4", "Loser Game 3", "W", "", "W-4", "L-3");
$bracket_game_numbers[12][5][6] = array("Loser Game 4", "Loser Game 5", "W", "", "L-4", "L-5");
$bracket_game_numbers[12][5][7] = array("Winner Game 2", "Winner Game 3", "W", "", "W-2", "W-3");
$bracket_game_numbers[12][5][8] = array("Winner Game 5", "Winner Game 6", "W", "", "W-5", "W-6");
$bracket_game_numbers[12][5][9] = array("Winner Game 8", "Loser Game 7", "W", "", "W-8", "L-7");
$bracket_game_numbers[12][5][10] = array("Winner Game 7", "Winner Game 9", "W", "", "W-7", "W-9");
$bracket_game_numbers[12][5][11] = array("Winner Game 10", "Loser 10 If 1st Loss", "W", "", "W-10", "L-10");

$bracket_game_numbers[12][6][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[12][6][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[12][6][3] = array("Team 5", "Winner Game 1", "W", "", "", "W-1");
$bracket_game_numbers[12][6][4] = array("Team 6", "Winner Game 2", "W", "", "", "W-2");
$bracket_game_numbers[12][6][5] = array("Loser Game 2", "Loser Game 3", "W", "", "L-2", "L-3");
$bracket_game_numbers[12][6][6] = array("Loser Game 1", "Loser Game 4", "W", "", "L-1", "L-4");
$bracket_game_numbers[12][6][7] = array("Winner Game 5", "Loser Game 6", "W", "", "W-5", "L-6");
$bracket_game_numbers[12][6][8] = array("Winner Game 6", "Loser Game 5", "W", "", "W-6", "L-5");
$bracket_game_numbers[12][6][9] = array("Winner Game 3", "Winner Game 4", "W", "", "W-3", "W-4");
$bracket_game_numbers[12][6][10] = array("Winner Game 7", "Winner Game 8", "W", "", "W-7", "W-8");
$bracket_game_numbers[12][6][11] = array("Winner Game 10", "Loser Game 9", "W", "", "W-10", "L-9");
$bracket_game_numbers[12][6][12] = array("Winner Game 9", "Winner Game 11", "W", "", "W-9", "W-11");
$bracket_game_numbers[12][6][13] = array("Winner Game 12", "Loser 12 If 1st Loss", "W", "", "W-12", "L-12");

$bracket_game_numbers[12][7][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[12][7][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[12][7][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[12][7][4] = array("Team 7", "Winner Game 1", "W", "", "", "W-1");
$bracket_game_numbers[12][7][5] = array("Winner Game 2", "Winner Game 3", "W", "", "W-2", "W-3");
$bracket_game_numbers[12][7][6] = array("Loser Game 1", "Loser Game 2", "W", "", "L-1", "L-2");
$bracket_game_numbers[12][7][7] = array("Loser Game 3", "Loser Game 4", "W", "", "L-3", "L-4");
$bracket_game_numbers[12][7][8] = array("Loser Game 5", "Loser Game 6", "W", "", "L-5", "L-6");
$bracket_game_numbers[12][7][9] = array("Winner Game 7", "Winner Game 8", "W", "", "W-7", "W-8");
$bracket_game_numbers[12][7][10] = array("Winner Game 6", "Loser Game 7", "W", "", "W-6", "L-7");
$bracket_game_numbers[12][7][11] = array("Winner Game 4", "Winner Game 5", "W", "", "W-4", "W-5");
$bracket_game_numbers[12][7][12] = array("Winner Game 9", "Winner Game 10", "W", "", "W-9", "W-10");
$bracket_game_numbers[12][7][13] = array("Winner Game 12", "Loser Game 11", "W", "", "W-12", "L-11");
$bracket_game_numbers[12][7][14] = array("Winner Game 11", "Winner Game 13", "W", "", "W-11", "W-13");
$bracket_game_numbers[12][7][15] = array("Winner Game 14", "Loser 14 If 1st Loss", "W", "", "W-14", "L-14");

$bracket_game_numbers[12][8][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[12][8][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[12][8][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[12][8][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[12][8][5] = array("Loser Game 1", "Loser Game 2", "W", "", "L-1", "L-2");
$bracket_game_numbers[12][8][6] = array("Loser Game 3", "Loser Game 4", "W", "", "L-3", "L-4");
$bracket_game_numbers[12][8][7] = array("Winner Game 1", "Winner Game 2", "W", "", "W-1", "W-2");
$bracket_game_numbers[12][8][8] = array("Winner Game 3", "Winner Game 4", "W", "", "W-3", "W-4");
$bracket_game_numbers[12][8][9] = array("Winner Game 5", "Loser Game 6", "W", "", "W-5", "L-6");
$bracket_game_numbers[12][8][10] = array("Winner Game 6", "Loser Game 5", "W", "", "W-6", "L-5");
$bracket_game_numbers[12][8][11] = array("Winner Game 9", "Loser Game 8", "W", "", "W-9", "L-8");
$bracket_game_numbers[12][8][12] = array("Winner Game 10", "Loser Game 7", "W", "", "W-10", "L-7");
$bracket_game_numbers[12][8][13] = array("Winner Game 7", "Loser Game 8", "W", "", "W-7", "L-8");
$bracket_game_numbers[12][8][14] = array("Winner Game 11", "Winner Game 12", "W", "", "W-11", "W-12");
$bracket_game_numbers[12][8][15] = array("Winner Game 14", "Loser Game 13", "W", "", "W-14", "L-13");
$bracket_game_numbers[12][8][16] = array("Winner Game 13", "Winner Game 15", "W", "", "W-13", "W-15");
$bracket_game_numbers[12][8][17] = array("Winner Game 16", "Loser 16 If 1st Loss", "W", "", "W-16", "L-16");

$bracket_game_numbers[12][9][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[12][9][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[12][9][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[12][9][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[12][9][5] = array("Team 9", "Winner Game 1", "W", "", "", "W-1");
$bracket_game_numbers[12][9][6] = array("Loser Game 1", "Loser Game 2", "W", "", "L-1", "L-2");
$bracket_game_numbers[12][9][7] = array("Winner Game 6", "Loser Game 3", "W", "", "W-6", "L-3");
$bracket_game_numbers[12][9][8] = array("Loser Game 4", "Loser Game 5", "W", "", "L-4", "L-5");
$bracket_game_numbers[12][9][9] = array("Loser Game 6", "Loser Game 7", "W", "", "L-6", "L-7");
$bracket_game_numbers[12][9][10] = array("Winner Game 7", "Winner Game 8", "W", "", "W-7", "W-8");
$bracket_game_numbers[12][9][11] = array("Winner Game 9", "Loser Game 8", "W", "", "W-9", "L-8");
$bracket_game_numbers[12][9][12] = array("Winner Game 2", "Winner Game 3", "W", "", "W-2", "W-3");
$bracket_game_numbers[12][9][13] = array("Winner Game 4", "Winner Game 5", "W", "", "W-4", "W-5");
$bracket_game_numbers[12][9][14] = array("Winner Game 10", "Loser Game 12", "W", "", "W-10", "L-12");
$bracket_game_numbers[12][9][15] = array("Winner Game 11", "Loser Game 13", "W", "", "W-11", "L-13");
$bracket_game_numbers[12][9][16] = array("Winner Game 12", "Winner Game 13", "W", "", "W-12", "W-13");
$bracket_game_numbers[12][9][17] = array("Winner Game 14", "Winner Game 15", "W", "", "W-14", "W-15");
$bracket_game_numbers[12][9][18] = array("Winner Game 17", "Loser Game 16", "W", "", "W-17", "L-16");
$bracket_game_numbers[12][9][19] = array("Winner Game 16", "Winner Game 18", "W", "", "W-16", "W-18");
$bracket_game_numbers[12][9][20] = array("Winner Game 19", "Loser 19 If 1st Loss", "W", "", "W-19", "L-19");

$bracket_game_numbers[12][10][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[12][10][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[12][10][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[12][10][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[12][10][5] = array("Team 9", "Winner Game 2", "W", "", "", "W-2");
$bracket_game_numbers[12][10][6] = array("Team 10", "Winner Game 3", "W", "", "", "W-3");
$bracket_game_numbers[12][10][7] = array("Loser Game 1", "Loser Game 2", "W", "", "L-1", "L-2");
$bracket_game_numbers[12][10][8] = array("Loser Game 3", "Loser Game 4", "W", "", "L-3", "L-4");
$bracket_game_numbers[12][10][9] = array("Loser Game 5", "Loser Game 6", "W", "", "L-5", "L-6");
$bracket_game_numbers[12][10][10] = array("Loser Game 7", "Loser Game 9", "W", "", "L-7", "L-9");
$bracket_game_numbers[12][10][11] = array("Winner Game 7", "Loser Game 8", "W", "", "W-7", "L-8");
$bracket_game_numbers[12][10][12] = array("Winner Game 1", "Winner Game 5", "W", "", "W-1", "W-5");
$bracket_game_numbers[12][10][13] = array("Winner Game 4", "Winner Game 6", "W", "", "W-4", "W-6");
$bracket_game_numbers[12][10][14] = array("Winner Game 8", "Winner Game 9", "W", "", "W-8", "W-9");
$bracket_game_numbers[12][10][15] = array("Winner Game 10", "Winner Game 11", "W", "", "W-10", "W-11");
$bracket_game_numbers[12][10][16] = array("Winner Game 14", "Loser Game 12", "W", "", "W-14", "L-12");
$bracket_game_numbers[12][10][17] = array("Winner Game 15", "Loser Game 13", "W", "", "W-15", "L-13");
$bracket_game_numbers[12][10][18] = array("Winner Game 12", "Winner Game 13", "W", "", "W-12", "W-13");
$bracket_game_numbers[12][10][19] = array("Winner Game 16", "Winner Game 17", "W", "", "W-16", "W-17");
$bracket_game_numbers[12][10][20] = array("Winner Game 19", "Loser Game 18", "W", "", "W-19", "L-18");
$bracket_game_numbers[12][10][21] = array("Winner Game 18", "Winner Game 20", "W", "", "W-18", "W-20");
$bracket_game_numbers[12][10][22] = array("Winner Game 21", "Loser 21 If 1st Loss", "W", "", "W-21", "L-21");

$bracket_game_numbers[12][11][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[12][11][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[12][11][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[12][11][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[12][11][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[12][11][6] = array("Team 11", "Winner Game 1", "W", "", "", "W-1");
$bracket_game_numbers[12][11][7] = array("Loser Game 1", "Loser Game 2", "W", "", "L-1", "L-2");
$bracket_game_numbers[12][11][8] = array("Loser Game 3", "Loser Game 4", "W", "", "L-3", "L-4");
$bracket_game_numbers[12][11][9] = array("Loser Game 5", "Loser Game 6", "W", "", "L-5", "L-6");
$bracket_game_numbers[12][11][10] = array("Winner Game 2", "Winner Game 3", "W", "", "W-2", "W-3");
$bracket_game_numbers[12][11][11] = array("Winner Game 4", "Winner Game 5", "W", "", "W-4", "W-5");
$bracket_game_numbers[12][11][12] = array("Loser Game 7", "Loser Game 8", "W", "", "L-7", "L-8");
$bracket_game_numbers[12][11][13] = array("Winner Game 6", "Winner Game 10", "W", "", "W-6", "W-10");
$bracket_game_numbers[12][11][14] = array("Winner Game 7", "Loser Game 9", "W", "", "W-7", "L-9");
$bracket_game_numbers[12][11][15] = array("Winner Game 8", "Loser Game 10", "W", "", "W-8", "L-10");
$bracket_game_numbers[12][11][16] = array("Winner Game 9", "Loser Game 11", "W", "", "W-9", "L-11");
$bracket_game_numbers[12][11][17] = array("Winner Game 12", "Loser Game 13", "W", "", "W-12", "L-13");
$bracket_game_numbers[12][11][18] = array("Winner Game 14", "Winner Game 15", "W", "", "W-14", "W-15");
$bracket_game_numbers[12][11][19] = array("Winner Game 16", "Winner Game 17", "W", "", "W-16", "W-17");
$bracket_game_numbers[12][11][20] = array("Winner Game 11", "Winner Game 13", "W", "", "W-11", "W-13");
$bracket_game_numbers[12][11][21] = array("Winner Game 18", "Winner Game 19", "W", "", "W-18", "W-19");
$bracket_game_numbers[12][11][22] = array("Winner Game 21", "Loser Game 20", "W", "", "W-21", "L-20");
$bracket_game_numbers[12][11][23] = array("Winner Game 20", "Winner Game 22", "W", "", "W-20", "W-22");
$bracket_game_numbers[12][11][24] = array("Winner Game 23", "Loser 23 if 1st Loss", "W", "", "W-23", "L-23");


$bracket_game_numbers[12][12][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[12][12][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[12][12][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[12][12][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[12][12][5] = array("Team 9", "Winner Game 1", "W", "", "", "W-1");
$bracket_game_numbers[12][12][6] = array("Team 10", "Winner Game 2", "W", "", "", "W-2");
$bracket_game_numbers[12][12][7] = array("Team 11", "Winner Game 3", "W", "", "", "W-3");
$bracket_game_numbers[12][12][8] = array("Team 12", "Winner Game 4", "W", "", "", "W-4");
$bracket_game_numbers[12][12][9] = array("Loser Game 1", "Loser Game 2", "W", "", "L-1", "L-2");
$bracket_game_numbers[12][12][10] = array("Loser Game 3", "Loser Game 5", "W", "", "L-3", "L-5");
$bracket_game_numbers[12][12][11] = array("Loser Game 4", "Loser Game 6", "W", "", "L-4", "L-6");
$bracket_game_numbers[12][12][12] = array("Loser Game 1", "Loser Game 7", "W", "", "L-1", "L-7");
$bracket_game_numbers[12][12][13] = array("Winner Game 9", "Loser Game 12", "W", "", "W-9", "L-12");
$bracket_game_numbers[12][12][14] = array("Winner Game 10", "Loser Game 11", "W", "", "W-10", "L-11");
$bracket_game_numbers[12][12][15] = array("Winner Game 11", "Loser Game 10", "W", "", "W-11", "L-10");
$bracket_game_numbers[12][12][16] = array("Winner Game 12", "Loser Game 9", "W", "", "W-12", "L-9");
$bracket_game_numbers[12][12][17] = array("Winner Game 5", "Loser Game 6", "W", "", "W-5", "L-6");
$bracket_game_numbers[12][12][18] = array("Winner Game 7", "Loser Game 8", "W", "", "W-7", "L-8");
$bracket_game_numbers[12][12][19] = array("Winner Game 13", "Loser Game 14", "W", "", "W-13", "L-14");
$bracket_game_numbers[12][12][20] = array("Winner Game 15", "Winner Game 16", "W", "", "W-15", "W-16");
$bracket_game_numbers[12][12][21] = array("Winner Game 19", "Loser Game 18", "W", "", "W-19", "L-18");
$bracket_game_numbers[12][12][22] = array("Winner Game 20", "Winner Game 17", "W", "", "W-20", "W-17");
$bracket_game_numbers[12][12][23] = array("Winner Game 17", "Winner Game 18", "W", "", "W-17", "W-18");
$bracket_game_numbers[12][12][24] = array("Winner Game 21", "Winner Game 22", "W", "", "W-21", "W-22");
$bracket_game_numbers[12][12][25] = array("Winner Game 24", "Loser Game 23", "W", "", "W-24", "L-23");
$bracket_game_numbers[12][12][26] = array("Winner Game 23", "Winner Game 25", "W", "", "W-23", "W-25");
$bracket_game_numbers[12][12][27] = array("Winner Game 26", "Loser 26 if 1st Loss", "W", "", "W-26", "L-26");

$bracket_game_numbers[12][13][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[12][13][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[12][13][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[12][13][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[12][13][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[12][13][6] = array("Team 11", "Team 12", "P", "", "", "");
$bracket_game_numbers[12][13][7] = array("Team 13", "Winner Game 1", "W", "", "", "W-1");
$bracket_game_numbers[12][13][8] = array("Winner Game 2", "Winner Game 3", "W", "", "W-2", "W-3");
$bracket_game_numbers[12][13][9] = array("Loser Game 1", "Loser Game 2", "W", "", "L-1", "L-2");
$bracket_game_numbers[12][13][10] = array("Loser Game 3", "Loser Game 4", "W", "", "L-3", "L-4");
$bracket_game_numbers[12][13][11] = array("Loser Game 5", "Loser Game 6", "W", "", "L-5", "L-6");
$bracket_game_numbers[12][13][12] = array("Loser Game 7", "Loser Game 8", "W", "", "L-7", "L-8");
$bracket_game_numbers[12][13][13] = array("Winner Game 4", "Winner Game 5", "W", "", "W-4", "W-5");
$bracket_game_numbers[12][13][14] = array("Winner Game 9", "Loser Game 12", "W", "", "W-9", "L-12");
$bracket_game_numbers[12][13][15] = array("Winner Game 10", "Loser Game 11", "W", "", "W-10", "L-11");
$bracket_game_numbers[12][13][16] = array("Winner Game 11", "Loser Game 10", "W", "", "W-11", "L-10");
$bracket_game_numbers[12][13][17] = array("Winner Game 12", "Loser Game 9", "W", "", "W-12", "L-9");
$bracket_game_numbers[12][13][18] = array("Winner Game 6", "Winner Game 13", "W", "", "W-6", "W-13");
$bracket_game_numbers[12][13][19] = array("Winner Game 7", "Winner Game 8", "W", "", "W-7", "W-8");
$bracket_game_numbers[12][13][20] = array("Winner Game 14", "Loser Game 13", "W", "", "W-14", "L-13");
$bracket_game_numbers[12][13][21] = array("Winner Game 16", "Loser Game 18", "W", "", "W-16", "L-18");
$bracket_game_numbers[12][13][22] = array("Winner Game 17", "Loser Game 19", "W", "", "W-17", "L-19");
$bracket_game_numbers[12][13][23] = array("Winner Game 15", "Winner Game 20", "W", "", "W-15", "W-20");
$bracket_game_numbers[12][13][24] = array("Winner Game 21", "Winner Game 22", "W", "", "W-21", "W-22");
$bracket_game_numbers[12][13][25] = array("Winner Game 18", "Winner Game 19", "W", "", "W-18", "W-19");
$bracket_game_numbers[12][13][26] = array("Winner Game 23", "Winner Game 24", "W", "", "W-23", "W-24");
$bracket_game_numbers[12][13][27] = array("Winner Game 26", "Loser Game 25", "W", "", "W-24", "L-25");
$bracket_game_numbers[12][13][28] = array("Winner Game 25", "Winner Game 27", "W", "", "W-25", "W-27");
$bracket_game_numbers[12][13][29] = array("Winner Game 28", "Loser 28 if 1st Loss", "W", "", "W-28", "L-28");


$bracket_game_numbers[12][14][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[12][14][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[12][14][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[12][14][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[12][14][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[12][14][6] = array("Team 11", "Team 12", "P", "", "", "");
$bracket_game_numbers[12][14][7] = array("Team 13", "Winner Game 1", "W", "", "", "W-1");
$bracket_game_numbers[12][14][8] = array("Team 14", "Winner Game 2", "W", "", "", "W-2");
$bracket_game_numbers[12][14][9] = array("Winner Game 3", "Winner Game 4", "W", "", "W-3", "W-4");
$bracket_game_numbers[12][14][10] = array("Winner Game 5", "Winner Game 6", "W", "", "W-5", "W-6");
$bracket_game_numbers[12][14][11] = array("Loser Game 1", "Loser Game 2", "W", "", "L-1", "L-2");
$bracket_game_numbers[12][14][12] = array("Loser Game 3", "Loser Game 4", "W", "", "L-3", "L-4");
$bracket_game_numbers[12][14][13] = array("Loser Game 5", "Loser Game 6", "W", "", "L-5", "L-6");
$bracket_game_numbers[12][14][14] = array("Loser Game 7", "Loser Game 8", "W", "", "L-7", "L-8");
$bracket_game_numbers[12][14][15] = array("Loser Game 11", "Loser Game 12", "W", "", "L-11", "L-12");
$bracket_game_numbers[12][14][16] = array("Loser Game 13", "Loser Game 14", "W", "", "L-13", "L-14");
$bracket_game_numbers[12][14][17] = array("Winner Game 7", "Winner Game 9", "W", "", "W-7", "W-9");
$bracket_game_numbers[12][14][18] = array("Winner Game 8", "Winner Game 10", "W", "", "W-8", "W-10");
$bracket_game_numbers[12][14][19] = array("Winner Game 16", "Loser Game 9", "W", "", "W-16", "L-9");
$bracket_game_numbers[12][14][20] = array("Winner Game 15", "Loser Game 10", "W", "", "W-15", "L-10");
$bracket_game_numbers[12][14][21] = array("Winner Game 13", "Winner Game 14", "W", "", "W-13", "W-14");
$bracket_game_numbers[12][14][22] = array("Winner Game 11", "Winner Game 12", "W", "", "W-11", "W-12");
$bracket_game_numbers[12][14][23] = array("Winner Game 19", "Loser Game 17", "W", "", "W-19", "L-17");
$bracket_game_numbers[12][14][24] = array("Winner Game 20", "Loser Game 18", "W", "", "W-20", "L-18");
$bracket_game_numbers[12][14][25] = array("Winner Game 21", "Winner Game 22", "W", "", "W-21", "W-22");
$bracket_game_numbers[12][14][26] = array("Winner Game 17", "Winner Game 18", "W", "", "W-17", "W-18");
$bracket_game_numbers[12][14][27] = array("Winner Game 24", "Winner Game 25", "W", "", "W-24", "W-25");
$bracket_game_numbers[12][14][28] = array("Winner Game 23", "Winner Game 27", "W", "", "W-23", "W-27");
$bracket_game_numbers[12][14][29] = array("Winner Game 28", "Loser Game 26", "W", "", "W-28", "L-26");
$bracket_game_numbers[12][14][30] =  array("Winner Game 26", "Winner Game 29", "W", "", "W-26", "W-29");
$bracket_game_numbers[12][14][31] = array("Winner Game 30", "Loser 30 if 1st Loss", "W", "", "W-30", "L-30");

$bracket_game_numbers[12][15][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[12][15][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[12][15][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[12][15][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[12][15][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[12][15][6] = array("Team 11", "Team 12", "P", "", "", "");
$bracket_game_numbers[12][15][7] = array("Team 13", "Team 14", "P", "", "", "");
$bracket_game_numbers[12][15][8] = array("Team 15", "Winner Game 1", "W", "", "", "W-1");
$bracket_game_numbers[12][15][9] = array("Winner Game 2", "Winner Game 3", "W", "", "W-2", "W-3");
$bracket_game_numbers[12][15][10] = array("Winner Game 4", "Winner Game 5", "W", "", "W-4", "W-5");
$bracket_game_numbers[12][15][11] = array("Winner Game 6", "Winner Game 7", "W", "", "W-6", "W-7");
$bracket_game_numbers[12][15][12] = array("Loser Game 1", "Loser Game 4", "W", "", "L-1", "L-4");
$bracket_game_numbers[12][15][13] = array("Loser Game 6", "Loser Game 8", "W", "", "L-6", "L-8");
$bracket_game_numbers[12][15][14] = array("Loser Game 2", "Loser Game 3", "W", "", "L-2", "L-3");
$bracket_game_numbers[12][15][15] = array("Loser Game 5", "Loser Game 7", "W", "", "L-5", "L-7");
$bracket_game_numbers[12][15][16] = array("Winner Game 12", "Loser Game 13", "W", "", "W-12", "L-13");
$bracket_game_numbers[12][15][17] = array("Winner Game 13", "Loser Game 14", "W", "", "W-13", "L-14");
$bracket_game_numbers[12][15][18] = array("Winner Game 14", "Loser Game 15", "W", "", "W-14", "L-15");
$bracket_game_numbers[12][15][19] = array("Winner Game 15", "Loser Game 12", "W", "", "W-15", "L-12");
$bracket_game_numbers[12][15][20] = array("Winner Game 16", "Loser Game 9", "W", "", "W-16", "L-9");
$bracket_game_numbers[12][15][21] = array("Winner Game 17", "Loser Game 10", "W", "", "W-17", "L-10");
$bracket_game_numbers[12][15][22] = array("Winner Game 18", "Loser Game 11", "W", "", "W-18", "L-11");
$bracket_game_numbers[12][15][23] = array("Winner Game 8", "Winner Game 9", "W", "", "W-8", "W-9");
$bracket_game_numbers[12][15][24] = array("Winner Game 10", "Winner Game 11", "W", "", "W-10", "W-11");
$bracket_game_numbers[12][15][25] = array("Winner Game 20", "Winner Game 21", "W", "", "W-20", "W-21");
$bracket_game_numbers[12][15][26] = array("Winner Game 19", "Winner Game 22", "W", "", "W-19", "W-22");
$bracket_game_numbers[12][15][27] = array("Winner Game 25", "Loser Game 23", "W", "", "W-25", "L-23");
$bracket_game_numbers[12][15][28] = array("Winner Game 26", "Loser Game 24", "W", "", "W-26", "L-24");
$bracket_game_numbers[12][15][29] = array("Winner Game 23", "Winner Game 24", "W", "", "W-23", "W-24");
$bracket_game_numbers[12][15][30] = array("Winner Game 27", "Winner Game 28", "W", "", "W-27", "W-28");
$bracket_game_numbers[12][15][31] = array("Winner Game 30", "Loser Game 29", "W", "", "W-30", "L-29");
$bracket_game_numbers[12][15][32] = array("Winner Game 29", "Winner Game 31", "W", "", "W-29", "W-31");
$bracket_game_numbers[12][15][33] = array("Winner Game 32", "Loser 32 if 1st Loss", "W", "", "W-32", "L-32");

$bracket_game_numbers[12][16][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[12][16][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[12][16][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[12][16][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[12][16][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[12][16][6] = array("Team 11", "Team 12", "P", "", "", "");
$bracket_game_numbers[12][16][7] = array("Team 13", "Team 14", "P", "", "", "");
$bracket_game_numbers[12][16][8] = array("Team 15", "Team 16", "P", "", "", "");
$bracket_game_numbers[12][16][9] = array("Loser Game 1", "Loser Game 2", "W", "", "L-1", "L-2");
$bracket_game_numbers[12][16][10] = array("Loser Game 3", "Loser Game 4", "W", "", "L-3", "L-4");
$bracket_game_numbers[12][16][11] = array("Loser Game 5", "Loser Game 6", "W", "", "L-5", "L-6");
$bracket_game_numbers[12][16][12] = array("Loser Game 7", "Loser Game 8", "W", "", "L-7", "L-8");
$bracket_game_numbers[12][16][13] = array("Winner Game 1", "Winner Game 2", "W", "", "W-1", "W-2");
$bracket_game_numbers[12][16][14] = array("Winner Game 3", "Winner Game 4", "W", "", "W-3", "W-4");
$bracket_game_numbers[12][16][15] = array("Winner Game 5", "Winner Game 6", "W", "", "W-5", "W-6");
$bracket_game_numbers[12][16][16] = array("Winner Game 7", "Winner Game 8", "W", "", "W-7", "W-8");
$bracket_game_numbers[12][16][17] = array("Winner Game 9", "Loser Game 10", "W", "", "W-9", "L-10");
$bracket_game_numbers[12][16][18] = array("Winner Game 10", "Loser Game 9", "W", "", "W-10", "L-9");
$bracket_game_numbers[12][16][19] = array("Winner Game 11", "Loser Game 12", "W", "", "W-11", "L-12");
$bracket_game_numbers[12][16][20] = array("Winner Game 12", "Loser Game 11", "W", "", "W-12", "L-11");
$bracket_game_numbers[12][16][21] = array("Winner Game 17", "Loser Game 16", "W", "", "W-17", "L-16");
$bracket_game_numbers[12][16][22] = array("Winner Game 18", "Loser Game 15", "W", "", "W-18", "L-15");
$bracket_game_numbers[12][16][23] = array("Winner Game 19", "Loser Game 14", "W", "", "W-19", "L-14");
$bracket_game_numbers[12][16][24] = array("Winner Game 20", "Loser Game 13", "W", "", "W-20", "L-13");
$bracket_game_numbers[12][16][25] = array("Winner Game 13", "Winner Game 14", "W", "", "W-13", "W-14");
$bracket_game_numbers[12][16][26] = array("Winner Game 15", "Winner Game 16", "W", "", "W-15", "W-16");
$bracket_game_numbers[12][16][27] = array("Winner Game 21", "Winner Game 22", "W", "", "W-21", "W-22");
$bracket_game_numbers[12][16][28] = array("Winner Game 23", "Winner Game 24", "W", "", "W-23", "W-24");
$bracket_game_numbers[12][16][29] = array("Winner Game 27", "Loser Game 25", "W", "", "W-27", "L-25");
$bracket_game_numbers[12][16][30] = array("Winner Game 28", "Loser Game 26", "W", "", "W-28", "L-26");
$bracket_game_numbers[12][16][31] = array("Winner Game 25", "Winner Game 26", "W", "", "W-25", "W-26");
$bracket_game_numbers[12][16][32] = array("Winner Game 29", "Winner Game 30", "W", "", "W-29", "W-30");
$bracket_game_numbers[12][16][33] = array("Winner Game 32", "Loser Game 31", "W", "", "W-32", "L-31");
$bracket_game_numbers[12][16][34] = array("Winner Game 31", "Winner Game 33", "W", "", "W-31", "W-33");
$bracket_game_numbers[12][16][35] = array("Winner Game 34", "Loser 34 if 1st Loss", "W", "", "W-34", "L-34");


//---------------------------End------------------------------//


//-----------------------2 Pool + 3 Game guarantee------------------------------------//

$bracket_game_numbers[13][4][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[13][4][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[13][4][3] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[13][4][4] = array("Team 4", "Team 1", "P", "", "", "");
$bracket_game_numbers[13][4][5] = array("#1 Seed", "#4 Seed", "P", "", "#1", "#4");
$bracket_game_numbers[13][4][6] = array("#2 Seed", "#3 Seed", "P", "", "#2", "#3");
$bracket_game_numbers[13][4][7] = array("Winner Game 5", "Winner Game 6", "W", "", "W-5", "W-6");
$bracket_game_numbers[13][4][8] = array("Loser Game 5", "Loser Game 6", "W", "", "L-5", "L-6");
$bracket_game_numbers[13][4][9] = array("Loser Game 7", "Loser Game 8", "W", "", "L-7", "L-8");
$bracket_game_numbers[13][4][10] = array("Winner Game 8", "Winner Game 9", "W", "", "W-8", "W-9");
$bracket_game_numbers[13][4][11] = array("Winner Game 7", "Winner Game 10", "W", "", "W-7", "W-10");
$bracket_game_numbers[13][4][12] = array("Winner Game 11", "Loser 11 If 1st Loss", "W", "", "W-11", "L-11");


$bracket_game_numbers[13][5][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[13][5][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[13][5][3] = array("Team 5", "Team 1", "P", "", "", "");
$bracket_game_numbers[13][5][4] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[13][5][5] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[13][5][6] = array("#4 Seed", "#5 Seed", "P", "", "#4", "#5");
$bracket_game_numbers[13][5][7] = array("#2 Seed", "#3 Seed", "P", "", "#2", "#3");
$bracket_game_numbers[13][5][8] = array("#1 Seed", "Winner Game 6", "W", "", "#1", "W-6");
$bracket_game_numbers[13][5][9] = array("Loser Game 6", "Loser Game 7", "W", "", "L-6", "L-7");
$bracket_game_numbers[13][5][10] = array("Winner Game 9", "Loser Game 8", "W", "", "W-9", "L-8");
$bracket_game_numbers[13][5][13] = array("Loser Game 9", "Loser Game 10", "W", "", "L-9", "L-10");
$bracket_game_numbers[13][5][12] = array("Winner Game 7", "Winner Game 8", "W", "", "W-7", "W-8");
$bracket_game_numbers[13][5][13] = array("Winner Game 10", "Winner Game 11", "W", "", "W-10", "W-11");
$bracket_game_numbers[13][5][14] = array("Winner Game 13", "Loser Game 12", "W", "", "W-13", "L-12");
$bracket_game_numbers[13][5][15] = array("Winner Game 12", "Winner Game 14", "W", "", "W-12", "W-14");
$bracket_game_numbers[13][5][16] = array("Winner Game 14", "Loser 14 If 1st Loss", "W", "", "W-14", "L-14");


$bracket_game_numbers[13][6][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[13][6][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[13][6][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[13][6][4] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[13][6][5] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[13][6][6] = array("Team 6", "Team 1", "P", "", "", "");
$bracket_game_numbers[13][6][7] = array("#4 Seed", "#5 Seed", "P", "", "#4", "#5");
$bracket_game_numbers[13][6][8] = array("#3 Seed", "#6 Seed", "P", "", "#3", "#6");
$bracket_game_numbers[13][6][9] = array("#1 Seed", "Winner Game 7", "W", "", "#1", "W-7");
$bracket_game_numbers[13][6][10] = array("#2 Seed", "Winner Game 8", "W", "", "#2", "W-8");
$bracket_game_numbers[13][6][11] = array("Loser Game 8", "Loser Game 9", "W", "", "L-8", "L-9");
$bracket_game_numbers[13][6][12] = array("Loser Game 7", "Loser Game 10", "W", "", "L-7", "L-10");
$bracket_game_numbers[13][6][13] = array("Winner Game 11", "Loser Game 12", "W", "", "W-11", "L-12");
$bracket_game_numbers[13][6][14] = array("Winner Game 12", "Loser Game 11", "W", "", "W-12", "L-11");
$bracket_game_numbers[13][6][15] = array("Winner Game 9", "Winner Game 10", "W", "", "W-9", "W-10");
$bracket_game_numbers[13][6][16] = array("Winner Game 13", "Winner Game 14", "W", "", "W-13", "W-14");
$bracket_game_numbers[13][6][17] = array("Winner Game 16", "Loser Game 15", "W", "", "W-16", "L-15");
$bracket_game_numbers[13][6][18] = array("Winner Game 15", "Winner Game 17", "W", "", "W-15", "W-17");
$bracket_game_numbers[13][6][19] = array("Winner Game 18", "Loser 18 If 1st Loss", "W", "", "W-18", "L-18");


$bracket_game_numbers[13][7][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[13][7][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[13][7][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[13][7][4] = array("Team 7", "Team 1", "P", "", "", "");
$bracket_game_numbers[13][7][5] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[13][7][6] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[13][7][7] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[13][7][8] = array("#4 Seed", "#5 Seed", "P", "", "#4", "#5");
$bracket_game_numbers[13][7][9] = array("#3 Seed", "#6 Seed", "P", "", "#3", "#6");
$bracket_game_numbers[13][7][10] = array("#2 Seed", "#7 Seed", "P", "", "#2", "#7");
$bracket_game_numbers[13][7][11] = array("#1 Seed", "Winner Game 8", "W", "", "#1", "W-8");
$bracket_game_numbers[13][7][12] = array("Winner Game 9", "Winner Game 10", "W", "", "W-9", "W-10");
$bracket_game_numbers[13][7][13] = array("Loser Game 8", "Loser Game 9", "W", "", "L-8", "L-9");
$bracket_game_numbers[13][7][14] = array("Loser Game 10", "Loser Game 11", "W", "", "L-10", "L-11");
$bracket_game_numbers[13][7][15] = array("Winner Game 14", "Winner Game 15", "W", "", "W-14", "W-15");
$bracket_game_numbers[13][7][16] = array("Winner Game 13", "Loser Game 14", "W", "", "W-13", "L-14");
$bracket_game_numbers[13][7][17] = array("Winner Game 11", "Winner Game 12", "W", "", "W-11", "W-12");
$bracket_game_numbers[13][7][18] = array("Winner Game 16", "Winner Game 17", "W", "", "W-16", "W-17");
$bracket_game_numbers[13][7][19] = array("Winner Game 19", "Loser Game 18", "W", "", "W-19", "L-18");
$bracket_game_numbers[13][7][20] = array("Winner Game 18", "Winner Game 20", "W", "", "W-18", "W-20");
$bracket_game_numbers[13][7][21] = array("Winner Game 21", "Loser 21 If 1st Loss", "W", "", "W-21", "L-21");


$bracket_game_numbers[13][8][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[13][8][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[13][8][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[13][8][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[13][8][5] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[13][8][6] = array("Team 4", "Team 1", "P", "", "", "");
$bracket_game_numbers[13][8][7] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[13][8][8] = array("Team 8", "Team 5", "P", "", "", "");
$bracket_game_numbers[13][8][9] = array("#1 Seed", "#8 Seed", "P", "", "#1", "#8");
$bracket_game_numbers[13][8][10] = array("#4 Seed", "#5 Seed", "P", "", "#4", "#5");
$bracket_game_numbers[13][8][11] = array("#3 Seed", "#6 Seed", "P", "", "#3", "#6");
$bracket_game_numbers[13][8][12] = array("#2 Seed", "#7 Seed", "P", "", "#2", "#7");
$bracket_game_numbers[13][8][13] = array("Loser Game 9", "Loser Game 10", "W", "", "L-9", "L-10");
$bracket_game_numbers[13][8][14] = array("Loser Game 11", "Loser Game 12", "W", "", "L-11", "L-12");
$bracket_game_numbers[13][8][15] = array("Winner Game 9", "Winner Game 10", "W", "", "W-9", "W-10");
$bracket_game_numbers[13][8][16] = array("Winner Game 11", "Winner Game 12", "W", "", "W-11", "W-12");
$bracket_game_numbers[13][8][17] = array("Winner Game 13", "Winner Game 12", "W", "", "W-11", "W-12");
$bracket_game_numbers[13][8][18] = array("Winner Game 14", "Loser Game 13", "W", "", "W-14", "L-13");
$bracket_game_numbers[13][8][19] = array("Winner Game 17", "Loser Game 16", "W", "", "W-17", "L-16");
$bracket_game_numbers[13][8][20] = array("Winner Game 18", "Loser Game 15", "W", "", "W-18", "L-15");
$bracket_game_numbers[13][8][21] = array("Winner Game 15", "Winner Game 16", "W", "", "W-15", "W-16");
$bracket_game_numbers[13][8][22] = array("Winner Game 19", "Winner Game 20", "W", "", "W-19", "W-20");
$bracket_game_numbers[13][8][23] = array("Winner Game 22", "Loser Game 21", "W", "", "W-22", "L-21");
$bracket_game_numbers[13][8][24] = array("Winner Game 21", "Winner Game 23", "W", "", "W-21", "W-23");
$bracket_game_numbers[13][8][25] = array("Winner Game 24", "Loser 24 If 1st Loss", "W", "", "W-24", "L-24");


$bracket_game_numbers[13][9][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[13][9][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[13][9][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[13][9][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[13][9][5] = array("Team 9", "Team 1", "P", "", "", "");
$bracket_game_numbers[13][9][6] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[13][9][7] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[13][9][8] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[13][9][9] = array("Team 8", "Team 9", "P", "", "", "");
$bracket_game_numbers[13][9][10] = array("#8 Seed", "#9 Seed", "P", "", "#8", "#9");
$bracket_game_numbers[13][9][11] = array("#2 Seed", "#7 Seed", "P", "", "#2", "#7");
$bracket_game_numbers[13][9][12] = array("#3 Seed", "#6 Seed", "P", "", "#3", "#6");
$bracket_game_numbers[13][9][13] = array("#4 Seed", "#5 Seed", "P", "", "#4", "#5");
$bracket_game_numbers[13][9][14] = array("#1 Seed", "Winner Game 10", "P", "", "#1", "W-10");
$bracket_game_numbers[13][9][15] = array("Loser Game 10", "Loser Game 11", "W", "", "L-10", "L-11");
$bracket_game_numbers[13][9][16] = array("Winner Game 15", "Loser Game 12", "W", "", "W-15", "L-12");
$bracket_game_numbers[13][9][17] = array("Loser Game 13", "Loser Game 14", "L", "", "L-13", "L-14");
$bracket_game_numbers[13][9][18] = array("Loser Game 15", "Loser Game 16", "W", "", "L-15", "L-16");
$bracket_game_numbers[13][9][19] = array("Winner Game 16", "Winner Game 17", "W", "", "W-16", "W-17");
$bracket_game_numbers[13][9][20] = array("Winner Game 18", "Loser Game 17", "W", "", "W-18", "L-17");
$bracket_game_numbers[13][9][21] = array("Winner Game 11", "Winner Game 12", "W", "", "W-11", "W-12");
$bracket_game_numbers[13][9][22] = array("Winner Game 13", "Winner Game 14", "W", "", "W-13", "W-14");
$bracket_game_numbers[13][9][23] = array("Winner Game 19", "Loser Game 21", "W", "", "W-19", "L-21");
$bracket_game_numbers[13][9][24] = array("Winner Game 20", "Loser Game 22", "W", "", "W-19", "L-22");
$bracket_game_numbers[13][9][25] = array("Winner Game 21", "Winner Game 22", "W", "", "W-21", "W-22");
$bracket_game_numbers[13][9][26] = array("Winner Game 23", "Winner Game 24", "W", "", "W-23", "W-24");
$bracket_game_numbers[13][9][27] = array("Winner Game 26", "Loser Game 25", "W", "", "W-26", "L-25");
$bracket_game_numbers[13][9][28] = array("Winner Game 25", "Winner Game 27", "W", "", "W-25", "W-27");
$bracket_game_numbers[13][9][29] = array("Winner Game 28", "Loser 28 if 1st Loss ", "W", "", "W-28", "L-28");


$bracket_game_numbers[13][10][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[13][10][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[13][10][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[13][10][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[13][10][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[13][10][6] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[13][10][7] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[13][10][8] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[13][10][9] = array("Team 5", "Team 9", "P", "", "", "");
$bracket_game_numbers[13][10][10] = array("Team 8", "Team 10", "P", "", "", "");
$bracket_game_numbers[13][10][11] = array("#8 Seed", "#9 Seed", "P", "", "#8", "#9");
$bracket_game_numbers[13][10][12] = array("#7 Seed", "#10 Seed", "P", "", "#7", "#10");
$bracket_game_numbers[13][10][13] = array("#4 Seed", "#5 Seed", "P", "", "#4", "#5");
$bracket_game_numbers[13][10][14] = array("#3 Seed", "#6 Seed", "P", "", "#3", "#6");
$bracket_game_numbers[13][10][15] = array("#1 Seed", "Winner Game 11", "W", "", "#1", "W-11");
$bracket_game_numbers[13][10][16] = array("#2 Seed", "Winner Game 12", "W", "", "#2", "W-12");
$bracket_game_numbers[13][10][17] = array("Loser Game 12", "Loser Game 13", "W", "", "L-12", "L-13");
$bracket_game_numbers[13][10][18] = array("Loser Game 11", "Loser Game 14", "W", "", "L-11", "L-14");
$bracket_game_numbers[13][10][19] = array("Loser Game 15", "Loser Game 16", "W", "", "L-15", "L-16");
$bracket_game_numbers[13][10][20] = array("Loser Game 18", "Loser Game 19", "W", "", "L-18", "L-19");
$bracket_game_numbers[13][10][21] = array("Winner Game 18", "Loser Game 17", "W", "", "W-18", "L-17");
$bracket_game_numbers[13][10][22] = array("Winner Game 17", "Winner Game 20", "W", "", "W-17", "W-20");
$bracket_game_numbers[13][10][23] = array("Winner Game 21", "Winner Game 19", "W", "", "W-21", "L-19");
$bracket_game_numbers[13][10][24] = array("Winner Game 13", "Winner Game 14", "W", "", "W-13", "W-14");
$bracket_game_numbers[13][10][25] = array("Winner Game 16", "Winner Game 14", "W", "", "W-16", "W-14");
$bracket_game_numbers[13][10][26] = array("Winner Game 22", "Loser Game 25", "W", "", "W-22", "L-25");
$bracket_game_numbers[13][10][27] = array("Winner Game 23", "Loser Game 24", "W", "", "W-23", "L-24");
$bracket_game_numbers[13][10][28] = array("Winner Game 24", "Winner Game 25", "W", "", "W-24", "W-25");
$bracket_game_numbers[13][10][29] = array("Winner Game 26", "Winner Game 27", "W", "", "W-26", "W-27");
$bracket_game_numbers[13][10][30] = array("Winner Game 29", "Loser Game 28", "W", "", "W-29", "L-28");
$bracket_game_numbers[13][10][31] = array("Winner Game 28", "Winner Game 30", "W", "", "W-28", "W-30");
$bracket_game_numbers[13][10][32] = array("Winner Game 31", "Loser 31 if 1st Loss ", "W", "", "W-31", "L-31");



$bracket_game_numbers[13][11][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[13][11][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[13][11][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[13][11][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[13][11][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[13][11][6] = array("Team 11", "Team 1", "P", "", "", "");
$bracket_game_numbers[13][11][7] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[13][11][8] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[13][11][9] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[13][11][10] = array("Team 8", "Team 9", "P", "", "", "");
$bracket_game_numbers[13][11][11] = array("Team 10", "Team 11", "P", "", "", "");
$bracket_game_numbers[13][11][12] = array("#8 Seed", "#9 Seed", "P", "", "#8", "#9");
$bracket_game_numbers[13][11][13] = array("#6 Seed", "#11 Seed", "P", "", "#6", "#11");
$bracket_game_numbers[13][11][14] = array("#7 Seed", "#10 Seed", "P", "", "#7", "#10");
$bracket_game_numbers[13][11][15] = array("#4 Seed", "#5 Seed", "W", "", "#4", "#5");
$bracket_game_numbers[13][11][16] = array("#1 Seed", "Winner Game 12", "W", "", "#1", "W-12");
$bracket_game_numbers[13][11][17] = array("#3 Seed", "Winner Game 13", "W", "", "", "W-13");
$bracket_game_numbers[13][11][18] = array("#2 Seed", "Winner Game 14", "W", "", "", "W-14");
$bracket_game_numbers[13][11][19] = array("Loser Game 13", "Loser Game 15", "W", "", "L-13", "L-15");
$bracket_game_numbers[13][11][20] = array("Loser Game 14", "Loser Game 16", "W", "", "L-14", "L-16");
$bracket_game_numbers[13][11][21] = array("Loser Game 12", "Loser Game 17", "W", "", "L-12", "L-17");
$bracket_game_numbers[13][11][22] = array("Loser Game 19", "Loser Game 20", "W", "", "L-19", "L-20");
$bracket_game_numbers[13][11][23] = array("Winner Game 21", "Loser Game 18", "W", "", "W-21", "L-18");
$bracket_game_numbers[13][11][24] = array("Winner Game 20", "Loser Game 21", "W", "", "W-20", "L-21");
$bracket_game_numbers[13][11][25] = array("Winner Game 19", "Loser Game 23", "W", "", "W-19", "L-23");
$bracket_game_numbers[13][11][26] = array("Winner Game 23", "Winner Game 22", "W", "", "W-23", "W-22");
$bracket_game_numbers[13][11][27] = array("Winner Game 25", "Winner Game 24", "W", "", "W-25", "W-24");
$bracket_game_numbers[13][11][28] = array("Winner Game 15", "Winner Game 16", "W", "", "W-15", "W-16");
$bracket_game_numbers[13][11][29] = array("Winner Game 17", "Winner Game 18", "W", "", "W-17", "W-18");
$bracket_game_numbers[13][11][30] = array("Winner Game 26", "Loser Game 28", "W", "", "W-26", "L-28");
$bracket_game_numbers[13][11][31] = array("Winner Game 27", "Loser Game 29", "W", "", "W-27", "L-29");
$bracket_game_numbers[13][11][32] = array("Winner Game 28", "Winner Game 29", "W", "", "W-28", "W-29");
$bracket_game_numbers[13][11][33] = array("Winner Game 31", "Winner Game 30", "W", "", "W-31", "W-30");
$bracket_game_numbers[13][11][34] = array("Winner Game 33", "Loser Game 32", "W", "", "W-33", "L-32");
$bracket_game_numbers[13][11][35] = array("Winner Game 32", "Winner Game 34", "W", "", "W-32", "W-34");
$bracket_game_numbers[13][11][36] = array("Winner Game 35", "Loser 35 if 1st Loss ", "W", "", "W-35", "L-35");


$bracket_game_numbers[13][12][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[13][12][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[13][12][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[13][12][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[13][12][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[13][12][6] = array("Team 11", "Team 12", "P", "", "", "");
$bracket_game_numbers[13][12][7] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[13][12][8] = array("Team 4", "Team 1", "P", "", "", "");
$bracket_game_numbers[13][12][9] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[13][12][10] = array("Team 8", "Team 5", "P", "", "", "");
$bracket_game_numbers[13][12][11] = array("Team 10", "Team 11", "P", "", "", "");
$bracket_game_numbers[13][12][12] = array("Team 12", "Team 9", "P", "", "", "");
$bracket_game_numbers[13][12][13] = array("#8 Seed", "#9 Seed", "P", "", "#8", "#9");
$bracket_game_numbers[13][12][14] = array("#5 Seed", "#12 Seed", "P", "", "#5", "#12");
$bracket_game_numbers[13][12][15] = array("#6 Seed", "#11 Seed", "W", "", "#6", "#11");
$bracket_game_numbers[13][12][16] = array("#7 Seed", "#10 Seed", "W", "", "#7", "#10");
$bracket_game_numbers[13][12][17] = array("#1 Seed", "Winner Game 13", "W", "", "#1", "W-13");
$bracket_game_numbers[13][12][18] = array("#4 Seed", "Winner Game 14", "W", "", "#4", "W-14");
$bracket_game_numbers[13][12][19] = array("#3 Seed", "Winner Game 15", "W", "", "#3", "W-15");
$bracket_game_numbers[13][12][20] = array("#2 Seed", "Winner Game 16", "W", "", "#2", "W-16");
$bracket_game_numbers[13][12][21] = array("Loser Game 15", "Loser Game 17", "W", "", "L-15", "L-17");
$bracket_game_numbers[13][12][22] = array("Loser Game 16", "Loser Game 18", "W", "", "L-16", "L-18");
$bracket_game_numbers[13][12][23] = array("Loser Game 13", "Loser Game 19", "W", "", "L-13", "L-19");
$bracket_game_numbers[13][12][24] = array("Loser Game 14", "Loser Game 20", "W", "", "L-14", "L-20");
$bracket_game_numbers[13][12][25] = array("Winner Game 21", "Loser Game 24", "W", "", "W-21", "L-24");
$bracket_game_numbers[13][12][26] = array("Winner Game 22", "Loser Game 23", "W", "", "W-22", "L-23");
$bracket_game_numbers[13][12][27] = array("Winner Game 23", "Loser Game 22", "W", "", "W-23", "L-22");
$bracket_game_numbers[13][12][28] = array("Winner Game 24", "Loser Game 21", "W", "", "W-24", "L-21");
$bracket_game_numbers[13][12][29] = array("Winner Game 17", "Winner Game 18", "W", "", "W-17", "W-18");
$bracket_game_numbers[13][12][30] = array("Winner Game 29", "Winner Game 20", "W", "", "W-29", "W-20");
$bracket_game_numbers[13][12][31] = array("Winner Game 25", "Winner Game 26", "W", "", "W-25", "W-26");
$bracket_game_numbers[13][12][32] = array("Winner Game 27", "Winner Game 28", "W", "", "W-27", "W-28");
$bracket_game_numbers[13][12][33] = array("Winner Game 31", "Loser Game 30", "W", "", "W-31", "L-30");
$bracket_game_numbers[13][12][34] = array("Winner Game 32", "Loser Game 29", "W", "", "W-32", "L-29");
$bracket_game_numbers[13][12][35] = array("Winner Game 29", "Winner Game 30", "W", "", "W-29", "W-30");
$bracket_game_numbers[13][12][36] = array("Winner Game 33", "Winner Game 34", "W", "", "W-33", "W-34");
$bracket_game_numbers[13][12][37] = array("Winner Game 36", "Loser Game 35", "W", "", "W-36", "L-35");
$bracket_game_numbers[13][12][38] = array("Winner Game 35", "Winner Game 37", "W", "", "W-35", "W-37");
$bracket_game_numbers[13][12][39] = array("Winner Game 38", "Loser 39 if 1st Loss ", "W", "", "W-39", "L-39");


$bracket_game_numbers[13][13][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[13][13][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[13][13][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[13][13][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[13][13][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[13][13][6] = array("Team 11", "Team 12", "P", "", "", "");
$bracket_game_numbers[13][13][7] = array("Team 13", "Team 1", "P", "", "", "");
$bracket_game_numbers[13][13][8] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[13][13][9] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[13][13][10] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[13][13][11] = array("Team 8", "Team 9", "P", "", "", "");
$bracket_game_numbers[13][13][12] = array("Team 10", "Team 11", "P", "", "", "");
$bracket_game_numbers[13][13][13] = array("Team 12", "Team 13", "P", "", "", "");
$bracket_game_numbers[13][13][14] = array("#7 Seed", "#10 Seed", "P", "", "#7", "#10");
$bracket_game_numbers[13][13][15] = array("#6 Seed", "#11 Seed", "W", "", "#6", "#11");
$bracket_game_numbers[13][13][16] = array("#4 Seed", "#13 Seed", "W", "", "#4", "#13");
$bracket_game_numbers[13][13][17] = array("#5 Seed", "#12 Seed", "W", "", "#5", "#12");
$bracket_game_numbers[13][13][18] = array("#8 Seed", "#9 Seed", "W", "", "#8", "#9");
$bracket_game_numbers[13][13][19] = array("#2 Seed", "Winner Game 14", "W", "", "#2", "W-14");
$bracket_game_numbers[13][13][20] = array("#3 Seed", "Winner Game 15", "W", "", "#3", "W-15");
$bracket_game_numbers[13][13][21] = array("Winner Game 16", "Winner Game 17", "W", "", "W-16", "W-17");
$bracket_game_numbers[13][13][22] = array("#1 Seed", "Winner Game 18", "W", "", "#1", "W-18");
$bracket_game_numbers[13][13][23] = array("Loser Game 14", "Loser Game 15", "W", "", "L-14", "L-15");
$bracket_game_numbers[13][13][24] = array("Loser Game 16", "Loser Game 17", "W", "", "L-16", "L-17");
$bracket_game_numbers[13][13][25] = array("Loser Game 18", "Loser Game 19", "W", "", "L-18", "L-19");
$bracket_game_numbers[13][13][26] = array("Loser Game 20", "Loser Game 22", "W", "", "L-20", "L-22");
$bracket_game_numbers[13][13][27] = array("Loser Game 21", "Loser Game 23", "W", "", "L-21", "L-23");
$bracket_game_numbers[13][13][28] = array("Winner Game 23", "Loser Game 24", "W", "", "W-23", "L-24");
$bracket_game_numbers[13][13][29] = array("Winner Game 24", "Loser Game 25", "W", "", "W-24", "L-25");
$bracket_game_numbers[13][13][30] = array("Winner Game 25", "Loser Game 26", "W", "", "W-25", "L-26");
$bracket_game_numbers[13][13][31] = array("Winner Game 26", "Winner Game 27", "W", "", "W-26", "W-27");
$bracket_game_numbers[13][13][32] = array("Winner Game 19", "Winner Game 20", "W", "", "W-19", "W-20");
$bracket_game_numbers[13][13][33] = array("Winner Game 21", "Winner Game 22", "W", "", "W-21", "W-22");
$bracket_game_numbers[13][13][34] = array("Winner Game 28", "Winner Game 29", "W", "", "W-28", "W-29");
$bracket_game_numbers[13][13][35] = array("Winner Game 30", "Winner Game 31", "W", "", "W-30", "W-31");
$bracket_game_numbers[13][13][36] = array("Loser Game 33", "Winner Game 34", "W", "", "L-33", "W-34");
$bracket_game_numbers[13][13][37] = array("Winner Game 35", "Loser Game 32", "W", "", "W-35", "L-32");
$bracket_game_numbers[13][13][38] = array("Winner Game 32", "Winner Game 33", "W", "", "W-32", "W-33");
$bracket_game_numbers[13][13][39] = array("Winner Game 36", "Winner Game 37", "W", "", "W-36", "W-37");
$bracket_game_numbers[13][13][40] = array("Winner Game 39", "Loser Game 38", "W", "", "W-39", "L-38");
$bracket_game_numbers[13][13][41] = array("Winner Game 38", "Winner Game 40", "W", "", "W-38", "W-40");
$bracket_game_numbers[13][13][42] = array("Winner Game 42", "Loser 42 if 1st Loss ", "W", "", "W-42", "L-42");



$bracket_game_numbers[13][14][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[13][14][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[13][14][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[13][14][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[13][14][5] = array("Team 9", "Team 11", "P", "", "", "");
$bracket_game_numbers[13][14][6] = array("Team 11", "Team 12", "P", "", "", "");
$bracket_game_numbers[13][14][7] = array("Team 13", "Team 14", "P", "", "", "");
$bracket_game_numbers[13][14][8] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[13][14][9] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[13][14][10] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[13][14][13] = array("Team 8", "Team 5", "P", "", "", "");
$bracket_game_numbers[13][14][12] = array("Team 10", "Team 11", "P", "", "", "");
$bracket_game_numbers[13][14][13] = array("Team 14", "Team 9", "P", "", "", "");
$bracket_game_numbers[13][14][14] = array("Team 13", "Team 10", "P", "", "", "");
$bracket_game_numbers[13][14][15] = array("#8 Seed", "#9 Seed", "P", "", "", "");
$bracket_game_numbers[13][14][16] = array("#5 Seed", "#12 Seed", "W", "", "#5", "#12");
$bracket_game_numbers[13][14][17] = array("#4 Seed", "#13 Seed", "W", "", "#4", "#13");
$bracket_game_numbers[13][14][18] = array("#3 Seed", "#14 Seed", "W", "", "#3", "#14");
$bracket_game_numbers[13][14][19] = array("#6 Seed", "#11 Seed", "W", "", "#6", "#11");
$bracket_game_numbers[13][14][20] = array("#7 Seed", "#10 Seed", "W", "", "#7", "#10");
$bracket_game_numbers[13][14][21] = array("#1 Seed", "Winner Game 15", "W", "", "#1", "W-15");
$bracket_game_numbers[13][14][22] = array("Winner Game 16", "Winner Game 17", "W", "", "W-16", "W-17");
$bracket_game_numbers[13][14][23] = array("Winner Game 18", "Winner Game 19", "W", "", "W-18", "W-19");
$bracket_game_numbers[13][14][24] = array("#2 Seed", "Winner Game 20", "W", "", "#2", "W-20");
$bracket_game_numbers[13][14][25] = array("Loser Game 18", "Loser Game 19", "W", "", "L-18", "L-19");
$bracket_game_numbers[13][14][26] = array("Loser Game 16", "Loser Game 17", "W", "", "L-16", "L-17");
$bracket_game_numbers[13][14][27] = array("Loser Game 15", "Loser Game 24", "W", "", "L-15", "L-24");
$bracket_game_numbers[13][14][28] = array("Loser Game 21", "Loser Game 20", "W", "", "L-21", "L-20");
$bracket_game_numbers[13][14][29] = array("Loser Game 22", "Loser Game 25", "W", "", "L-22", "L-25");
$bracket_game_numbers[13][14][30] = array("Loser Game 23", "Loser Game 26", "W", "", "L-23", "L-26");
$bracket_game_numbers[13][14][31] = array("Winner Game 29", "Loser Game 28", "W", "", "W-29", "L-28");
$bracket_game_numbers[13][14][32] = array("Winner Game 26", "Winner Game 27", "W", "", "W-26", "W-27");
$bracket_game_numbers[13][14][33] = array("Winner Game 25", "Winner Game 28", "W", "", "W-25", "W-28");
$bracket_game_numbers[13][14][34] = array("Loser Game 27", "Winner Game 30", "W", "", "L-27", "W-30");
$bracket_game_numbers[13][14][35] = array("Winner Game 21", "Winner Game 22", "W", "", "W-21", "W-22");
$bracket_game_numbers[13][14][36] = array("Winner Game 23", "Winner Game 24", "W", "", "W-23", "W-24");
$bracket_game_numbers[13][14][37] = array("Winner Game 31", "Winner Game 32", "W", "", "W-31", "W-32");
$bracket_game_numbers[13][14][38] = array("Winner Game 33", "Winner Game 34", "W", "", "W-33", "W-34");
$bracket_game_numbers[13][14][39] = array("Loser Game 36", "Winner Game 37", "W", "", "L-36", "W-37");
$bracket_game_numbers[13][14][40] = array("Winner Game 38", "Loser Game 35", "W", "", "W-38", "L-35");
$bracket_game_numbers[13][14][41] = array("Winner Game 35", "Winner Game 36", "W", "", "W-35", "W-36");
$bracket_game_numbers[13][14][42] = array("Winner Game 39", "Winner Game 40", "W", "", "W-39", "W-40");
$bracket_game_numbers[13][14][43] = array("Loser Game 41", "Winner Game 42", "W", "", "L-41", "W-42");
$bracket_game_numbers[13][14][44] = array("Winner Game 41", "Winner Game 43", "W", "", "W-41", "W-43");
$bracket_game_numbers[13][14][45] = array("Winner Game 44", "Loser 44 if 1st Loss ", "W", "", "W-44", "L-44");


$bracket_game_numbers[13][15][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[13][15][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[13][15][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[13][15][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[13][15][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[13][15][6] = array("Team 11", "Team 12", "P", "", "", "");
$bracket_game_numbers[13][15][7] = array("Team 13", "Team 14", "P", "", "", "");
$bracket_game_numbers[13][15][8] = array("Team 15", "Team 1", "P", "", "", "");
$bracket_game_numbers[13][15][9] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[13][15][10] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[13][15][11] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[13][15][12] = array("Team 8", "Team 9", "P", "", "", "");
$bracket_game_numbers[13][15][13] = array("Team 10", "Team 11", "P", "", "", "");
$bracket_game_numbers[13][15][14] = array("Team 12", "Team 13", "P", "", "", "");
$bracket_game_numbers[13][15][15] = array("Team 14", "Team 15", "P", "", "", "");
$bracket_game_numbers[13][15][16] = array("#8 Seed", "#9 Seed", "P", "", "", "");
$bracket_game_numbers[13][15][17] = array("#5 Seed", "#12 Seed", "W", "", "#5", "#12");
$bracket_game_numbers[13][15][18] = array("#4 Seed", "#13 Seed", "W", "", "#4", "#13");
$bracket_game_numbers[13][15][19] = array("#3 Seed", "#14 Seed", "W", "", "#3", "#14");
$bracket_game_numbers[13][15][20] = array("#6 Seed", "#11 Seed", "W", "", "#6", "#11");
$bracket_game_numbers[13][15][21] = array("#7 Seed", "#10 Seed", "W", "", "#7", "#10");
$bracket_game_numbers[13][15][22] = array("#2 Seed", "#15 Seed", "W", "", "#2", "#15");
$bracket_game_numbers[13][15][23] = array("#1 Seed", "Winner Game 16", "W", "", "#1", "W-16");
$bracket_game_numbers[13][15][24] = array("Winner Game 17", "Winner Game 18", "W", "", "W-17", "W-18");
$bracket_game_numbers[13][15][25] = array("Winner Game 19", "Winner Game 20", "W", "", "W-19", "W-20");
$bracket_game_numbers[13][15][26] = array("Winner Game 21", "Winner Game 22", "W", "", "W-21", "W-22");
$bracket_game_numbers[13][15][27] = array("Loser Game 16", "Loser Game 19", "W", "", "L-16", "L-19");
$bracket_game_numbers[13][15][28] = array("Loser Game 21", "Loser Game 23", "W", "", "L-21", "L-23");
$bracket_game_numbers[13][15][29] = array("Loser Game 17", "Loser Game 18", "W", "", "L-17", "L-18");
$bracket_game_numbers[13][15][30] = array("Loser Game 20", "Loser Game 22", "W", "", "L-20", "L-22");
$bracket_game_numbers[13][15][31] = array("Winner Game 27", "Loser Game 28", "W", "", "W-27", "L-28");
$bracket_game_numbers[13][15][32] = array("Winner Game 28", "Loser Game 29", "W", "", "W-28", "L-29");
$bracket_game_numbers[13][15][33] = array("Winner Game 20", "Loser Game 30", "W", "", "W-20", "L-30");
$bracket_game_numbers[13][15][34] = array("Winner Game 30", "Loser Game 27", "W", "", "W-30", "L-27");
$bracket_game_numbers[13][15][35] = array("Winner Game 31", "Loser Game 24", "W", "", "W-31", "L-24");
$bracket_game_numbers[13][15][36] = array("Winner Game 32", "Loser Game 25", "W", "", "W-32", "L-25");
$bracket_game_numbers[13][15][37] = array("Winner Game 33", "Loser Game 26", "W", "", "W-33", "L-26");
$bracket_game_numbers[13][15][38] = array("Winner Game 23", "Winner Game 24", "W", "", "W-23", "W-24");
$bracket_game_numbers[13][15][39] = array("Winner Game 25", "Winner Game 26", "W", "", "W-25", "W-26");
$bracket_game_numbers[13][15][40] = array("Winner Game 35", "Winner Game 36", "W", "", "W-35", "W-36");
$bracket_game_numbers[13][15][41] = array("Winner Game 34", "Winner Game 37", "W", "", "W-34", "W-37");
$bracket_game_numbers[13][15][42] = array("Winner Game 40", "Loser Game 38", "W", "", "W-40", "L-38");
$bracket_game_numbers[13][15][43] = array("Winner Game 41", "Loser Game 39", "W", "", "W-41", "L-39");
$bracket_game_numbers[13][15][44] = array("Winner Game 38", "Winner Game 39", "W", "", "W-38", "W-39");
$bracket_game_numbers[13][15][45] = array("Winner Game 42", "Winner Game 43", "W", "", "W-42", "W-43");
$bracket_game_numbers[13][15][46] = array("Winner Game 45", "Loser Game 44", "W", "", "W-45", "L-44");
$bracket_game_numbers[13][15][47] = array("Winner Game 45", "Winner Game 46", "W", "", "W-45", "W-46");
$bracket_game_numbers[13][15][48] = array("Winner Game 47", "Loser 47 if 1st Loss ", "W", "", "W-47", "L-47");


$bracket_game_numbers[13][16][1] = array("Team 1", "Team 2", "P", "", "", "");
$bracket_game_numbers[13][16][2] = array("Team 3", "Team 4", "P", "", "", "");
$bracket_game_numbers[13][16][3] = array("Team 5", "Team 6", "P", "", "", "");
$bracket_game_numbers[13][16][4] = array("Team 7", "Team 8", "P", "", "", "");
$bracket_game_numbers[13][16][5] = array("Team 9", "Team 10", "P", "", "", "");
$bracket_game_numbers[13][16][6] = array("Team 11", "Team 12", "P", "", "", "");
$bracket_game_numbers[13][16][7] = array("Team 13", "Team 14", "P", "", "", "");
$bracket_game_numbers[13][16][8] = array("Team 15", "Team 16", "P", "", "", "");
$bracket_game_numbers[13][16][9] = array("Team 2", "Team 3", "P", "", "", "");
$bracket_game_numbers[13][16][10] = array("Team 4", "Team 5", "P", "", "", "");
$bracket_game_numbers[13][16][11] = array("Team 6", "Team 7", "P", "", "", "");
$bracket_game_numbers[13][16][12] = array("Team 8", "Team 9", "P", "", "", "");
$bracket_game_numbers[13][16][13] = array("Team 10", "Team 11", "P", "", "", "");
$bracket_game_numbers[13][16][14] = array("Team 12", "Team 9", "P", "", "", "");
$bracket_game_numbers[13][16][15] = array("Team 14", "Team 15", "P", "", "", "");
$bracket_game_numbers[13][16][16] = array("Team 16", "Team 13", "P", "", "", "");
$bracket_game_numbers[13][16][17] = array("#1 Seed", "#16 Seed", "W", "", "#1", "#16");
$bracket_game_numbers[13][16][18] = array("#8 Seed", "#9 Seed", "W", "", "#8", "#9");
$bracket_game_numbers[13][16][19] = array("#5 Seed", "#12 Seed", "W", "", "#5", "#12");
$bracket_game_numbers[13][16][20] = array("#4 Seed", "#13 Seed", "W", "", "#4", "#13");
$bracket_game_numbers[13][16][21] = array("#3 Seed", "#14 Seed", "W", "", "#3", "#14");
$bracket_game_numbers[13][16][22] = array("#6 Seed", "#11 Seed", "W", "", "#6", "#11");
$bracket_game_numbers[13][16][23] = array("#7 Seed", "#10 Seed", "W", "", "#7", "#10");
$bracket_game_numbers[13][16][24] = array("#2 Seed", "#15 Seed", "W", "", "#2", "#15");
$bracket_game_numbers[13][16][25] = array("Loser Game 17", "Loser Game 18", "W", "", "L-17", "L-18");
$bracket_game_numbers[13][16][26] = array("Loser Game 19", "Loser Game 20", "W", "", "L-19", "L-20");
$bracket_game_numbers[13][16][27] = array("Loser Game 21", "Loser Game 22", "W", "", "L-21", "L-22");
$bracket_game_numbers[13][16][28] = array("Loser Game 23", "Loser Game 24", "W", "", "L-23", "L-24");
$bracket_game_numbers[13][16][29] = array("Winner Game 17", "Winner Game 18", "W", "", "W-17", "W-18");
$bracket_game_numbers[13][16][30] = array("Winner Game 19", "Winner Game 20", "W", "", "W-19", "W-20");
$bracket_game_numbers[13][16][31] = array("Winner Game 21", "Winner Game 22", "W", "", "W-21", "W-22");
$bracket_game_numbers[13][16][32] = array("Winner Game 23", "Winner Game 24", "W", "", "W-23", "W-24");
$bracket_game_numbers[13][16][33] = array("Winner Game 25", "Loser Game 26", "W", "", "W-25", "L-26");
$bracket_game_numbers[13][16][34] = array("Winner Game 26", "Loser Game 25", "W", "", "W-26", "L-25");
$bracket_game_numbers[13][16][35] = array("Winner Game 27", "Loser Game 28", "W", "", "W-27", "L-28");
$bracket_game_numbers[13][16][36] = array("Winner Game 28", "Loser Game 27", "W", "", "W-28", "L-27");
$bracket_game_numbers[13][16][37] = array("Winner Game 33", "Loser Game 32", "W", "", "W-33", "L-32");
$bracket_game_numbers[13][16][38] = array("Winner Game 34", "Loser Game 31", "W", "", "W-34", "L-31");
$bracket_game_numbers[13][16][39] = array("Winner Game 35", "Loser Game 30", "W", "", "W-35", "L-30");
$bracket_game_numbers[13][16][40] = array("Winner Game 36", "Loser Game 29", "W", "", "W-36", "L-29");
$bracket_game_numbers[13][16][41] = array("Winner Game 29", "Winner Game 30", "W", "", "W-29", "W-30");
$bracket_game_numbers[13][16][42] = array("Winner Game 31", "Winner Game 32", "W", "", "W-31", "W-32");
$bracket_game_numbers[13][16][43] = array("Winner Game 37", "Winner Game 38", "W", "", "W-37", "W-38");
$bracket_game_numbers[13][16][44] = array("Winner Game 39", "Winner Game 40", "W", "", "W-39", "W-40");
$bracket_game_numbers[13][16][45] = array("Winner Game 43", "Loser Game 41", "W", "", "W-43", "L-41");
$bracket_game_numbers[13][16][46] = array("Winner Game 44", "Loser Game 42", "W", "", "W-44", "L-42");
$bracket_game_numbers[13][16][47] = array("Winner Game 41", "Winner Game 42", "W", "", "W-41", "W-42");
$bracket_game_numbers[13][16][48] = array("Winner Game 45", "Winner Game 46", "W", "", "W-45", "W-46");
$bracket_game_numbers[13][16][49] = array("Winner Game 48", "Loser Game 47", "W", "", "W-48", "L-47");
$bracket_game_numbers[13][16][50] = array("Winner Game 47", "Winner Game 49", "W", "", "W-47", "W-49");
$bracket_game_numbers[13][16][51] = array("Winner Game 50", "Loser 50 if 1st Loss ", "W", "", "W-50", "L-50");


//---------------------------End------------------------------//

function getBracketMatches($bracketId, $noOfTeams){
    $matches = array();
    if(isset($bracket_game_numbers[$bracketId]) && isset($bracket_game_numbers[$bracketId][$noOfTeams])){
        $matches = $bracket_game_numbers[$bracketId][$noOfTeams];
    }
    return $matches;
}



?>