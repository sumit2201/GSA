<?php 
define("ACTION_SUCCESS", "Success");
define("ACTION_FAIL", "Fail");
define("USER_NOT_ENABLED", "Account is not enavbled yet");
define("USER_VERIFICATION_PENDING", "Email or phone verification pending");
define("SITE_ROOT_IMAGE_FOLDER_PATH","/opt/lampp/htdocs/GSA/my-app/src/assets/images")
?>